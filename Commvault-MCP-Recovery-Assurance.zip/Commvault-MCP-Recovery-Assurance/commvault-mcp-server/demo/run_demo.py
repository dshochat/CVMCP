"""
Terminal walkthrough of the Recovery Assurance story against the simulated CommCell.

    python demo/run_demo.py
"""

import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["RECOVERY_BASELINE_DIR"] = tempfile.mkdtemp(prefix="cv-recovery-")

from src.recovery.baseline import (audit_recovery_group, commit_approval, detect_drift,  # noqa: E402
                                   prepare_approval, propose_sequence)
from src.recovery.cv_reader import CommvaultReader  # noqa: E402
from src.recovery.discovery import RecoveryDiscovery  # noqa: E402
from src.recovery.simulator import SimulatedCommCell  # noqa: E402

ICON = {"critical": "[CRIT]", "high": "[HIGH]", "medium": "[MED ]", "low": "[LOW ]"}


def h(t):
    print("\n" + "=" * 78 + f"\n {t}\n" + "=" * 78)


sim = SimulatedCommCell()
engine = lambda: RecoveryDiscovery(CommvaultReader(sim))  # noqa: E731

h("1. Owner gives ONE seed:  TradingDemo  ->  TRADING-WEB-01")
r = engine().discover("TRADING-WEB-01", "TradingDemo")
print(r["summary"])
print("\nResources:")
for x in r["resources"]:
    print(f"  {x['name']:<22} {x['role']:<10} {x['confidence']:<9} " + " | ".join(x["evidence"]))
print("\nRecoverability gaps:")
for g in r["gaps"]:
    print(f"  {ICON[g['severity']]} {g['resource']:<22} {g['finding']}")
print("\nNot visible to Commvault (owner must confirm):")
for u in r["unknownOutsideCommvault"][:3]:
    print("  ? " + u)

INC, EXC = ["TRADING-SQL-01", "TRADING-API-01"], ["trading-reporting-01"]

h("2. Recovery order - determined automatically from technology (no owner input)")
p = propose_sequence(engine(), "TradingDemo", "TRADING-WEB-01", INC, EXC)
for pre in p["prerequisites"]:
    print("  Before P1: " + pre.split(".")[0])
for pr in p["priorities"]:
    for r in pr["resources"]:
        print(f"  P{pr['priority']}  {r['name']:<16} {r['tier']:<13} {r['confidence']:<9} {r['evidence'][0]}")
    print(f"       gate -> {'; '.join(pr['releaseNextPriorityWhen'])}")
print(f"  plan fingerprint: {p['planHash']}")

h("3. Owner approves (in the MCP client this is a dialog the AI cannot answer)")
pending, _ = prepare_approval(engine(), "TradingDemo", "TRADING-WEB-01", INC, EXC, p["planHash"])
print("\n".join("  | " + line for line in pending["confirmationText"].splitlines()))
a = commit_approval(pending, "Dana Lee (TradingDemo owner)", "demo")
print(f"  {a['status']} by {a['approvedBy']}: {a['recoveryOrder']}")

h("4. Audit the EXISTING Cleanroom recovery group (zero input)")
au = audit_recovery_group(engine(), "TradingDemo-Cleanroom")
print("  current:     " + ", ".join(f"{e['entity']}=P{e['priority']}" for e in au["currentOrder"]))
print("  recommended: " + ", ".join(f"{e['entity']}=P{e['executionOrder']['priority']}" for e in au["recommendedOrder"]))
for f in au["findings"]:
    print(f"  {ICON[f['severity']]} {f['finding']}")

h("5. Drift check, same day")
print("  " + detect_drift(engine(), "TradingDemo")["summary"])

h("6. Six months later... (new API node, new Kafka broker, DB dropped from backup, SQL backups failing)")
sim.apply_drift()
d = detect_drift(engine(), "TradingDemo")
print("  " + d["status"])
for f in d["findings"]:
    print(f"  {ICON[f['severity']]} {f['resource']:<16} {f['finding']}")
    print(f"         action: {f['recommendedAction']}")
print("\n  " + d["note"])
