"""
Terminal walkthrough of the Recovery Assurance story against the simulated CommCell.

    python demo/run_demo.py
"""

import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
os.environ["RECOVERY_BASELINE_DIR"] = tempfile.mkdtemp(prefix="cv-recovery-")

from src.recovery.baseline import (audit_recovery_group, commit_approval, detect_drift,  # noqa: E402
                                   prepare_approval, propose_sequence)
from src.recovery.cv_reader import CommvaultReader  # noqa: E402
from src.recovery.discovery import RecoveryDiscovery  # noqa: E402
from src.recovery.simulator import SimulatedCommCell  # noqa: E402

ICON = {"critical": "[CRIT]", "high": "[HIGH]", "medium": "[MED ]", "low": "[LOW ]"}


def h(t):
    print("\n" + "=" * 78 + f"\n {t}\n" + "=" * 78)


sim = SimulatedCommCell()
engine = lambda: RecoveryDiscovery(CommvaultReader(sim))  # noqa: E731

h("1. Owner gives ONE seed:  TradingDemo  ->  TRADING-WEB-01")
r = engine().discover("TRADING-WEB-01", "TradingDemo")
print(r["summary"])
print("\nResources:")
for x in r["resources"]:
    print(f"  {x['name']:<22} {x['role']:<10} {x['confidence']:<9} " + " | ".join(x["evidence"]))
print("\nRecoverability gaps:")
for g in r["gaps"]:
    print(f"  {ICON[g['severity']]} {g['resource']:<22} {g['finding']}")
print("\nNot visible to Commvault (owner must confirm):")
for u in r["unknownOutsideCommvault"][:3]:
    print("  ? " + u)

INC, EXC = ["TRADING-SQL-01", "TRADING-API-01"], ["trading-reporting-01"]

h("2. Recovery order - determined automatically from technology (no owner input)")
p = propose_sequence(engine(), "TradingDemo", "TRADING-WEB-01", INC, EXC)
for pre in p["prerequisites"]:
    print("  Before P1: " + pre.split(".")[0])
for pr in p["priorities"]:
    for r in pr["resources"]:
        print(f"  P{pr['priority']}  {r['name']:<16} {r['tier']:<13} {r['confidence']:<9} {r['evidence'][0]}")
    print(f"       gate -> {'; '.join(pr['releaseNextPriorityWhen'])}")
print(f"  plan fingerprint: {p['planHash']}")

h("3. Owner approves (in the MCP client this is a dialog the AI cannot answer)")
pending, _ = prepare_approval(engine(), "TradingDemo", "TRADING-WEB-01", INC, EXC, p["planHash"])
print("\n".join("  | " + line for line in pending["confirmationText"].splitlines()))
a = commit_approval(pending, "Dana Lee (TradingDemo owner)", "demo")
print(f"  {a['status']} by {a['approvedBy']}: {a['recoveryOrder']}")

h("4. Audit the EXISTING Cleanroom recovery group (zero input)")
au = audit_recovery_group(engine(), "TradingDemo-Cleanroom")
print("  current:     " + ", ".join(f"{e['entity']}=P{e['priority']}" for e in au["currentOrder"]))
print("  recommended: " + ", ".join(f"{e['entity']}=P{e['executionOrder']['priority']}" for e in au["recommendedOrder"]))
for f in au["findings"]:
    print(f"  {ICON[f['severity']]} {f['finding']}")

h("5. Drift check, same day")
print("  " + detect_drift(engine(), "TradingDemo")["summary"])

h("6. Six months later... (new API node, new Kafka broker, DB dropped from backup, SQL backups failing)")
sim.apply_drift()
d = detect_drift(engine(), "TradingDemo")
print("  " + d["status"])
for f in d["findings"]:
    print(f"  {ICON[f['severity']]} {f['resource']:<16} {f['finding']}")
    print(f"         action: {f['recommendedAction']}")
print("\n  " + d["note"])

h("7. Security scenario: Cortex incident + Wiz graph -> identity-compromise recovery runbook")
import json as _json
from datetime import datetime as _dt, timezone as _tz
from src.recovery.adapters.security_sources import build_graph as _build_graph
from src.recovery.runbook import build_runbook as _build_runbook
_g = Path(__file__).resolve().parent / "graphs"
sim2 = SimulatedCommCell()
_full = _json.loads((_g / "tradingdemo_identity_compromise.json").read_text())
_full["t0"] = _dt.fromtimestamp(sim2.now - 50 * 3600, tz=_tz.utc).isoformat()
_rb = _build_runbook(RecoveryDiscovery(CommvaultReader(sim2)), "identity_compromise", _full,
                     recovery_group_name="TradingDemo-Cleanroom")
print("  " + _rb["summary"])
print(f"  t0 {_rb['t0']}  ->  clean cutoff {_rb['cleanCutoff']} (dwell {_rb['dwellTimeHours']} h)")
for line in _rb["recoveryOrder"]:
    print("    " + line)
for f in _rb["recoveryGroupFindings"][:3]:
    print(f"  [{f['severity'].upper()}] {f['finding'][:150]}")
for ph in _rb["phases"]:
    print(f"  -- {ph['title']}")
    for s in ph["steps"][:4]:
        print(f"     {s['step']:>2}. {'AUTO  ' if s['automatable'] else 'MANUAL'} {s['title'][:110]}")
_imp = _build_graph(_json.loads((_g / "sample_cortex_incident.json").read_text()),
                    _json.loads((_g / "sample_wiz_graph.json").read_text()), 24)
print(f"\n  Same flow from raw exports: Cortex incident {_imp['incidentId']} -> scenario '{_imp['suggestedScenario']}' "
      f"({_imp['scenarioReason']}); Wiz graph -> {_imp['report']['nodes']} nodes / {_imp['report']['edges']} edges; "
      f"unmapped: {_imp['report']['unmappedWizEntityTypes'] + _imp['report']['unmappedWizRelationships']}")
print("  Read-only plan: nothing was executed.")
