"""
Offline demo MCP server: the Recovery Assurance tools running against a SIMULATED CommCell
(application "TradingDemo"). No Commvault server, token or keyring needed.

    python demo/sim_server.py            # stdio, for Claude Desktop / any MCP client

Extra demo-only tools:
    simulate_production_change  - fast-forward six months of production change
    reset_simulation            - back to day zero (also clears the approved baseline)
"""

import os
import sys
import types
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.environ.setdefault("RECOVERY_BASELINE_DIR", str(ROOT / "demo" / "baselines"))

from src.recovery.simulator import SimulatedCommCell  # noqa: E402

STATE = {"sim": SimulatedCommCell()}


class _SimProxy:
    """Stands in for src.cv_api_client.commvault_api_client; GET-only."""
    def get(self, endpoint, params=None, headers=None):
        return STATE["sim"].get(endpoint, params)


# Route every Commvault call in this process to the simulator (must precede src.tools import).
_stub = types.ModuleType("src.cv_api_client")
_stub.commvault_api_client = _SimProxy()
sys.modules["src.cv_api_client"] = _stub

from fastmcp import FastMCP  # noqa: E402
from fastmcp.tools import Tool  # noqa: E402
from src.tools.recovery_tools import RECOVERY_ASSURANCE_TOOLS  # noqa: E402


def simulate_production_change() -> dict:
    """
    DEMO ONLY. Simulates six months of production change in the TradingDemo application:
    a new API server and a Kafka broker are deployed, a database is dropped from backup content, and SQL backups start failing.
    Afterwards, call detect_recovery_drift for TradingDemo.
    """
    STATE["sim"].apply_drift()
    return {"status": "OK", "simulated": [
        "TRADING-API-02 deployed and added to client group TradingDemo-Prod",
        "TradingAudit database removed from the SQL subclient content",
        "TRADING-KAFKA-01 (message broker) deployed into the TradingDemo-Prod group",
        "TRADING-SQL-01 has had no successful backup for 41 hours",
    ]}


def reset_simulation() -> dict:
    """DEMO ONLY. Resets the simulated CommCell to day zero and deletes the TradingDemo approved baseline."""
    STATE["sim"] = SimulatedCommCell()
    f = Path(os.environ["RECOVERY_BASELINE_DIR"]) / "tradingdemo.json"
    if f.exists():
        f.unlink()
    return {"status": "RESET"}


mcp = FastMCP(
    name="Commvault Recovery Assurance (simulated CommCell)",
    instructions=(
        "Recovery Assurance tools for Commvault. The CommCell is SIMULATED and contains one application, "
        "TradingDemo, whose owner-supplied seed resource is TRADING-WEB-01, and an existing Cleanroom recovery group "
        "TradingDemo-Cleanroom. Workflow: discover_recovery_application -> ask the user to confirm candidates -> "
        "generate_recovery_sequence -> show the plan -> approve_recovery_map (the server asks the human directly). "
        "Never claim a candidate belongs to the application without the user's confirmation. "
        "Security scenarios: sample inputs live in demo/graphs (tradingdemo_identity_compromise.json, "
        "sample_cortex_incident.json, sample_wiz_graph.json); use import_security_context for raw Cortex/Wiz exports, "
        "then build_scenario_runbook with recovery_group_name TradingDemo-Cleanroom."
    ),
)
for fn in RECOVERY_ASSURANCE_TOOLS + [simulate_production_change, reset_simulation]:
    mcp.add_tool(Tool.from_function(fn, output_schema=None))

if __name__ == "__main__":
    mcp.run(transport="stdio")
