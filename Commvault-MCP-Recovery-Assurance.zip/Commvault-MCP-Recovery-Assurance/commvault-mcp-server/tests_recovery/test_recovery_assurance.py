"""
Offline tests for the Recovery Assurance tools. Run with:  pytest tests_recovery
They use the simulated CommCell; no Commvault server or credentials are needed.
"""
import json

import pytest

from src.recovery.baseline import (audit_recovery_group, commit_approval, detect_drift, load_baseline,
                                   prepare_approval, propose_sequence)
from src.recovery.sequencing import classify
from src.recovery.cv_reader import CommvaultReader
from src.recovery.discovery import RecoveryDiscovery
from src.recovery.simulator import SimulatedCommCell

APP, SEED = "TradingDemo", "TRADING-WEB-01"


@pytest.fixture(autouse=True)
def baseline_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("RECOVERY_BASELINE_DIR", str(tmp_path))
    return tmp_path


@pytest.fixture
def sim():
    return SimulatedCommCell()


def engine(sim, rpo=24):
    return RecoveryDiscovery(CommvaultReader(sim), rpo_hours=rpo)


def by_name(result):
    return {r["name"]: r for r in result["resources"]}


INC, EXC = ["TRADING-SQL-01", "TRADING-API-01"], ["trading-reporting-01"]


def approve_default(sim):
    h = propose_sequence(engine(sim), APP, SEED, INC, EXC)["planHash"]
    pending, err = prepare_approval(engine(sim), APP, SEED, INC, EXC, h)
    assert err is None
    return commit_approval(pending, "owner", "test")


# ------------------------------------------------------------------ discovery
def test_seed_is_confirmed_and_resolved(sim):
    r = engine(sim).discover(SEED, APP)
    assert r["status"] == "DISCOVERED" and r["readOnly"] is True
    seed = by_name(r)[SEED]
    assert seed["role"] == "seed" and seed["confidence"] == "confirmed" and seed["type"] == "VM"
    assert seed["protection"]["protected"] is True


def test_seed_resolves_by_hostname_case_insensitive(sim):
    assert engine(sim).discover("trading-web-01.corp.local", APP)["status"] == "DISCOVERED"


def test_unknown_seed_reports_not_found(sim):
    r = engine(sim).discover("NOPE-01", APP)
    assert r["status"] == "SEED_NOT_FOUND"


def test_candidates_carry_evidence_and_graded_confidence(sim):
    res = by_name(engine(sim).discover(SEED, APP))
    assert res["TRADING-SQL-01"]["confidence"] == "high"
    assert res["trading-reporting-01"]["confidence"] == "low"
    for name in ("TRADING-SQL-01", "TRADING-API-01", "trading-reporting-01"):
        assert res[name]["role"] == "candidate" and res[name]["needsOwnerReview"] is True
        assert res[name]["evidence"]


def test_broad_groups_are_ignored(sim):
    r = engine(sim).discover(SEED, APP)
    assert not any(n.startswith("CORP-VM") for n in by_name(r))
    assert any("All Production VMs" in n and "infrastructure" in n for n in r["notes"])


def test_sql_instance_and_databases_discovered_on_candidate(sim):
    sql = by_name(engine(sim).discover(SEED, APP))["TRADING-SQL-01"]
    dbs = sql["protection"]["subclients"][0]["databases"]
    assert "SQL Server" in sql["protection"]["applications"]
    assert set(dbs) == {"TradingDB", "TradingAudit"}


def test_gaps_flag_unprotected_and_single_copy(sim):
    gaps = engine(sim).discover(SEED, APP)["gaps"]
    findings = {(g["resource"], g["finding"]) for g in gaps}
    assert ("trading-reporting-01", "Possible application component has no Commvault protection") in findings
    assert any(res == "TRADING-API-01" and "single copy" in f for res, f in findings)


def test_outside_commvault_unknowns_always_reported(sim):
    r = engine(sim).discover(SEED, APP)
    assert any("Active Directory" in u for u in r["unknownOutsideCommvault"])


def test_discovery_is_read_only(sim):
    eng = engine(sim)
    eng.discover(SEED, APP)
    # The simulator only implements GET; any write attempt would raise AttributeError.
    assert not hasattr(sim, "post") and eng.r.calls


def test_stale_recovery_point_flagged(sim):
    sim.clients["101"]["backups"] = [sim.now - 50 * 3600]
    gaps = engine(sim).discover(SEED, APP)["gaps"]
    assert any(g["resource"] == SEED and "RPO" in g["finding"] for g in gaps)


# ------------------------------------------- regressions from the 11.46 lab probe (2026-10-20)
def test_lab_hypervisor_group_is_not_application_evidence(sim):
    """ESX1-style groups (all VMs on a host) produced false candidates on the real lab."""
    r = engine(sim).discover(SEED, APP)
    assert "CORP-VM-01" not in by_name(r) and "CORP-VM-02" not in by_name(r)
    assert any("ESX-PROD-04" in n and "infrastructure" in n for n in r["notes"])


def test_lab_recovery_group_assembly_is_strong_evidence(sim):
    sim._client("107", "LEGACY-BATCH-07", True, ["14"], ["File System"],
                [("207", "default", "File System", "DefaultInstanceName", "1", [])], [-5])
    sim.groups["14"] = {"name": "Sample Application 1", "members": ["101", "107"], "cfg": 2, "rg": True,
                        "desc": "Assembly auto-created during upgrade for Recovery Group: Sample Application 1"}
    sim.clients["101"]["groups"].append("14")
    c = by_name(engine(sim).discover(SEED, APP))["LEGACY-BATCH-07"]
    assert c["confidence"] == "high" and "recovery group" in c["evidence"][0]


def test_lab_configuration_group_ignored(sim):
    sim.groups["15"] = {"name": "ThreatScan configuration group", "members": ["101", "936"], "cfg": 0}
    sim.clients["101"]["groups"].append("15")
    r = engine(sim).discover(SEED, APP)
    assert "CORP-VM-36" not in by_name(r) and any("configuration group" in n for n in r["notes"])


def test_lab_air_gap_protect_and_compliance_lock_detected(sim):
    seed = by_name(engine(sim).discover(SEED, APP))[SEED]
    copies = seed["protection"]["plans"][0]["copies"]
    agp = [c for c in copies if c["airGapped"]]
    assert len(agp) == 1 and agp[0]["immutable"] and "compliance lock" in agp[0]["immutableEvidence"]
    gaps = {g["finding"] for g in engine(sim).discover(SEED, APP)["gaps"] if g["resource"] == SEED}
    assert not any("air-gapped" in g or "immutable" in g.lower() for g in gaps)


def test_lab_snapshot_copy_is_not_an_independent_copy(sim):
    sim.plans["1"]["backupDestinations"].pop()   # drop AGP -> snapshot + primary only
    gaps = engine(sim).discover(SEED, APP)["gaps"]
    assert any(g["resource"] == SEED and "single copy" in g["finding"] for g in gaps)


def test_lab_onprem_plus_cloud_is_not_same_region(sim):
    gaps = engine(sim).discover(SEED, APP)["gaps"]
    assert not any(g["resource"] == SEED and "same region" in g["finding"] for g in gaps)


def test_lab_system_databases_hidden_from_summary(sim):
    sim.clients["102"]["subclients"][0]["dbs"] += ["master", "model", "msdb"]
    r = engine(sim).discover("TRADING-SQL-01", APP)
    assert "master" not in r["summary"] and "TradingDB" in r["summary"]


def test_lab_recovery_group_found_via_assembly_chain(sim):
    a = audit_recovery_group(engine(sim), "TradingDemo-Cleanroom")
    assert a["recoveryGroupDetails"]["assemblyId"] == "37" and a["recoveryGroupDetails"]["id"] == "7"
    assert a["recoveryGroupDetails"]["target"] == "Azure Sample Cleanroom"


def test_lab_priorities_unavailable_falls_back_to_members(sim):
    sim.rg_detail_supported = False
    a = audit_recovery_group(engine(sim), "TradingDemo-Cleanroom")
    assert a["status"] == "PRIORITIES_UNAVAILABLE" and not a["findings"]
    assert {e["entity"] for e in a["currentOrder"]} == {"TRADING-WEB-01", "TRADING-API-01", "TRADING-SQL-01"}
    assert a["recommendedOrder"][0]["entity"] == "TRADING-SQL-01"


def test_lab_empty_recovery_group_list_is_not_found(sim):
    sim.recovery_groups = {}
    assert audit_recovery_group(engine(sim), "Anything")["status"] == "GROUP_NOT_FOUND"


# ------------------------------------------------------------------- approval
def test_approval_requires_decision_on_every_candidate(sim):
    p = propose_sequence(engine(sim), APP, SEED, ["TRADING-SQL-01"], [])
    pending, err = prepare_approval(engine(sim), APP, SEED, ["TRADING-SQL-01"], [], p["planHash"])
    assert pending is None and err["status"] == "NEEDS_DECISION"
    assert set(err["undecidedCandidates"]) == {"TRADING-API-01", "trading-reporting-01"}


def test_approval_rejects_names_not_discovered(sim):
    pending, err = prepare_approval(engine(sim), APP, SEED, ["MADE-UP-99"], [], "x")
    assert err["status"] == "REJECTED"


def test_approval_refuses_when_plan_changed_after_review(sim):
    h = propose_sequence(engine(sim), APP, SEED, INC, EXC)["planHash"]
    sim.clients["103"]["agents"].append("Oracle")          # API-01 becomes a database server
    pending, err = prepare_approval(engine(sim), APP, SEED, INC, EXC, h)
    assert pending is None and err["status"] == "PLAN_CHANGED"


def test_approval_persists_baseline_with_sequence(sim, baseline_dir):
    r = approve_default(sim)
    assert r["status"] == "APPROVED" and len(r["members"]) == 3
    assert r["recoveryOrder"] == ["P1: TRADING-SQL-01", "P2: TRADING-API-01", "P3: TRADING-WEB-01"]
    base = load_baseline(APP)
    assert set(base["members"]) == {SEED, "TRADING-SQL-01", "TRADING-API-01"}
    assert base["excluded"] == ["trading-reporting-01"] and base["sequence"]["planHash"] == r["planHash"]
    assert json.loads((baseline_dir / "tradingdemo.json").read_text())["approvedBy"] == "owner"


def test_application_name_is_sanitised_for_filesystem(sim, baseline_dir):
    app = "../../etc/Trading Demo"
    h = propose_sequence(engine(sim), app, SEED, INC, EXC)["planHash"]
    pending, _ = prepare_approval(engine(sim), app, SEED, INC, EXC, h)
    commit_approval(pending, "owner", "test")
    assert (baseline_dir / "etc-trading-demo.json").exists()


# ----------------------------------------------------------------- sequencing
def test_default_order_is_data_then_app_then_web_with_no_input(sim):
    p = propose_sequence(engine(sim), APP, SEED, INC, EXC)
    order = [[r["name"] for r in pr["resources"]] for pr in p["priorities"]]
    assert order == [["TRADING-SQL-01"], ["TRADING-API-01"], ["TRADING-WEB-01"]]
    assert p["prerequisites"] and "Active Directory" in p["prerequisites"][0]


def test_agent_evidence_is_confirmed_naming_is_flagged(sim):
    p = propose_sequence(engine(sim), APP, SEED, INC, EXC)
    tiers = {r["name"]: r for pr in p["priorities"] for r in pr["resources"]}
    assert tiers["TRADING-SQL-01"]["confidence"] == "confirmed"
    assert {c["resource"] for c in p["classificationsNeedingConfirmation"]} == {"TRADING-WEB-01", "TRADING-API-01"}


def test_unknown_technology_defaults_to_application_low():
    c = classify({"name": "XQZ-17", "protection": {"applications": ["File System"]}})
    assert c["tier"] == "application" and c["confidence"] == "low" and c["needsConfirmation"]


def test_db_agent_beats_misleading_hostname():
    c = classify({"name": "PAY-WEB-07", "protection": {"applications": ["Virtual Server", "Oracle"]}})
    assert c["tier"] == "data" and c["confidence"] == "confirmed"


def test_owner_exception_reorders_and_cycles_are_rejected(sim):
    p = propose_sequence(engine(sim), APP, SEED, INC, EXC, ordering_exceptions=["TRADING-API-01 before TRADING-SQL-01"])
    prio = {r["name"]: pr["priority"] for pr in p["priorities"] for r in pr["resources"]}
    assert prio["TRADING-API-01"] < prio["TRADING-SQL-01"]
    with pytest.raises(ValueError):
        propose_sequence(engine(sim), APP, SEED, INC, EXC,
                         ordering_exceptions=["TRADING-WEB-01 before TRADING-SQL-01"])  # WEB waits for API waits for SQL


def test_tier_override_removes_confirmation_need(sim):
    p = propose_sequence(engine(sim), APP, SEED, INC, EXC, tier_overrides={"TRADING-WEB-01": "presentation"})
    assert {c["resource"] for c in p["classificationsNeedingConfirmation"]} == {"TRADING-API-01"}


def test_plan_hash_is_stable_and_order_sensitive(sim):
    a = propose_sequence(engine(sim), APP, SEED, INC, EXC)["planHash"]
    assert a == propose_sequence(engine(sim), APP, SEED, INC, EXC)["planHash"]
    assert a != propose_sequence(engine(sim), APP, SEED, INC, EXC,
                                 ordering_exceptions=["TRADING-API-01 before TRADING-SQL-01"])["planHash"]


# ---------------------------------------------------------------------- audit
def test_audit_flags_web_before_database_with_zero_input(sim):
    a = audit_recovery_group(engine(sim), "TradingDemo-Cleanroom")
    assert a["status"] == "ORDER_VIOLATIONS" and a["readOnly"]
    assert any(f["type"] == "order_violation" and f["finding"].startswith("TRADING-WEB-01") and "TRADING-SQL-01" in f["finding"]
               for f in a["findings"])
    assert any(f["type"] == "same_priority" for f in a["findings"])


def test_audit_compliant_group(sim):
    sim.recovery_groups["7"]["entities"] = [("TRADING-SQL-01", 1), ("TRADING-API-01", 2), ("TRADING-WEB-01", 3)]
    assert audit_recovery_group(engine(sim), "TradingDemo-Cleanroom")["status"] == "COMPLIANT"


def test_audit_with_baseline_detects_missing_member(sim):
    approve_default(sim)
    sim.recovery_groups["7"]["entities"] = [("TRADING-SQL-01", 1), ("TRADING-WEB-01", 3)]
    a = audit_recovery_group(engine(sim), "TradingDemo-Cleanroom", APP)
    assert any(f["type"] == "missing_from_group" and "TRADING-API-01" in f["finding"] for f in a["findings"])


def test_audit_unknown_group(sim):
    assert audit_recovery_group(engine(sim), "nope")["status"] == "GROUP_NOT_FOUND"


# ---------------------------------------------------------------------- drift
def test_no_baseline(sim):
    assert detect_drift(engine(sim), APP)["status"] == "NO_BASELINE"


def test_in_sync_right_after_approval(sim):
    approve_default(sim)
    assert detect_drift(engine(sim), APP)["status"] == "IN_SYNC"


def test_drift_detects_new_resource_removed_db_and_rpo_breach(sim):
    approve_default(sim)
    sim.apply_drift()
    d = detect_drift(engine(sim), APP)
    kinds = {(f["type"], f["resource"]) for f in d["findings"]}
    assert d["status"] == "DRIFT_DETECTED"
    assert ("new_unreviewed_resource", "TRADING-API-02") in kinds
    assert ("database_removed", "TRADING-SQL-01") in kinds
    assert ("rpo_breach", "TRADING-SQL-01") in kinds
    assert d["readOnly"] is True


def test_drift_detects_recovery_order_drift_for_new_middleware(sim):
    approve_default(sim)
    sim.apply_drift()
    f = [x for x in detect_drift(engine(sim), APP)["findings"]
         if x["type"] == "recovery_order_drift" and x["resource"] == "TRADING-KAFKA-01"][0]
    assert "middleware" in f["finding"] and "TRADING-API-01 must now wait" in f["finding"]
    assert "[TRADING-SQL-01] -> [TRADING-KAFKA-01]" in f["recommendedAction"]


def test_drift_detects_technology_change(sim):
    approve_default(sim)
    sim.clients["103"]["agents"].append("PostgreSQL")
    f = [x for x in detect_drift(engine(sim), APP)["findings"] if x["type"] == "technology_changed"]
    assert f and f[0]["resource"] == "TRADING-API-01" and "data tier" in f[0]["finding"]


def test_drift_detects_lost_air_gap_and_immutability(sim):
    approve_default(sim)
    sim.plans["1"]["backupDestinations"].pop()          # remove the Air Gap Protect copy
    sim.plans["1"]["backupDestinations"][0]["storagePool"]["isImmutable"] = False
    kinds = {f["type"] for f in detect_drift(engine(sim), APP)["findings"]}
    assert {"air_gap_lost", "immutability_lost", "copy_removed", "region_diversity_lost"} <= kinds


def test_drift_detects_unprotected_new_resource_as_critical(sim):
    approve_default(sim)
    sim._client("106", "TRADING-CACHE-01", True, ["11"], ["File System"], [], [])
    sim.groups["11"]["members"].append("106")
    f = [x for x in detect_drift(engine(sim), APP)["findings"] if x["resource"] == "TRADING-CACHE-01"][0]
    assert f["severity"] == "critical" and "NOT protected" in f["finding"]


def test_drift_detects_member_removed_from_commcell(sim):
    approve_default(sim)
    del sim.clients["103"]
    sim.groups["11"]["members"].remove("103")
    kinds = {(f["type"], f["resource"]) for f in detect_drift(engine(sim), APP)["findings"]}
    assert ("member_missing", "TRADING-API-01") in kinds


# ------------------------------------------------------------ MCP integration
@pytest.fixture
def mcp_with_sim(sim, monkeypatch):
    import sys, types
    # Importing the src.tools package instantiates the real CommServe client (env + OS keyring).
    # Stub it: these tests must never touch a real CommCell.
    stub = types.ModuleType("src.cv_api_client")
    stub.commvault_api_client = sim
    monkeypatch.setitem(sys.modules, "src.cv_api_client", stub)
    from fastmcp import FastMCP
    from fastmcp.tools import Tool
    import src.tools.recovery_tools as rt
    monkeypatch.setattr(rt, "_engine", lambda rpo_hours=24: engine(sim, rpo_hours))
    mcp = FastMCP("test")
    for fn in rt.RECOVERY_ASSURANCE_TOOLS:
        mcp.add_tool(Tool.from_function(fn, output_schema=None))
    return mcp


def _data(res):
    return json.loads(res.content[0].text)


async def _approve_via_mcp(mcp, handler):
    from fastmcp import Client
    kwargs = {"elicitation_handler": handler} if handler else {}
    async with Client(mcp, **kwargs) as c:
        plan = _data(await c.call_tool("generate_recovery_sequence", {
            "application_name": APP, "seed_resource": SEED, "include_candidates": INC, "exclude_candidates": EXC}))
        return plan, _data(await c.call_tool("approve_recovery_map", {
            "application_name": APP, "seed_resource": SEED, "plan_hash": plan["planHash"],
            "include_candidates": INC, "exclude_candidates": EXC}))


async def test_tools_register(mcp_with_sim):
    from fastmcp import Client
    async with Client(mcp_with_sim) as c:
        tools = {t.name: t for t in await c.list_tools()}
        assert set(tools) == {"discover_recovery_application", "generate_recovery_sequence", "approve_recovery_map",
                              "detect_recovery_drift", "audit_recovery_order", "list_recovery_scenarios",
                              "assess_blast_radius", "build_scenario_runbook", "import_security_context",
                              "preview_recovery_group", "create_recovery_group"}
        assert "ctx" not in tools["approve_recovery_map"].inputSchema.get("properties", {})
        assert "approved_by" not in tools["approve_recovery_map"].inputSchema.get("properties", {})


async def test_human_accepts_in_dialog(mcp_with_sim):
    seen = {}

    async def handler(message, response_type, params, context):
        seen["message"] = message
        return response_type(approver_name="Dana Lee")

    plan, r = await _approve_via_mcp(mcp_with_sim, handler)
    assert r["status"] == "APPROVED" and r["approvedBy"] == "Dana Lee" and r["approvalMethod"] == "mcp_elicitation"
    assert plan["planHash"] in seen["message"] and "P1: TRADING-SQL-01" in seen["message"]


async def test_human_declines_in_dialog(mcp_with_sim):
    from fastmcp.client.elicitation import ElicitResult

    async def handler(message, response_type, params, context):
        return ElicitResult(action="decline")

    _, r = await _approve_via_mcp(mcp_with_sim, handler)
    assert r["status"] == "NOT_APPROVED" and load_baseline(APP) is None


async def test_client_without_dialog_support_fails_closed(mcp_with_sim):
    # Depending on protocol version the server refuses (older) or the client errors on the dialog request (2026-07-28).
    try:
        _, r = await _approve_via_mcp(mcp_with_sim, None)
        assert r["status"] == "NOT_APPROVED"
    except Exception as e:
        assert "Elicitation not supported" in str(e)
    assert load_baseline(APP) is None


async def test_ai_cannot_forge_approval_by_retrying(mcp_with_sim):
    """Calling approve twice without a human answer never saves anything."""
    from fastmcp import Client
    async with Client(mcp_with_sim) as c:
        plan = _data(await c.call_tool("generate_recovery_sequence", {
            "application_name": APP, "seed_resource": SEED, "include_candidates": INC, "exclude_candidates": EXC}))
        for _ in range(2):
            try:
                await c.call_tool("approve_recovery_map", {"application_name": APP, "seed_resource": SEED,
                                  "plan_hash": plan["planHash"], "include_candidates": INC, "exclude_candidates": EXC})
            except Exception:
                pass
    assert load_baseline(APP) is None


async def test_host_mode_allows_approval_without_dialog(mcp_with_sim, monkeypatch):
    monkeypatch.setenv("RECOVERY_APPROVAL_MODE", "host")
    _, r = await _approve_via_mcp(mcp_with_sim, None)
    assert r["status"] == "APPROVED" and r["approvalMethod"] == "host_tool_approval"


# ------------------------------------------------------- security scenarios
from datetime import datetime, timezone
from pathlib import Path
from src.recovery.blast_radius import assess, validate_graph
from src.recovery.runbook import build_runbook, list_scenarios

GRAPH_FILE = Path(__file__).resolve().parent.parent / "demo" / "graphs" / "tradingdemo_identity_compromise.json"


def demo_graph(sim, hours_ago=50, **kw):
    g = json.loads(GRAPH_FILE.read_text())
    g["t0"] = datetime.fromtimestamp(sim.now - hours_ago * 3600, tz=timezone.utc).isoformat()
    g.update(kw)
    return g


def test_catalog_has_five_scenarios_and_no_backup_plane():
    ids = {s["id"] for s in list_scenarios()}
    assert ids == {"identity_compromise", "cloud_iam_compromise", "ransomware", "data_tampering", "malicious_update"}


def test_blast_radius_follows_control_edges_only(sim):
    br = assess(engine(sim), demo_graph(sim))
    names = {r["name"] for r in br["recoveryScope"]}
    assert names == {"CORP-DC-01", "TRADING-SQL-01", "TRADING-API-01", "TRADING-WEB-01"}
    assert "vm:HR-APP-01" not in {a["id"] for a in br["affectedNodes"]}      # reads_from is not control
    assert any(g["resource"] == "TRADING-CACHE-01" for g in br["gaps"])       # affected, not a Commvault client
    sql = [r for r in br["recoveryScope"] if r["name"] == "TRADING-SQL-01"][0]
    assert "[authenticates] vm:TRADING-SQL-01" in sql["evidence"][0]


def test_clean_point_is_before_cutoff(sim):
    br = assess(engine(sim), demo_graph(sim, hours_ago=50, dwellTimeHours=24))
    cutoff = sim.now - 74 * 3600
    for r in br["recoveryScope"]:
        cand = r["recoveryPoint"]["cleanCandidate"]
        done = int(datetime.fromisoformat(cand["completed"].replace("Z", "+00:00")).timestamp())
        assert done < cutoff and r["recoveryPoint"]["suspectPointsAfterCutoff"] >= 3


def test_no_clean_point_is_a_critical_gap(sim):
    br = assess(engine(sim), demo_graph(sim, hours_ago=300, dwellTimeHours=24))  # older than backup history
    assert any(g["severity"] == "critical" and "No successful backup before" in g["finding"] for g in br["gaps"])


def test_graph_validation():
    with pytest.raises(ValueError):
        validate_graph({"nodes": [], "edges": [], "compromised": []})
    with pytest.raises(ValueError):
        validate_graph({"nodes": [{"id": "a"}], "edges": [], "compromised": ["b"]})


def test_identity_runbook_dc_first_pre_cutoff_and_latest_flagged(sim):
    rb = build_runbook(engine(sim), "identity_compromise", demo_graph(sim), recovery_group_name="TradingDemo-Cleanroom")
    assert rb["status"] == "RUNBOOK_READY"
    assert rb["recoveryOrder"] == ["P1: CORP-DC-01", "P2: TRADING-SQL-01", "P3: TRADING-API-01", "P4: TRADING-WEB-01"]
    assert any(f["severity"] == "critical" and "LATEST" in f["finding"] for f in rb["recoveryGroupFindings"])
    assert any("CORP-DC-01 is in the recovery scope but not in recovery group" in f["finding"] for f in rb["recoveryGroupFindings"])
    phases = [p["phase"] for p in rb["phases"]]
    assert phases.index("contain") < phases.index("foundation") < phases.index("recover") < phases.index("reconnect")
    steps = [s for p in rb["phases"] for s in p["steps"]]
    assert [s["step"] for s in steps] == list(range(1, len(steps) + 1))
    assert any("KRBTGT" in s["title"] and not s["automatable"] for s in steps)
    assert "helpdesk-jdoe" in rb["phases"][0]["steps"][0]["detail"]
    assert "# Recovery runbook" in rb["markdown"]


def test_ransomware_uses_clean_latest(sim):
    rb = build_runbook(engine(sim), "ransomware", demo_graph(sim))
    rec = [s for p in rb["phases"] if p["phase"] == "recover" for s in p["steps"] if s["title"].startswith("P")]
    assert all("Threat Scan" in s["title"] for s in rec)
    assert not any("LATEST" in f["finding"] for f in rb["recoveryGroupFindings"])


def test_malicious_update_rebuilds_compute_and_restores_data_only(sim):
    rb = build_runbook(engine(sim), "malicious_update", demo_graph(sim))
    rec = {s["title"].split(" - ")[1].split(" ")[0]: s for p in rb["phases"] if p["phase"] == "recover"
           for s in p["steps"] if s["title"].startswith("P")}
    assert "Rebuild" in rec["TRADING-API-01"]["title"] and not rec["TRADING-API-01"]["automatable"]
    assert "DATA ONLY" in rec["TRADING-SQL-01"]["title"]


def test_data_tampering_restores_only_data_out_of_place(sim):
    rb = build_runbook(engine(sim), "data_tampering", demo_graph(sim))
    rec = [s for p in rb["phases"] if p["phase"] == "recover" for s in p["steps"] if s["title"].startswith("P")]
    restored = [s for s in rec if s["automatable"]]
    assert len(restored) == 1 and "TRADING-SQL-01" in restored[0]["title"] and "OUT OF PLACE" in restored[0]["title"]


def test_dependency_edges_override_tier_order(sim):
    g = demo_graph(sim)
    g["edges"].append({"from": "vm:TRADING-SQL-01", "to": "vm:TRADING-WEB-01", "rel": "depends_on"})  # unusual
    rb = build_runbook(engine(sim), "identity_compromise", g)
    assert any("Dependency hints ignored" in n for n in rb["notes"]) or rb["recoveryOrder"]


def test_unknown_scenario(sim):
    assert build_runbook(engine(sim), "alien_invasion", demo_graph(sim))["status"] == "UNKNOWN_SCENARIO"


async def test_scenario_tools_via_mcp(mcp_with_sim, sim):
    from fastmcp import Client
    async with Client(mcp_with_sim) as c:
        sc = _data(await c.call_tool("list_recovery_scenarios", {}))
        assert len(sc["scenarios"]) == 5
        rb = _data(await c.call_tool("build_scenario_runbook", {
            "scenario": "identity_compromise", "graph": demo_graph(sim),
            "recovery_group_name": "TradingDemo-Cleanroom"}))
        assert rb["recoveryOrder"][0] == "P1: CORP-DC-01" and rb["readOnly"]


# ------------------------------------------------------------ Wiz / Cortex adapters
from src.recovery.adapters.security_sources import build_graph, from_cortex_incident, from_wiz_graph
SAMPLES = Path(__file__).resolve().parent.parent / "demo" / "graphs"


def test_cortex_incident_maps_identity_scenario_and_t0():
    cx = from_cortex_incident(json.loads((SAMPLES / "sample_cortex_incident.json").read_text()))
    assert cx["suggestedScenario"] == "identity_compromise" and cx["incidentId"] == "4711"
    assert cx["compromisedUsers"] == ["svc-trading"] and cx["compromisedHosts"] == ["trading-api-01"]
    assert cx["t0"].startswith("2026-")                                   # earliest alert, not incident creation


def test_cortex_ransomware_category():
    cx = from_cortex_incident({"incident_id": "9", "alert_categories": ["Ransomware"], "users": ["a"], "creation_time": 1})
    assert cx["suggestedScenario"] == "ransomware"


def test_wiz_graph_maps_types_and_reports_unknowns():
    wz = from_wiz_graph(json.loads((SAMPLES / "sample_wiz_graph.json").read_text()))
    types = {n["name"]: n["type"] for n in wz["nodes"]}
    assert types["trading-prod-admin"] == "iam_role" and types["TRADING-SQL-01"] == "cloud_vm"
    assert wz["unmappedEntityTypes"] == ["SOMETHING_NEW"] and wz["unmappedRelationships"] == ["WEIRD_LINK"]


def test_wiz_graphsearch_rows_become_paths():
    rows = {"data": {"graphSearch": {"nodes": [{"entities": [
        {"id": "u", "type": "USER_ACCOUNT", "name": "bob"}, {"id": "r", "type": "ACCESS_ROLE", "name": "admin"},
        {"id": "v", "type": "VIRTUAL_MACHINE", "name": "TRADING-SQL-01"}]}]}}}
    wz = from_wiz_graph(rows)
    assert len(wz["edges"]) == 2 and all(e["rel"] == "can_write" for e in wz["edges"])


def test_cortex_plus_wiz_to_runbook_end_to_end(sim):
    imp = build_graph(json.loads((SAMPLES / "sample_cortex_incident.json").read_text()),
                      json.loads((SAMPLES / "sample_wiz_graph.json").read_text()), dwell_time_hours=24)
    assert imp["status"] == "IMPORTED" and imp["suggestedScenario"] == "identity_compromise"
    assert any("trading-api-01" in u for u in imp["report"]["unmatchedIncidentEntities"])  # host not in Wiz graph
    g = imp["graph"]
    g["t0"] = datetime.fromtimestamp(sim.now - 50 * 3600, tz=timezone.utc).isoformat()
    rb = build_runbook(engine(sim), imp["suggestedScenario"], g)
    names = {n for p in rb["recoveryOrder"] for n in p.split(": ", 1)[1].split(", ")}
    assert {"TRADING-SQL-01", "TRADING-WEB-01", "TRADING-API-01"} <= names
    assert any(g["resource"] == "trading-reports" for g in rb["blastRadius"]["gaps"])   # bucket not in Commvault


# ------------------------------------------- playbook derived from the incident (no scenario input)
def _cx(sim, categories, hours_ago=50):
    ms = (sim.now - hours_ago * 3600) * 1000
    return {"reply": {"incident": {"incident_id": "77", "alert_categories": categories, "users": ["CORP\\svc-trading"],
                                   "creation_time": ms},
                      "alerts": {"data": [{"detection_timestamp": ms, "category": categories[0],
                                           "user_name": "CORP\\svc-trading"}]}}}


async def test_playbook_derived_from_cortex_without_scenario(mcp_with_sim, sim):
    from fastmcp import Client
    wiz = json.loads((SAMPLES / "sample_wiz_graph.json").read_text())
    async with Client(mcp_with_sim) as c:
        rb = _data(await c.call_tool("build_scenario_runbook", {
            "cortex_incident": _cx(sim, ["Credential Access"]), "wiz_graph": wiz, "dwell_time_hours": 24}))
    assert rb["scenario"]["playbooks"] == ["identity_compromise"]
    assert rb["scenarioSelection"]["source"].startswith("derived from Cortex incident 77")
    assert "importReport" in rb and rb["status"] == "RUNBOOK_READY"


def test_chained_identity_then_ransomware_merges_playbooks(sim):
    from src.recovery.runbook import load_catalog, merge_scenarios
    m = merge_scenarios(load_catalog(), ["ransomware", "identity_compromise"])
    assert m["id"] == "identity_compromise+ransomware"                       # identity has precedence
    assert m["recoveryPointPolicy"] == "before_cutoff"                       # strictest wins over clean_latest
    titles = [st["title"] for ph in m["phases"] if ph["steps"] != "__RECOVERY_SEQUENCE__" for st in ph["steps"]]
    assert any("KRBTGT" in t for t in titles) and any("AV scan" in t for t in titles)
    assert len(titles) == len(set(titles))                                    # no duplicate steps


def test_cortex_multi_category_yields_chain():
    cx = from_cortex_incident({"incident_id": "1", "alert_categories": ["Credential Access", "Ransomware"],
                               "users": ["x"], "creation_time": 1})
    assert cx["matchedScenarios"] == ["ransomware", "identity_compromise"]


async def test_override_and_missing_scenario(mcp_with_sim, sim):
    from fastmcp import Client
    async with Client(mcp_with_sim) as c:
        none = _data(await c.call_tool("build_scenario_runbook", {"graph": demo_graph(sim)}))
        assert none["status"] == "NEEDS_SCENARIO"
        ov = _data(await c.call_tool("build_scenario_runbook", {
            "cortex_incident": _cx(sim, ["Credential Access"]), "scenario": "malicious_update"}))
        assert ov["scenario"]["playbooks"] == ["malicious_update"] and "override" in ov["scenarioSelection"]["source"]


# ------------------------------------------------- lab regressions (rebuilt 11.46 lab, 2026-10-20)
def _exchange_404(sim, with_jobs=True):
    """exchange1 on the 11.46 lab: GET subclient?clientId= -> 404, yet it IS protected by an Exchange agent subclient."""
    sim._client("109", "exchange1", True, [], ["Exchange Mailbox"],
                [("209", "default", "Exchange Mailbox", "", "1", [])], [-96 - 24 * d for d in range(10)] if with_jobs else [])
    orig = sim.get
    def get(ep, params=None):
        if ep == "subclient" and str((params or {}).get("clientId")) == "109":
            raise RuntimeError("404 Client Error: for url: .../subclient?clientId=109")
        return orig(ep, params)
    sim.get = get
    g = demo_graph(sim)
    g["nodes"].append({"id": "vm:exchange1", "type": "server", "commvaultClient": "exchange1"})
    g["edges"].append({"from": "domain:corp.local", "to": "vm:exchange1", "rel": "authenticates"})
    return g


def test_lab_404_subclients_but_backup_jobs_means_protected(sim):
    rb = build_runbook(engine(sim), "identity_compromise", _exchange_404(sim))
    assert not any(x["resource"] == "exchange1" for x in rb["blastRadius"]["gaps"])          # no false "not protected"
    ex = [st for p in rb["phases"] if p["phase"] == "recover" for st in p["steps"] if "exchange1" in st["title"]][0]
    assert "pre-cutoff" in ex["title"] and ex["automatable"]
    assert "job 10900" in ex["detail"] or "job" in ex["detail"]


def test_lab_404_subclients_and_no_jobs_means_verify_not_unprotected(sim):
    rb = build_runbook(engine(sim), "identity_compromise", _exchange_404(sim, with_jobs=False))
    gap = [x for x in rb["blastRadius"]["gaps"] if x["resource"] == "exchange1"][0]
    assert gap["severity"] == "medium" and "could not be determined" in gap["finding"]
    ex = [st for p in rb["phases"] if p["phase"] == "recover" for st in p["steps"] if "exchange1" in st["title"]][0]
    assert "verify in Command Center" in ex["title"] and not ex["automatable"]
    assert "to verify" in rb["summary"]


def test_unprotected_resource_is_rebuild_step(sim):
    sim._client("110", "TRADING-CACHE-02", True, [], ["File System"], [], [])
    g = demo_graph(sim)
    g["nodes"].append({"id": "vm:cache2", "type": "server", "commvaultClient": "TRADING-CACHE-02"})
    g["edges"].append({"from": "domain:corp.local", "to": "vm:cache2", "rel": "authenticates"})
    rb = build_runbook(engine(sim), "identity_compromise", g)
    st = [x for p in rb["phases"] if p["phase"] == "recover" for x in p["steps"] if "TRADING-CACHE-02" in x["title"]][0]
    assert "NOT PROTECTED" in st["title"] and not st["automatable"]
    assert "unprotected to rebuild" in rb["summary"]


def test_lab_unreadable_client_becomes_gap(sim):
    orig = sim.get
    def get(ep, params=None):
        if ep == "Agent" and str((params or {}).get("clientId")) == "103":
            raise RuntimeError("500 Server Error")
        return orig(ep, params)
    sim.get = get
    br = assess(engine(sim), demo_graph(sim))
    assert br["status"] == "ASSESSED"


def test_unreadable_recovery_point_setting_is_flagged(sim):
    orig = sim.get
    def get(ep, params=None):
        r = orig(ep, params)
        if ep == "RecoveryGroups":
            for g in r.get("recoveryGroups", []):
                g.pop("recoveryPointDetails", None)
        return r
    sim.get = get
    rb = build_runbook(engine(sim), "identity_compromise", demo_graph(sim), recovery_group_name="TradingDemo-Cleanroom")
    assert any("could not be read" in f["finding"] and "LATEST" in f["finding"] for f in rb["recoveryGroupFindings"])


# --------------------------------------- 11.46 lab shapes (probe of exchange1 + RecoveryGroup/3, 2026-10-20)
def test_lab_recovery_group_detail_priorities_and_numeric_latest(sim):
    """RecoveryGroup/<id>: entities[].executionOrder.priority; recoveryPointCategory 0 == LATEST."""
    sim.recovery_groups["7"]["entities"] = [("TRADING-API-01", 1), ("TRADING-SQL-01", 1)]   # like vmwlnx1 + vmwsql1
    a = audit_recovery_group(engine(sim), "TradingDemo-Cleanroom")
    assert a["status"] == "ORDER_VIOLATIONS"
    assert any(f["type"] == "same_priority" and "TRADING-SQL-01 (data)" in f["finding"] for f in a["findings"])
    rb = build_runbook(engine(sim), "identity_compromise", demo_graph(sim), recovery_group_name="TradingDemo-Cleanroom")
    assert any(f["severity"] == "critical" and "LATEST" in f["finding"] for f in rb["recoveryGroupFindings"])


def test_lab_exchange_protection_via_dag_pseudo_client(sim):
    """exchange1 (53): subclient list 404, no jobs; protection lives on DAG pseudo-client exchange1_1 (97)."""
    sim._client("197", "exchange1_1", False, [], ["Exchange Database"],
                [("300", "default", "Exchange Database", "defaultInstanceName", "1", ["Mailbox Database 1524003910"])],
                [-96 - 24 * d for d in range(10)])
    sim._client("153", "exchange1", False, [], [], [], [])
    sim.clients["153"]["dag"] = "197"
    orig = sim.get
    def get(ep, params=None):
        if ep == "subclient" and str((params or {}).get("clientId")) == "153":
            raise RuntimeError("404 Client Error: No VM groups found.")
        return orig(ep, params)
    sim.get = get
    d = engine(sim).discover("exchange1", "LabExchange")
    seed = by_name(d)["exchange1"]
    assert seed["protection"]["protected"] and "DAG pseudo-client" in seed["protection"]["protectionEvidence"]
    assert "Mailbox Database 1524003910" in d["summary"] and "exchange1_1" not in by_name(d)
    g = demo_graph(sim)
    g["nodes"].append({"id": "vm:exchange1", "type": "server", "commvaultClient": "exchange1"})
    g["edges"].append({"from": "domain:corp.local", "to": "vm:exchange1", "rel": "authenticates"})
    rb = build_runbook(engine(sim), "identity_compromise", g)
    st = [x for p in rb["phases"] if p["phase"] == "recover" for x in p["steps"] if "exchange1" in x["title"]][0]
    assert st["automatable"] and "job" in st["detail"] and not any(x["resource"] == "exchange1" for x in rb["blastRadius"]["gaps"])


# ------------------------------------------------------------------ Phase 2: create recovery group
from src.recovery.apply import desired_group, diff_against, eligibility, build_create_payload, render_preview


def _rb(sim, **kw):
    return build_runbook(engine(sim), "identity_compromise", demo_graph(sim, **kw), recovery_group_name="TradingDemo-Cleanroom")


def test_phase2_desired_group_members_priorities_and_points(sim):
    rb = _rb(sim)
    base = engine(sim).r.get_recovery_group("TradingDemo-Cleanroom")
    g = desired_group(rb, base, "IR-test")
    order = [(m["priority"], m["name"]) for m in g["members"]]
    assert order == [(1, "CORP-DC-01"), (2, "TRADING-SQL-01"), (3, "TRADING-API-01"), (4, "TRADING-WEB-01")]
    assert all(m["recoveryPoint"]["category"] == "POINT_IN_TIME" and m["recoveryPoint"]["jobId"] for m in g["members"])
    assert g["target"]["name"] == "Azure Sample Cleanroom" and g["target"]["id"] == 3
    assert g["recoveryPoint"]["category"] == "POINT_IN_TIME" and g["planHash"]


def test_phase2_app_level_only_is_not_eligible():
    m = {"name": "exchange1", "action": "restore_pre_cutoff", "protected": True, "protectionUnknown": False,
         "applications": ["Exchange Database"], "subclients": [{"appName": "Exchange Database"}]}
    ok, why = eligibility(m)
    assert not ok and "no VM-level backup" in why and "Exchange Database" in why


def test_phase2_diff_against_existing_group(sim):
    rb = _rb(sim)
    base = engine(sim).r.get_recovery_group("TradingDemo-Cleanroom")
    diff = diff_against(desired_group(rb, base, "IR-test"), base)
    assert any(d.startswith("+ CORP-DC-01") for d in diff)
    assert any("TRADING-WEB-01: priority 1" in d for d in diff)
    assert any("LATEST" in d and "POINT_IN_TIME" in d for d in diff)
    text = render_preview(desired_group(rb, base, "IR-test"), diff)
    assert "Creates a NEW group only" in text


def test_phase2_payload_shape_is_isolated_and_marked(sim):
    g = desired_group(_rb(sim), engine(sim).r.get_recovery_group("TradingDemo-Cleanroom"), "IR-test")
    from src.recovery.apply import build_create_steps
    steps = build_create_steps(g)
    assert [x["endpoint"] for x in steps] == ["V4/ServerGroup", "ClientGroup/{assemblyId}", "Cleanroom/Runbook", "RecoveryGroup",
                                              "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}",
                                              "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}/SkipRecovery/Enable"]
    assert all(x["validated"] for x in steps) and len(steps) == 6                    # all from 11.46 captures
    assert steps[2]["body"]["entities"] == [] and steps[2]["body"]["target"] == {"entity": {"id": 3}}
    p = build_create_payload(g)
    assert p["name"] == "IR-test" and len(p["entities"]) == 4
    assert p["entities"][0]["recoveryConfiguration"]["executionOrder"]["priority"] == 1


def test_phase2_ransomware_group_uses_latest_clean(sim):
    rb = build_runbook(engine(sim), "ransomware", demo_graph(sim))
    g = desired_group(rb, None, "IR-r")
    assert all(m["recoveryPoint"]["category"] == "LATEST_CLEAN_REQUIRES_THREAT_SCAN" for m in g["members"])


async def test_phase2_preview_tool_is_read_only(mcp_with_sim, sim):
    from fastmcp import Client
    async with Client(mcp_with_sim) as c:
        pv = _data(await c.call_tool("preview_recovery_group", {
            "base_recovery_group_name": "TradingDemo-Cleanroom", "graph": demo_graph(sim), "scenario": "identity_compromise"}))
    assert pv["status"] == "PREVIEW" and pv["readOnly"] and pv["planHash"] and pv["payloadValidated"] is True
    assert not hasattr(sim, "post")


async def test_phase2_create_is_disabled_by_default(mcp_with_sim, sim, monkeypatch):
    from fastmcp import Client
    monkeypatch.delenv("RECOVERY_WRITE_ENABLED", raising=False)
    async with Client(mcp_with_sim) as c:
        r = _data(await c.call_tool("create_recovery_group", {
            "base_recovery_group_name": "TradingDemo-Cleanroom", "plan_hash": "x", "graph": demo_graph(sim),
            "scenario": "identity_compromise"}))
    assert r["status"] == "WRITE_DISABLED"


async def test_phase2_create_flow_with_approval_and_hash(mcp_with_sim, sim, monkeypatch):
    from fastmcp import Client
    import src.tools.recovery_tools as rt
    from src.recovery.apply import GuardedWriter
    sent = []

    # Stateful fake CommCell for the write path. Entities as Commvault 11.46 creates them: one per VM (entity.id =
    # client id) plus a file-system entity whose client is the VM; all at priority 1.
    # As in the 11.46 lab: the domain controller is protected at file level only (one 'default' file-system entity),
    # the SQL VM has a VM entity plus a redundant file-system entity. workload 8 = VM, 9 = file system.
    ents = {12: {"id": 12, "name": "TRADING-SQL-01", "entity": {"id": 102}, "client": {"name": "ESX1"}, "executionOrder": {"priority": 1},
                 "workload": 8, "virtualMachine": {}, "skipRecovery": False,
                 "subEntities": [{"name": "SQL instance"}],
                 "restoreEligibility": {"isEligible": False, "ineligibleReason": "The last full backup copy is more than [45] days old."}},
            13: {"id": 13, "name": "default", "entity": {"id": 7102}, "client": {"name": "TRADING-SQL-01"}, "executionOrder": {"priority": 1},
                 "workload": 9, "skipRecovery": False},
            16: {"id": 16, "name": "default", "entity": {"id": 7108}, "client": {"name": "CORP-DC-01"}, "executionOrder": {"priority": 1},
                 "workload": 9, "skipRecovery": False},
            14: {"id": 14, "name": "TRADING-API-01", "entity": {"id": 103}, "client": {"name": "ESX1"}, "executionOrder": {"priority": 1},
                 "workload": 8, "virtualMachine": {}, "skipRecovery": False},
            15: {"id": 15, "name": "TRADING-WEB-01", "entity": {"id": 101}, "client": {"name": "ESX1"}, "executionOrder": {"priority": 1},
                 "workload": 8, "virtualMachine": {}, "skipRecovery": False}}
    grp = {"id": 4, "name": "IR-test", "vendor": 7, "useAutoScale": True,     # Commvault turns it on for file entities
           "recoveryPointDetails": {"recoveryPointCategory": 0, "recoveryPoint": 0}}

    class FakeWriter(GuardedWriter):
        def __init__(self):
            super().__init__("https://x", "t")
        def send(self, method, endpoint, body, template=None):
            key = (method, template or endpoint)
            assert key in self.allow, key
            if template and "{entityId}" in template:
                assert int(endpoint.split("/Entity/")[1].split("/")[0]) in self._known_entities
            sent.append((method, endpoint, body))
            if endpoint == "V4/ServerGroup":
                return {"serverGroupInfo": {"id": 27, "name": body["name"]}}
            if endpoint.startswith("ClientGroup/"):
                return {"errorMessage": "Server group updated successfully", "errorCode": 0}
            if endpoint == "Cleanroom/Runbook":
                return {"recoveryGroup": {"id": 4, "name": body["name"]}, "error": {}}
            if method == "GET":
                return {"recoveryGroup": dict(grp), "entities": [json.loads(json.dumps(e)) for e in ents.values()]}
            if method == "PUT" and endpoint == "RecoveryGroup":
                grp["useAutoScale"] = body["useAutoScale"]
                return {"recoveryGroup": {"id": 4}, "error": {}}
            if method == "PUT" and endpoint.endswith("/SkipRecovery/Enable"):
                assert body is None
                ents[int(endpoint.split("/Entity/")[1].split("/")[0])]["skipRecovery"] = True
                return {"errorMessage": "", "errorCode": 0}
            if method == "PUT" and "/Entity/" in endpoint:
                eid = int(endpoint.rsplit("/", 1)[-1])
                assert "subEntities" not in body and body["id"] == eid
                ents[eid]["executionOrder"] = {"priority": body["executionOrder"]["priority"]}
                return {"errorMessage": "", "errorCode": 0}
    monkeypatch.setattr(rt.GuardedWriter, "from_environment", classmethod(lambda cls: FakeWriter()))
    seen = {}

    async def handler(message, response_type, params, context):
        seen["msg"] = message
        return response_type(approver_name="Dana Lee")

    args = {"base_recovery_group_name": "TradingDemo-Cleanroom", "graph": demo_graph(sim),
            "scenario": "identity_compromise", "new_group_name": "IR-test"}
    async with Client(mcp_with_sim, elicitation_handler=handler) as c:
        pv = _data(await c.call_tool("preview_recovery_group", args))
        bad = _data(await c.call_tool("create_recovery_group", {**args, "plan_hash": "deadbeef"}))
        assert bad["status"] == "PLAN_CHANGED" and not sent
        ok = _data(await c.call_tool("create_recovery_group", {**args, "plan_hash": pv["planHash"]}))
    assert ok["status"] == "CREATED" and ok["assemblyId"] == 27 and ok["recoveryGroupId"] == 4 and ok["approvedBy"] == "Dana Lee"
    assert ok["verifiedPriorities"] == {"TRADING-SQL-01": 2, "default (TRADING-SQL-01)": 2, "default (CORP-DC-01)": 1,
                                     "TRADING-API-01": 3, "TRADING-WEB-01": 4}   # lab: two 'default' entities
    put_rg = [b for m, e, b in sent if (m, e) == ("PUT", "RecoveryGroup")][0]
    assert put_rg["useAutoScale"] is False and ok["autoScale"] is False      # all-custom infrastructure, no mismatch
    assert ok["skippedEntities"] == ["default (TRADING-SQL-01)"] and ents[13]["skipRecovery"] and not ents[16]["skipRecovery"]
    assert ok["recoveredAsFilesOnly"] == ["CORP-DC-01"] and "working domain controller" in ok["warnings"][0]
    assert not ok["priorityMismatches"] and "45" in ok["commvaultReadiness"]["TRADING-SQL-01"]
    calls = [(x[0], x[1]) for x in sent]
    assert calls[:5] == [("POST", "V4/ServerGroup"), ("POST", "ClientGroup/27"), ("POST", "Cleanroom/Runbook"),
                         ("GET", "RecoveryGroup/4"), ("PUT", "RecoveryGroup")]
    assert set(calls[5:-2]) == {("PUT", "RecoveryGroup/4/Entity/12"), ("PUT", "RecoveryGroup/4/Entity/13"),
                                ("PUT", "RecoveryGroup/4/Entity/14"), ("PUT", "RecoveryGroup/4/Entity/15")}   # DC already P1
    assert calls[-2] == ("PUT", "RecoveryGroup/4/Entity/13/SkipRecovery/Enable")       # skip comes after priorities
    assert calls[-1] == ("GET", "RecoveryGroup/4")
    assert sent[2][2]["assembly"] == {"id": 27} and sent[2][2]["entities"] == []
    put = sent[4][2]
    assert put["id"] == 4 and put["recoveryPointDetails"]["recoveryPointCategory"] == "POINT_IN_TIME"
    assert put["recoveryPointDetails"]["recoveryPoint"] > 0 and put["threatScan"]["enableThreatScan"] is True
    assert sent[0][2] == {"name": "IR-test", "serverGroupType": "MANUAL",
                          "manualAssociation": {"associatedservers": [{"id": 108}, {"id": 102}, {"id": 103}, {"id": 101}]}}
    assert sent[1][2]["clientGroupDetail"]["configurationGroupType"] == 2 and "IR-test" in seen["msg"]


def test_phase2_writer_refuses_put_on_other_recovery_group():
    from src.recovery.apply import GuardedWriter, WriteDisabled
    w = GuardedWriter("https://x", "t")
    w._created_rg = 4
    with pytest.raises(WriteDisabled):
        w.send("PUT", "RecoveryGroup", {"id": 3})        # Sample Application 1's group: never


def test_phase2_preview_warns_identity_server_files_only():
    from src.recovery.apply import desired_group, render_preview
    rb = {"scenario": {"id": "identity_compromise", "recoveryPointPolicy": "before_cutoff"}, "cleanCutoff": "2026-10-18T00:00:00Z",
          "recoveryPlan": [
              {"name": "dc1", "clientId": 2, "tier": "foundation", "priority": 1, "action": "restore_pre_cutoff", "protected": True,
               "subclients": [{"name": "default", "appName": "File System"}],
               "cleanPoint": {"jobId": 1, "completed": "2026-10-16T19:08:32Z"}},
              {"name": "vmwlnx1", "clientId": 3, "tier": "application", "priority": 3, "action": "restore_pre_cutoff", "protected": True,
               "subclients": [{"name": "vms", "appName": "Virtual Server"}],
               "cleanPoint": {"jobId": 2, "completed": "2026-10-16T18:41:24Z"}}]}
    g = desired_group(rb, {"name": "base", "targetId": 3, "target": "Azure"}, "IR", {"2": "dc1", "3": "vmwlnx1"})
    assert len(g["warnings"]) == 1 and g["warnings"][0].startswith("CRITICAL: dc1")
    assert "working domain controller" in render_preview(g, [])


def test_phase2_skip_endpoint_bound_to_own_entities():
    from src.recovery.apply import GuardedWriter, WriteDisabled
    w = GuardedWriter("https://x", "t")
    w._created_rg, w._known_entities = 4, {6, 7}
    t = "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}/SkipRecovery/Enable"
    with pytest.raises(WriteDisabled):
        w.send("PUT", "RecoveryGroup/4/Entity/99/SkipRecovery/Enable", None, template=t)
    with pytest.raises(WriteDisabled):
        w.send("PUT", "RecoveryGroup/3/Entity/6/SkipRecovery/Enable", None, template=t)
    with pytest.raises(WriteDisabled):                    # disable/other verbs are not on the allowlist
        w.send("PUT", "RecoveryGroup/4/Entity/6/SkipRecovery/Disable", None)


def test_phase2_writer_refuses_entity_of_other_group():
    from src.recovery.apply import GuardedWriter, WriteDisabled
    w = GuardedWriter("https://x", "t")
    w._created_rg, w._known_entities = 4, {3, 4, 5}
    with pytest.raises(WriteDisabled):
        w.send("PUT", "RecoveryGroup/4/Entity/99", {"id": 99}, template="RecoveryGroup/{recoveryGroupId}/Entity/{entityId}")
    with pytest.raises(WriteDisabled):
        w.send("PUT", "RecoveryGroup/3/Entity/4", {"id": 4}, template="RecoveryGroup/{recoveryGroupId}/Entity/{entityId}")


def test_lab_entity_not_ready_is_reported(sim):
    orig = sim.get
    def get(ep, params=None):
        r = orig(ep, params)
        if ep.startswith("RecoveryGroup/"):
            r["entities"][0]["restoreEligibility"] = {"isEligible": False, "ineligibleReason": "The last full backup copy is more than [45] days old."}
        return r
    sim.get = get
    rb = build_runbook(engine(sim), "identity_compromise", demo_graph(sim), recovery_group_name="TradingDemo-Cleanroom")
    assert any("NOT ready for recovery" in f["finding"] and "45" in f["finding"] for f in rb["recoveryGroupFindings"])


def test_phase2_writer_refuses_foreign_group_id():
    from src.recovery.apply import GuardedWriter, WriteDisabled
    w = GuardedWriter("https://x", "t")
    w._created_assembly = 27
    with pytest.raises(WriteDisabled):
        w.send("POST", "ClientGroup/25", {}, template="ClientGroup/{assemblyId}")   # Sample Application 1: never


def test_phase2_cleanroom_list_drives_eligibility(sim):
    rb = _rb(sim)
    base = engine(sim).r.get_recovery_group("TradingDemo-Cleanroom")
    sim.cleanroom_supported = ["108", "102"]          # DC (AD agent, not a VM) and SQL only
    g = desired_group(rb, base, "IR-x", engine(sim).r.get_cleanroom_supported())
    assert [m["name"] for m in g["members"]] == ["CORP-DC-01", "TRADING-SQL-01"]
    assert all("does not offer" in x["reason"] for x in g["excluded"])
    assert g["eligibilitySource"].startswith("Command Center")


def test_phase2_falls_back_when_cleanroom_list_unavailable(sim):
    sim.cleanroom_supported = None
    assert engine(sim).r.get_cleanroom_supported() is None
    g = desired_group(_rb(sim), None, "IR-y", None)
    assert g["eligibilitySource"].startswith("fallback")


async def test_phase2_create_refused_when_human_declines(mcp_with_sim, sim, monkeypatch):
    from fastmcp import Client
    from fastmcp.client.elicitation import ElicitResult
    import src.tools.recovery_tools as rt
    sent = []
    monkeypatch.setattr(rt.GuardedWriter, "from_environment",
                        classmethod(lambda cls: type("W", (), {"send": lambda self, *a, **k: sent.append(a)})()))

    async def handler(message, response_type, params, context):
        return ElicitResult(action="decline")
    args = {"base_recovery_group_name": "TradingDemo-Cleanroom", "graph": demo_graph(sim), "scenario": "identity_compromise"}
    async with Client(mcp_with_sim, elicitation_handler=handler) as c:
        pv = _data(await c.call_tool("preview_recovery_group", args))
        r = _data(await c.call_tool("create_recovery_group", {**args, "plan_hash": pv["planHash"]}))
    assert r["status"] == "NOT_APPROVED" and not sent


def test_phase2_writer_allowlist():
    from src.recovery.apply import GuardedWriter, WriteDisabled
    w = GuardedWriter("https://x", "t")
    with pytest.raises(WriteDisabled):
        w.send("DELETE", "RecoveryGroup/3", {})
    with pytest.raises(WriteDisabled):
        w.send("POST", "Cleanroom/Runbook/3/Launch", {})


# ------------------------------------------- Microsoft: Defender XDR incident + Exposure Management blast radius
LAB_DEF = Path(__file__).resolve().parent.parent / "lab" / "defender"


def test_defender_xdr_incident_maps_identity_users_hosts_t0():
    from src.recovery.adapters.security_sources import from_defender_incident
    d = from_defender_incident(json.loads((LAB_DEF / "incident_dc1_identity.json").read_text()))
    assert d["incidentId"] == 41077 and d["suggestedScenario"] == "identity_compromise"
    assert d["compromisedUsers"] == ["svc-sql"]                         # NT AUTHORITY\SYSTEM ignored
    assert d["compromisedHosts"] == ["dc1", "vmwwin1"]                  # FQDN -> host name
    assert d["t0"] == "2026-10-19T15:00:03Z"                            # earliest alert activity
    assert "T1003.006" in d["mitreTechniques"]


def test_defender_graph_api_evidence_form():
    from src.recovery.adapters.security_sources import from_defender_incident
    inc = {"id": "28282", "displayName": "Ransomware activity on multiple endpoints", "createdDateTime": "2026-10-19T10:00:00Z",
           "alerts": [{"category": "Impact", "mitreTechniques": ["T1486"], "title": "Ransomware behavior detected",
                       "firstActivityDateTime": "2026-10-19T09:41:00Z",
                       "evidence": [
                           {"@odata.type": "#microsoft.graph.security.deviceEvidence", "hostName": "vmwsql1",
                            "deviceDnsName": "vmwsql1.cv.lab", "roles": ["compromised"]},
                           {"@odata.type": "#microsoft.graph.security.userEvidence", "roles": ["compromised"],
                            "userAccount": {"accountName": "svc-sql", "domainName": "CV", "userPrincipalName": "svc-sql@cv.lab"}},
                           {"@odata.type": "#microsoft.graph.security.processEvidence",
                            "userAccount": {"accountName": "SYSTEM", "domainName": "NT AUTHORITY"}}]}]}
    d = from_defender_incident({"value": [inc]})
    assert d["suggestedScenario"] == "ransomware" and d["compromisedHosts"] == ["vmwsql1"]
    assert d["compromisedUsers"] == ["svc-sql"] and d["evidenceRoles"]["vmwsql1"] == ["compromised"]
    assert d["t0"] == "2026-10-19T09:41:00Z"


def test_exposure_graph_rows_map_and_ignore_vulnerability_edges():
    from src.recovery.adapters.security_sources import from_exposure_graph
    g = from_exposure_graph(json.loads((LAB_DEF / "exposure_dc1_identity.json").read_text()))
    rels = {(e["msemRel"], e["rel"]) for e in g["edges"]}
    assert ("frequently logged in by", "has_credentials_for") in rels and ("member of", "member_of") in rels
    assert not any(e["msemRel"] == "affecting" for e in g["edges"]) and not g["unmappedRelationships"]
    dc = next(n for n in g["nodes"] if n["name"] == "dc1.cv.lab")
    assert dc["type"] == "server" and dc["commvaultClient"] == "dc1"
    assert from_exposure_graph([{"EdgeLabel": "CanRemoteInteractiveLogonTo", "SourceNodeId": "a", "SourceNodeName": "u",
                                 "SourceNodeLabel": "user", "TargetNodeId": "b", "TargetNodeName": "h",
                                 "TargetNodeLabel": "device"}])["edges"][0]["rel"] == "can_login_to"   # camelCase label


def test_defender_plus_exposure_blast_radius_reaches_dc_through_credentials():
    from src.recovery.blast_radius import traverse, validate_graph
    imp = build_graph(defender_incident=json.loads((LAB_DEF / "incident_dc1_identity.json").read_text()),
                      exposure_graph=json.loads((LAB_DEF / "exposure_dc1_identity.json").read_text()))
    assert imp["status"] == "IMPORTED" and imp["incidentSource"] == "Defender"
    assert imp["matchedScenarios"] == ["identity_compromise"] and not imp["report"]["unmatchedIncidentEntities"]
    nodes, edges, comp, _ = validate_graph(imp["graph"])
    reach = {nodes[n].get("commvaultClient") for n in traverse(nodes, edges, comp)} - {None}
    # svc-sql -> vmwsql1; svc-sql -> SQL Admins -> vmwwin1 -> (cached creds) adm-dave -> Domain Admins -> dc1, exchange1
    assert {"vmwsql1", "vmwwin1", "dc1", "exchange1"} <= reach and "vmwlnx1" not in reach


def test_defender_incident_alone_scopes_hosts_and_combines_with_wiz():
    imp = build_graph(defender_incident=json.loads((LAB_DEF / "incident_dc1_identity.json").read_text()),
                      wiz_graph=json.loads((SAMPLES / "sample_wiz_graph.json").read_text()))
    assert imp["report"]["reachabilitySources"] == ["Wiz"]
    assert any("from Defender not found in Wiz" in u for u in imp["report"]["unmatchedIncidentEntities"])
    assert "defender:server:dc1" in imp["graph"]["compromised"]


async def test_playbook_derived_from_defender_via_mcp(mcp_with_sim, sim):
    from fastmcp import Client
    t0 = datetime.fromtimestamp(sim.now - 50 * 3600, tz=timezone.utc).isoformat()
    inc = {"incidentId": 9, "incidentName": "Credential access on a domain controller",
           "alerts": [{"category": "CredentialAccess", "mitreTechniques": ["T1003.006"], "firstActivity": t0,
                       "title": "Suspected DCSync attack", "devices": [{"deviceDnsName": "corp-dc-01.corp.local"}],
                       "entities": [{"entityType": "User", "accountName": "svc-trading", "userPrincipalName": "svc-trading@corp.local"}]}]}
    rows = [{"EdgeLabel": "can logon over the network to", "SourceNodeId": "u1", "SourceNodeName": "svc-trading@corp.local",
             "SourceNodeLabel": "user", "TargetNodeId": "d1", "TargetNodeName": "TRADING-SQL-01.corp.local", "TargetNodeLabel": "device"}]
    async with Client(mcp_with_sim) as c:
        rb = _data(await c.call_tool("build_scenario_runbook", {"defender_incident": inc, "exposure_graph": rows,
                                                                "dwell_time_hours": 24}))
    assert rb["status"] == "RUNBOOK_READY" and rb["scenario"]["playbooks"] == ["identity_compromise"]
    assert rb["scenarioSelection"]["source"].startswith("derived from Defender incident 9")
    plan = {m["name"] for m in rb["recoveryPlan"]}
    assert {"CORP-DC-01", "TRADING-SQL-01"} <= plan
