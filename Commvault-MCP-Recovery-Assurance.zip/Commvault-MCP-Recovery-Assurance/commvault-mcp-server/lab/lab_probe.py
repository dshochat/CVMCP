"""
Read-only lab probe for the Recovery Assurance tools.

Calls every Commvault REST endpoint the tools depend on (GET only), saves the raw
responses to lab/probe_output/, then runs discovery + sequencing against the live
CommCell and saves the results. Nothing is changed on the CommCell.

The token/password is read interactively and NEVER written to disk or to the output.

Usage (from the repo root, after `uv run setup.py`):
    uv run lab\\lab_probe.py --seed <CLIENT-NAME> [--app <ApplicationName>] [--group <Cleanroom recovery group>]

    Without --url it uses the MCP server's own configuration (recommended).
    --url https://<host> [--insecure] instead prompts for credentials (nothing saved).
"""

import argparse
import base64
import getpass
import json
import os
import re
import sys
import time
import traceback
from pathlib import Path

import requests

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent / "probe_output"
sys.path.insert(0, str(ROOT))

SECRET_KEYS = re.compile(r"(token|password|secret|accesskey|refresh)", re.I)


def scrub(obj):
    """Remove anything that looks like a credential from saved responses."""
    if isinstance(obj, dict):
        return {k: ("<redacted>" if SECRET_KEYS.search(k) and isinstance(v, str) else scrub(v)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [scrub(x) for x in obj]
    return obj


class LabApi:
    """GET-only client with the same .get(endpoint, params) shape the tools use.

    mcp mode (default): uses the Commvault MCP server's own configuration (.env + Windows Credential
    Manager written by `uv run setup.py`), i.e. exactly what the MCP server will use.
    url mode: --url given; prompts for a token or username/password (nothing saved).
    """

    def __init__(self, url, verify):
        self.mcp_client = None
        self.base = (url.rstrip("/") + "/commandcenter/api/") if url else None
        self.verify = verify
        self.headers = {"Accept": "application/json", "User-Agent": "cv-recovery-lab-probe/0.1"}
        self.log = []
        self.n = 0

    # -- auth (interactive; nothing persisted) --------------------------------
    def authenticate(self):
        print("\nAuthentication (nothing is saved):")
        print("  1) Access token generated in Command Center")
        print("  2) Username + password")
        choice = input("Choose 1 or 2 [1]: ").strip() or "1"
        if choice == "2":
            user = input("  Username: ").strip()
            pw = getpass.getpass("  Password: ")
            r = requests.post(self.base + "Login", json={"username": user, "password": base64.b64encode(pw.encode()).decode()},
                              headers={"Accept": "application/json", "Content-Type": "application/json"}, verify=self.verify, timeout=60)
            r.raise_for_status()
            tok = r.json().get("token")
            if not tok:
                raise SystemExit(f"Login failed: {scrub(r.json())}")
            self.headers["Authtoken"] = tok
        else:
            tok = getpass.getpass("  Access token: ").strip()
            self.headers["Authorization"] = f"Bearer {tok}"
            if self._raw("GET", "Client").status_code == 401:  # older token style
                del self.headers["Authorization"]
                self.headers["Authtoken"] = tok
        r = self._raw("GET", "Client")
        if r.status_code != 200:
            raise SystemExit(f"Authentication check failed: HTTP {r.status_code} {r.text[:200]}")
        print("  Authenticated.\n")

    def use_mcp_config(self):
        from src.cv_api_client import commvault_api_client  # reads .env + keyring like the MCP server
        self.mcp_client = commvault_api_client
        print(f"Using the Commvault MCP configuration: {commvault_api_client.base_url}")

    def _raw(self, method, endpoint, params=None):
        if self.mcp_client is not None:
            return _McpResponse(self.mcp_client, endpoint, params)
        return requests.request(method, self.base + endpoint, headers=self.headers, params=params,
                                verify=self.verify, timeout=120)

    # -- probe + save ----------------------------------------------------------
    def get(self, endpoint, params=None, headers=None):
        self.n += 1
        t = time.time()
        try:
            r = self._raw("GET", endpoint, params)
            ms = int((time.time() - t) * 1000)
            try:
                body = r.json()
            except ValueError:
                body = {"_nonJson": r.text[:2000]}
        except Exception as e:
            r, ms, body = None, int((time.time() - t) * 1000), {"_exception": str(e)}
        status = r.status_code if r is not None else "ERR"
        fname = f"{self.n:03d}_{re.sub(r'[^A-Za-z0-9]+', '_', endpoint)[:60]}.json"
        (OUT / fname).write_text(json.dumps({"endpoint": endpoint, "params": params, "status": status,
                                             "ms": ms, "response": scrub(body)}, indent=2), encoding="utf-8")
        self.log.append({"n": self.n, "endpoint": endpoint, "params": params, "status": status, "ms": ms, "file": fname})
        print(f"  [{status}] {ms:>5} ms  GET {endpoint} {params or ''}")
        if status != 200:
            raise RuntimeError(f"HTTP {status} for {endpoint}")
        return body


class _McpResponse:
    """Adapts the MCP client's parsed-JSON result to the small Response surface the probe uses."""
    def __init__(self, client, endpoint, params):
        try:
            self._json = client.request("GET", endpoint, params=params, max_retries=0)
            self.status_code, self.text = 200, ""
        except requests.exceptions.HTTPError as e:
            self.status_code = e.response.status_code if e.response is not None else 0
            self.text = e.response.text[:2000] if e.response is not None else str(e)
            self._json = None
        except Exception as e:
            self.status_code, self.text, self._json = 0, str(e), None

    def json(self):
        if self._json is None:
            raise ValueError(self.text)
        return self._json


def try_get(api, endpoint, params=None):
    try:
        return api.get(endpoint, params)
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="", help="Only if NOT using the MCP setup: Command Center host, e.g. https://cs01")
    ap.add_argument("--seed", required=True, help="Commvault client name of one production resource")
    ap.add_argument("--app", default="", help="Business application name")
    ap.add_argument("--group", default="", help="Existing Cleanroom recovery group to audit")
    ap.add_argument("--insecure", action="store_true")
    a = ap.parse_args()

    if a.insecure:
        import urllib3
        urllib3.disable_warnings()
    OUT.mkdir(parents=True, exist_ok=True)
    for f in OUT.glob("*.json"):
        f.unlink()

    api = LabApi(a.url, verify=not a.insecure)
    if a.url:
        api.authenticate()
    else:
        api.use_mcp_config()
        if api._raw("GET", "Client").status_code != 200:
            raise SystemExit("Could not reach the CommCell with the MCP configuration. Re-run `uv run setup.py` "
                             "(check CC_SERVER_URL in .env, tokens, and SSL_VERIFY=false for a self-signed lab cert).")
        print("  Connected.\n")

    # ---- Part 1: raw endpoint probe (exactly what cv_reader.py relies on) ----
    print("Part 1 - raw endpoints")
    try_get(api, "getid", {"clientname": a.seed})
    clients = try_get(api, "Client") or {}
    cid = None
    for c in clients.get("clientProperties", []):
        e = c.get("client", {}).get("clientEntity", {})
        if str(e.get("clientName", "")).lower() == a.seed.lower() or str(e.get("displayName", "")).lower() == a.seed.lower():
            cid = e.get("clientId")
    if cid is None:
        print(f"\n  !! Seed '{a.seed}' not found by name in Client list. Check spelling (see output 002).")
    else:
        client = try_get(api, f"Client/{cid}") or {}
        try_get(api, "Agent", {"clientId": cid})
        subs = try_get(api, "subclient", {"clientId": cid}) or {}
        plan_ids = set()
        for sc in subs.get("subClientProperties", [])[:10]:
            scid = sc.get("subClientEntity", {}).get("subclientId")
            d = try_get(api, f"subclient/{scid}") or {}
            for p in d.get("subClientProperties", []):
                if (p.get("planEntity") or {}).get("planId"):
                    plan_ids.add(p["planEntity"]["planId"])
        for pid in list(plan_ids)[:5]:
            if try_get(api, f"v4/serverplan/{pid}") is None:
                try_get(api, f"v4/plan/summary/{pid}")
        try_get(api, "Job", {"clientId": cid, "jobFilter": "Backup", "completedJobLookupTime": 7 * 24 * 3600})
        for g in (client.get("clientProperties") or [{}])[0].get("clientGroups", [])[:5]:
            try_get(api, f"ClientGroup/{g.get('clientGroupId')}")

    print("\n  Recovery groups (path not documented - trying candidates):")
    rg_path = None
    for path in ["V4/RecoveryGroups", "v4/recoverygroups", "V4/RecoveryGroup", "RecoveryGroups", "recoveryGroups"]:
        if try_get(api, path) is not None:
            rg_path = path
            break
    if rg_path and a.group:
        lst = json.loads((OUT / api.log[-1]["file"]).read_text())["response"]
        gid = next((g.get("id") for g in lst.get("recoveryGroups", []) if str(g.get("name", "")).lower() == a.group.lower()), None)
        if gid:
            try_get(api, f"{rg_path}/{gid}", {"getEntityDetails": "true"})
        else:
            print(f"  !! Recovery group '{a.group}' not found in list.")

    # ---- Part 2: run the actual tools against the lab ------------------------
    print("\nPart 2 - Recovery Assurance tools against the live lab")
    os.environ.setdefault("RECOVERY_BASELINE_DIR", str(OUT / "baselines"))
    summary = {}
    try:
        from src.recovery.cv_reader import CommvaultReader
        from src.recovery.discovery import RecoveryDiscovery
        from src.recovery.baseline import propose_sequence, audit_recovery_group
        eng = RecoveryDiscovery(CommvaultReader(api))
        disc = eng.discover(a.seed, a.app or None)
        (OUT / "RESULT_discovery.json").write_text(json.dumps(disc, indent=2), encoding="utf-8")
        summary["discovery"] = disc.get("summary") or disc.get("status")
        print("\n  DISCOVERY: " + str(summary["discovery"]))
        if disc.get("status") == "DISCOVERED":
            # Lab run only: treat every discovered candidate as confirmed, to see the full recovery order.
            cands = [r["name"] for r in disc["resources"] if r["role"] == "candidate"]
            seq = propose_sequence(RecoveryDiscovery(CommvaultReader(api)), a.app or a.seed, a.seed, cands, [])
            print("  SEQUENCE (assuming all candidates confirmed):")
            (OUT / "RESULT_sequence.json").write_text(json.dumps(seq, indent=2), encoding="utf-8")
            for p in seq.get("priorities", []):
                print(f"  P{p['priority']}: " + ", ".join(f"{r['name']} [{r['tier']}, {r['confidence']}]" for r in p["resources"]))
        if a.group:
            au = audit_recovery_group(RecoveryDiscovery(CommvaultReader(api)), a.group)
            (OUT / "RESULT_audit.json").write_text(json.dumps(au, indent=2), encoding="utf-8")
            print("  AUDIT: " + str(au.get("summary") or au.get("status")))
    except Exception:
        tb = traceback.format_exc()
        (OUT / "RESULT_error.txt").write_text(tb, encoding="utf-8")
        print("\n  Tool run failed (expected on first contact) - details in RESULT_error.txt")

    (OUT / "INDEX.json").write_text(json.dumps({"seed": a.seed, "app": a.app, "group": a.group,
                                                "recoveryGroupPath": rg_path, "calls": api.log, "summary": summary},
                                               indent=2), encoding="utf-8")
    print(f"\nDone. {api.n} GET calls. Output: {OUT}")
    print("No changes were made to the CommCell. Tell Claude 'probe done'.")


if __name__ == "__main__":
    main()
