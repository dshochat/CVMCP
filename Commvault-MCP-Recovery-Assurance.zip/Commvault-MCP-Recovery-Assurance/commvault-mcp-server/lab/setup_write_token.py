"""
Store a SEPARATE Commvault credential for Phase 2 writes (creating recovery groups) in the OS keyring.
It is kept apart from the read-only credential the discovery tools use.

    uv run lab\\setup_write_token.py

Use a token of an account allowed to create Cleanroom recovery groups. Writes stay disabled until an administrator
also sets RECOVERY_WRITE_ENABLED=true in .env.
"""
import getpass, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import keyring
from src.utils import get_keyring_service_name

service = get_keyring_service_name() + ":write"
tok = getpass.getpass("Access token for the WRITE account (input hidden): ").strip()
if not tok:
    sys.exit("Nothing stored.")
ref = getpass.getpass("Refresh token for the same account (input hidden; lets the tool renew the access token "
                      "when it expires - press Enter to skip): ").strip()
keyring.set_password(service, "access_token", tok)
if ref:
    keyring.set_password(service, "refresh_token", ref)
else:
    try:
        keyring.delete_password(service, "refresh_token")
    except Exception:
        pass
print(f"Stored in the OS keyring under '{service}'" + (" (access + refresh token)." if ref else
      " (access token only: re-run this when it expires).") + " Writes remain OFF until RECOVERY_WRITE_ENABLED=true.")
