"""
Phase 2 CREATE against the lab: creates a NEW Cleanroom application + recovery group from an incident runbook.

    uv run lab\\create_group.py --scenario identity_compromise --graph lab\\graphs\\lab_identity_dc1.json --base "Sample Application 1" --name "IR-dc1-test"

Safety: needs RECOVERY_WRITE_ENABLED=true in .env and a separate write token (uv run lab\\setup_write_token.py).
Shows the plan, then you must type the new group's name to confirm. Only creates NEW objects; the base group is only
read. Never launches a recovery. (In Claude Desktop the same flow is the create_recovery_group tool with an approval dialog.)
"""
import argparse, json, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent / "scenario_output"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="", help="override; derived from the incident when --defender/--cortex is given")
    ap.add_argument("--graph", default="")
    ap.add_argument("--defender", default="", help="Microsoft Defender XDR incident JSON")
    ap.add_argument("--exposure", default="", help="Exposure Management ExposureGraphEdges rows")
    ap.add_argument("--cortex", default="")
    ap.add_argument("--wiz", default="")
    ap.add_argument("--base", required=True, help="existing recovery group to copy the cleanroom target from (read only)")
    ap.add_argument("--name", required=True, help="name of the NEW application / recovery group")
    ap.add_argument("--t0", default="")
    ap.add_argument("--dwell", type=float, default=-1)
    a = ap.parse_args()

    from dotenv import load_dotenv
    load_dotenv(ROOT / ".env")
    from src.cv_api_client import commvault_api_client
    from src.recovery.cv_reader import CommvaultReader
    from src.recovery.discovery import RecoveryDiscovery
    from src.recovery.runbook import build_runbook
    from src.recovery.apply import GuardedWriter, WriteDisabled, desired_group, diff_against, render_preview, run_create

    try:
        writer = GuardedWriter.from_environment()
    except WriteDisabled as e:
        sys.exit(f"WRITE_DISABLED: {e}")

    load = lambda f: json.loads(Path(f).read_text(encoding="utf-8")) if f else None
    selection = None
    if a.defender or a.exposure or a.cortex or a.wiz:
        from src.recovery.adapters.security_sources import build_graph
        imp = build_graph(load(a.cortex), load(a.wiz), None, load(a.defender), load(a.exposure))
        graph = imp["graph"]
        scenarios = a.scenario.split(",") if a.scenario else imp["matchedScenarios"]
        selection = {"source": f"derived from {imp.get('incidentSource')} incident {imp.get('incidentId')}",
                     "reason": imp.get("scenarioReason"), "playbooks": scenarios}
        print(f"Incident {imp.get('incidentId')} ({imp.get('incidentSource')}): playbook(s) {scenarios}; "
              f"compromised {graph['compromised']}; {imp['report']['edges']} relationships; t0 {graph.get('t0')}")
        if imp["report"]["unmatchedIncidentEntities"] or imp["report"]["unmappedRelationships"]:
            print("Import report:", json.dumps({k: imp["report"][k] for k in ("unmatchedIncidentEntities", "unmappedRelationships",
                                                                              "unmappedEntityTypes")}))
    else:
        if not (a.graph and a.scenario):
            sys.exit("Give --defender/--exposure (or --cortex/--wiz), or --graph with --scenario.")
        graph, scenarios = load(a.graph), a.scenario.split(",")
    if a.t0 or not graph.get("t0"):
        graph["t0"] = a.t0 or (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
    reader = CommvaultReader(commvault_api_client)
    rb = build_runbook(RecoveryDiscovery(reader), scenarios, graph, None if a.dwell < 0 else a.dwell, a.base,
                       None, selection)
    base = reader.get_recovery_group(a.base)
    group = desired_group(rb, base, a.name, reader.get_cleanroom_supported())
    print(render_preview(group, diff_against(group, base)))
    if not group["members"]:
        sys.exit("NOTHING_TO_CREATE: no member is Cleanroom-eligible.")
    if not (group["target"] or {}).get("id"):
        sys.exit("NO_TARGET: could not read the cleanroom target from the base group.")

    print(f"\nplanHash {group['planHash']}")
    typed = input(f"\nThis will CREATE application + recovery group '{group['name']}' on the CommCell.\n"
                  f"Type the name exactly to confirm (anything else cancels): ").strip()
    if typed != group["name"]:
        sys.exit("Cancelled. Nothing was created.")

    try:
        result = run_create(writer, group)
    except Exception as e:                      # HTTP error mid-flow: report what already exists
        result = {"status": "ERROR", "error": str(e)[:500], "assemblyId": getattr(writer, "_created_assembly", None),
                  "recoveryGroupId": getattr(writer, "_created_rg", None)}
    OUT.mkdir(exist_ok=True)
    (OUT / "create_result.json").write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print("\n" + json.dumps({k: result.get(k) for k in ("status", "assemblyId", "recoveryGroupId", "verifiedPriorities",
                                                         "priorityMismatches", "unmatchedEntities", "skippedEntities",
                                                         "recoveredAsFilesOnly", "autoScale", "warnings", "commvaultReadiness",
                                                         "step", "response", "created", "error")}, indent=2, default=str))
    print(f"\nWrite calls: {len(writer.calls)}  ({', '.join(writer.calls)})")
    print("Nothing was recovered or launched. Check the group in Command Center > Cleanroom > Recovery groups.")


if __name__ == "__main__":
    main()
