"""
Replay saved lab probe responses through the current code (no CommCell needed).
    python lab/replay.py <probe_output_dir> <seed> [app]
"""
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from src.recovery.cv_reader import CommvaultReader
from src.recovery.discovery import RecoveryDiscovery
from src.recovery.baseline import propose_sequence


class ReplayApi:
    def __init__(self, folder):
        self.db, self.misses = {}, []
        for f in sorted(Path(folder).glob("[0-9]*.json")):
            d = json.loads(f.read_text(encoding="utf-8"))
            if d.get("status") == 200:
                self.db.setdefault(self._key(d["endpoint"], d.get("params")), d["response"])

    @staticmethod
    def _key(ep, params):
        return ep, tuple(sorted((k, str(v)) for k, v in (params or {}).items()))

    def get(self, endpoint, params=None, headers=None):
        k = self._key(endpoint, params)
        if k not in self.db:
            self.misses.append(k)
            raise RuntimeError(f"not captured: {k}")
        return self.db[k]


if __name__ == "__main__":
    folder, seed = sys.argv[1], sys.argv[2]
    app = sys.argv[3] if len(sys.argv) > 3 else seed
    api = ReplayApi(folder)
    d = RecoveryDiscovery(CommvaultReader(api)).discover(seed, app)
    print("SUMMARY:", d.get("summary"))
    for r in d.get("resources", []):
        print(f"  {r['name']:<10} {r['role']:<9} {r['confidence']:<9} {r['evidence']}")
    print("NOTES:", *d.get("notes", []), sep="\n  ")
    print("GAPS:")
    for g in d.get("gaps", []):
        print(f"  {g['severity']:<8} {g['resource']:<10} {g['finding']}")
    seed_res = next(r for r in d["resources"] if r["role"] == "seed")
    print("SEED COPIES:")
    for pl in seed_res["protection"]["plans"]:
        for c in pl["copies"]:
            print(f"  {pl['name']}/{c['name']:<22} primary={c['isPrimary']!s:<5} snap={c['isSnapshot']!s:<5} "
                  f"airgap={c['airGapped']!s:<5} immutable={c['immutable']!s:<5} ({c['immutableEvidence']}) region={c['region']}")
    cands = [r["name"] for r in d["resources"] if r["role"] == "candidate"]
    s = propose_sequence(RecoveryDiscovery(CommvaultReader(api)), app, seed, cands, [])
    print("SEQUENCE (all candidates confirmed):")
    for p in s.get("priorities", []):
        print(f"  P{p['priority']}: " + ", ".join(f"{r['name']} [{r['tier']}, {r['confidence']}]" for r in p["resources"]))
    print("UNCAPTURED CALLS:", sorted(set(api.misses)) or "none")
