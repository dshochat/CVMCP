"""
Phase 2 preview against the lab (READ-ONLY): what NEW Cleanroom recovery group would be created for an incident.

    uv run lab\\preview_group.py --scenario identity_compromise --graph lab\\graphs\\lab_identity_dc1.json --base "Sample Application 1"

Writes lab\\scenario_output\\group_preview.txt and group_preview.json (incl. the request body that WOULD be sent).
Nothing is created.
"""
import argparse, json, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent / "scenario_output"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", required=True)
    ap.add_argument("--graph", required=True)
    ap.add_argument("--base", required=True, help="existing recovery group to copy the target from (not modified)")
    ap.add_argument("--name", default="")
    ap.add_argument("--t0", default="")
    ap.add_argument("--dwell", type=float, default=-1)
    a = ap.parse_args()

    from src.cv_api_client import commvault_api_client
    from src.recovery.cv_reader import CommvaultReader
    from src.recovery.discovery import RecoveryDiscovery
    from src.recovery.runbook import build_runbook
    from src.recovery.apply import build_create_steps, desired_group, diff_against, render_preview, PAYLOAD_VALIDATED

    graph = json.loads(Path(a.graph).read_text(encoding="utf-8"))
    if a.t0 or not graph.get("t0"):
        graph["t0"] = a.t0 or (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()
    reader = CommvaultReader(commvault_api_client)
    rb = build_runbook(RecoveryDiscovery(reader), a.scenario.split(","), graph, None if a.dwell < 0 else a.dwell, a.base)
    base = reader.get_recovery_group(a.base)
    supported = reader.get_cleanroom_supported()
    group = desired_group(rb, base, a.name, supported)
    diff = diff_against(group, base)
    text = render_preview(group, diff)
    OUT.mkdir(exist_ok=True)
    (OUT / "group_preview.txt").write_text(text, encoding="utf-8")
    (OUT / "group_preview.json").write_text(json.dumps({"group": group, "differences": diff,
        "writeStepsThatWouldBeSent": build_create_steps(group), "payloadValidated": PAYLOAD_VALIDATED,
        "cleanroomSupportedServers": supported,
        "baseGroup": {k: v for k, v in (base or {}).items() if k != "entities"},
        "baseEntitiesRaw": [e.get("raw") for e in (base or {}).get("entities", [])]}, indent=2, default=str), encoding="utf-8")
    print(text)
    print(f"\nEligibility: {group['eligibilitySource']}")
    print(f"\n{len(reader.calls)} GET calls. Preview: {OUT / 'group_preview.txt'}")
    print("READ-ONLY: nothing was created.")


if __name__ == "__main__":
    main()
