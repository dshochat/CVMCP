"""
Run a security-scenario runbook against the live lab using the Commvault MCP configuration (read-only).

    uv run lab\\run_scenario.py --scenario identity_compromise --graph lab\\graphs\\lab_identity_dc1.json
        [--t0 2026-10-19T02:00:00Z] [--dwell 24] [--group "Sample Application 1"]
        [--cortex incident.json --wiz wiz_graph.json]      # alternative: build the graph from security-tool exports
        [--defender lab\\defender\\incident_dc1_identity.json --exposure lab\\defender\\exposure_dc1_identity.json]

Writes lab\\scenario_output\\runbook.md and runbook.json. Nothing is changed on the CommCell.
"""
import argparse, json, os, sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
OUT = Path(__file__).resolve().parent / "scenario_output"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", default="")
    ap.add_argument("--graph", default="")
    ap.add_argument("--cortex", default="")
    ap.add_argument("--wiz", default="")
    ap.add_argument("--defender", default="", help="Microsoft Defender XDR incident JSON")
    ap.add_argument("--exposure", default="", help="Exposure Management ExposureGraphEdges rows (lab/defender/blast_radius.kql)")
    ap.add_argument("--t0", default="", help="ISO time of compromise; default 48 hours ago")
    ap.add_argument("--dwell", type=float, default=-1)
    ap.add_argument("--group", default="")
    a = ap.parse_args()

    from src.cv_api_client import commvault_api_client
    from src.recovery.cv_reader import CommvaultReader
    from src.recovery.discovery import RecoveryDiscovery
    from src.recovery.runbook import build_runbook
    from src.recovery.adapters.security_sources import build_graph

    if a.cortex or a.wiz or a.defender or a.exposure:
        load = lambda p: json.loads(Path(p).read_text(encoding="utf-8")) if p else None
        imp = build_graph(load(a.cortex), load(a.wiz), None if a.dwell < 0 else a.dwell, load(a.defender), load(a.exposure))
        print("IMPORT:", json.dumps(imp["report"], indent=1))
        graph = imp["graph"]
        scenario = a.scenario.split(",") if a.scenario else imp["matchedScenarios"]
        selection = ({"source": "specified by caller (override)", "playbooks": scenario} if a.scenario else
                     {"source": f"derived from {imp.get('incidentSource')} incident {imp.get('incidentId')}", "reason": imp.get("scenarioReason"),
                      "playbooks": scenario})
        print(f"Playbook(s): {scenario} - {selection['source']} ({selection.get('reason') or ''})")
    else:
        graph, scenario = json.loads(Path(a.graph).read_text(encoding="utf-8")), a.scenario
        selection = None
    if a.t0 or not graph.get("t0"):
        graph["t0"] = a.t0 or (datetime.now(timezone.utc) - timedelta(hours=48)).isoformat()

    reader = CommvaultReader(commvault_api_client)
    rb = build_runbook(RecoveryDiscovery(reader), scenario, graph, None if a.dwell < 0 else a.dwell, a.group,
                       None, selection)
    OUT.mkdir(exist_ok=True)
    (OUT / "runbook.json").write_text(json.dumps(rb, indent=2), encoding="utf-8")
    (OUT / "runbook.md").write_text(rb.get("markdown", json.dumps(rb, indent=2)), encoding="utf-8")
    print("\n" + rb.get("summary", rb.get("status")))
    for line in rb.get("recoveryOrder", []):
        print("  " + line)
    for f in rb.get("recoveryGroupFindings", []):
        print(f"  [{f['severity'].upper()}] {f['finding']}")
    for g in rb.get("blastRadius", {}).get("gaps", []):
        print(f"  [GAP {g['severity'].upper()}] {g['resource']}: {g['finding']}")
    print(f"\n{len(reader.calls)} GET calls. Runbook: {OUT / 'runbook.md'}")
    print("No changes were made to the CommCell.")


if __name__ == "__main__":
    main()
