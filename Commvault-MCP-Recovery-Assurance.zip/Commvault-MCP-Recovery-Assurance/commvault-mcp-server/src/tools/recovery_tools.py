# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Recovery Assurance tools: understand what an application IS for recovery purposes, determine
its recovery order from technology, freeze an owner-approved recovery definition, and detect
when production drifts away from it.

Every tool is read-only against the CommCell. approve_recovery_map writes a local JSON baseline
only, and only after the HUMAN confirms through an MCP elicitation dialog that the AI cannot answer.
"""

import os
from dataclasses import dataclass
from typing import Annotated, Dict, List

from fastmcp import Context
from fastmcp.exceptions import ToolError
from pydantic import Field

from src.logger import logger
from src.recovery.baseline import (audit_recovery_group, commit_approval, detect_drift,
                                   prepare_approval, propose_sequence)
from src.recovery.cv_reader import CommvaultReader
from src.recovery.discovery import RecoveryDiscovery


def _engine(rpo_hours: int = 24) -> RecoveryDiscovery:
    from src.cv_api_client import commvault_api_client  # imported lazily so tests can inject a fake API
    return RecoveryDiscovery(CommvaultReader(commvault_api_client), rpo_hours=rpo_hours)


def _approval_mode() -> str:
    """
    elicit (default): the server asks the human directly through the MCP client's elicitation dialog.
                      If the client does not support elicitation, approval is REFUSED (fail closed).
    host:             rely on the MCP host's own per-tool approval prompt (e.g. "always ask" for this tool).
                      Weaker: enforcement lives in the client configuration, not in this server.
    """
    mode = os.environ.get("RECOVERY_APPROVAL_MODE", "elicit").strip().lower()
    return mode if mode in ("elicit", "host") else "elicit"


APPROVAL_SCHEMA = {
    "type": "object",
    "properties": {"approver_name": {"type": "string", "title": "Your name",
                                     "description": "Name of the application owner approving this recovery definition"}},
    "required": ["approver_name"],
}


def _modern_protocol(ctx) -> bool:
    fn = getattr(ctx, "_is_modern_protocol", None)
    try:
        return bool(fn()) if fn else False
    except Exception:
        return False


def _approval_request(text: str, plan_fp: str):
    from mcp_types import ElicitRequest, ElicitRequestFormParams, InputRequiredResult
    return InputRequiredResult(
        input_requests={"approval": ElicitRequest(params=ElicitRequestFormParams(
            message=text, requested_schema=APPROVAL_SCHEMA))},
        request_state=plan_fp,
    )


def _no_dialog_support() -> dict:
    return {"status": "NOT_APPROVED",
            "reason": "This MCP client does not support confirmation dialogs (elicitation), so the server "
                      "cannot verify that a human approved. Nothing was saved.",
            "options": ["Use an MCP client that supports elicitation",
                        "Administrator sets RECOVERY_APPROVAL_MODE=host and configures the client to always "
                        "ask before running approve_recovery_map"]}


@dataclass
class ApprovalForm:
    approver_name: Annotated[str, Field(title="Your name", description="Name of the application owner approving this recovery definition")]


def discover_recovery_application(
    seed_resource: Annotated[str, Field(description="Name, hostname or client id of ONE production resource of the application, supplied by the application owner (e.g. 'TRADING-WEB-01').")],
    application_name: Annotated[str, Field(description="Business name of the application (e.g. 'TradingDemo'). Optional but improves candidate matching.")] = "",
    rpo_hours: Annotated[int, Field(description="Recovery point objective in hours used to flag stale recovery points.")] = 24,
) -> dict:
    """
    Builds an evidence-based recovery map of a business application starting from a single seed resource.
    Read-only. Returns: the seed and the applications/instances/databases Commvault discovered on it, the plans,
    copies and latest recovery points protecting it, other resources that MAY belong to the application
    (each with evidence and confidence, requiring owner confirmation), recoverability gaps, and the dependencies
    Commvault cannot see. Present candidates to the user for confirmation; never assume they belong to the application.
    """
    try:
        return _engine(rpo_hours).discover(seed_resource, application_name or None)
    except Exception as e:
        logger.error(f"Error discovering recovery application: {e}")
        return ToolError({"error": str(e)})


def generate_recovery_sequence(
    application_name: Annotated[str, Field(description="Business name of the application.")],
    seed_resource: Annotated[str, Field(description="The seed resource used for discovery.")],
    include_candidates: Annotated[List[str], Field(description="Candidates the user confirmed belong to the application.")] = [],
    exclude_candidates: Annotated[List[str], Field(description="Candidates the user rejected.")] = [],
    tier_overrides: Annotated[Dict[str, str], Field(description="EXCEPTIONS ONLY. Resource name -> tier (foundation|data|middleware|application|presentation) when the user says the inferred tier is wrong.")] = {},
    ordering_exceptions: Annotated[List[str], Field(description="EXCEPTIONS ONLY. Unusual ordering stated by the user, e.g. 'LIC-01 before ORA-01'.")] = [],
) -> dict:
    """
    Determines the recovery order of an application automatically from technology, with no input needed for normal
    architectures: foundation -> data -> middleware -> application -> presentation. Tiers come from Commvault-discovered
    agents (strong evidence) or naming (weak, flagged for confirmation). Returns Commvault Cleanroom priorities
    (1 = first), what each resource waits for, readiness gates between priorities, and a planHash fingerprint.
    Read-only. Show the plan to the user, especially classificationsNeedingConfirmation, before approve_recovery_map.
    """
    try:
        return propose_sequence(_engine(), application_name, seed_resource, include_candidates or [],
                                exclude_candidates or [], tier_overrides or {}, ordering_exceptions or [])
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error generating recovery sequence: {e}")
        return ToolError({"error": str(e)})


async def approve_recovery_map(
    application_name: Annotated[str, Field(description="Business name of the application.")],
    seed_resource: Annotated[str, Field(description="The same seed resource used for discovery.")],
    plan_hash: Annotated[str, Field(description="planHash returned by generate_recovery_sequence for the plan the user reviewed.")],
    include_candidates: Annotated[List[str], Field(description="Candidates the user CONFIRMED belong to the application.")] = [],
    exclude_candidates: Annotated[List[str], Field(description="Candidates the user REJECTED.")] = [],
    tier_overrides: Annotated[Dict[str, str], Field(description="Same tier_overrides used to generate the plan.")] = {},
    ordering_exceptions: Annotated[List[str], Field(description="Same ordering_exceptions used to generate the plan.")] = [],
    rpo_hours: Annotated[int, Field(description="Approved RPO in hours for this application.")] = 24,
    ctx: Context = None,
) -> dict:
    """
    Freezes the recovery definition (members + recovery order) for an application so drift can be detected later.
    The server re-runs discovery and sequencing, refuses if the result no longer matches plan_hash, and then asks
    the HUMAN to confirm directly through the client's confirmation dialog. The AI cannot approve on the user's behalf.
    Writes a local baseline file only; makes no change to Commvault.
    """
    try:
        pending, err = prepare_approval(_engine(rpo_hours), application_name, seed_resource,
                                        include_candidates or [], exclude_candidates or [], plan_hash,
                                        tier_overrides or {}, ordering_exceptions or [])
        if err:
            return err

        if _approval_mode() == "host":
            return commit_approval(pending, "user (host tool-approval)", "host_tool_approval")

        if ctx is None:
            return {"status": "NOT_APPROVED", "reason": "No MCP session context; human confirmation impossible."}

        plan_fp = pending["baseline"]["sequence"]["planHash"]
        if _modern_protocol(ctx):
            # MCP 2026-07-28: guard pattern. Round 1 returns InputRequiredResult; the client shows the dialog
            # to the human and retries with the answer. request_state is sealed by the framework (tamper-proof).
            responses = getattr(ctx, "input_responses", None)
            if not responses or "approval" not in responses:
                return _approval_request(pending["confirmationText"], plan_fp)
            if (getattr(ctx, "request_state", None) or "") != plan_fp:
                return {"status": "PLAN_CHANGED", "reason": "The plan changed while the user was reviewing it. Nothing was saved.",
                        "nextStep": "Call generate_recovery_sequence again."}
            resp = responses["approval"]
            action = getattr(resp, "action", None)
            content = getattr(resp, "content", None) or {}
            approver = str(content.get("approver_name", "") if isinstance(content, dict) else "").strip()
        else:
            try:
                answer = await ctx.elicit(pending["confirmationText"], response_type=ApprovalForm)
            except Exception as e:
                logger.warning(f"Elicitation unavailable: {e}")
                return _no_dialog_support()
            action = answer.action
            approver = (getattr(getattr(answer, "data", None), "approver_name", "") or "").strip()

        if action != "accept":
            return {"status": "NOT_APPROVED", "reason": f"User did not approve ({action}). Nothing was saved."}
        if not approver:
            return {"status": "NOT_APPROVED", "reason": "Approver name is required. Nothing was saved."}
        return commit_approval(pending, approver, "mcp_elicitation")
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error approving recovery map: {e}")
        return ToolError({"error": str(e)})


def detect_recovery_drift(
    application_name: Annotated[str, Field(description="Business name of an application with an approved recovery map.")],
) -> dict:
    """
    Compares production as Commvault sees it now against the approved recovery definition for an application.
    Reports new resources not in the definition (and where they would fall in the recovery order), approved members
    that disappeared or lost protection, servers whose technology changed, removed databases/subclients, plan changes,
    lost immutable/air-gapped/secondary copies, and RPO breaches. Read-only; recommends actions but changes nothing.
    """
    try:
        return detect_drift(_engine(), application_name)
    except Exception as e:
        logger.error(f"Error detecting recovery drift: {e}")
        return ToolError({"error": str(e)})


def audit_recovery_order(
    recovery_group_name: Annotated[str, Field(description="Name of an existing Commvault Cleanroom recovery group.")],
    application_name: Annotated[str, Field(description="Optional. If the application has an approved recovery definition, also check the group contains every member.")] = "",
) -> dict:
    """
    Audits an EXISTING Commvault Cleanroom recovery group: classifies each member by technology and flags priorities
    that violate recovery best practice (e.g. web or application servers recovering before their database), members
    sharing a priority with their dependency, and (with an approved definition) members missing from the group.
    Read-only; needs no input beyond the group name.
    """
    try:
        return audit_recovery_group(_engine(), recovery_group_name, application_name or None)
    except Exception as e:
        logger.error(f"Error auditing recovery order: {e}")
        return ToolError({"error": str(e)})


RECOVERY_ASSURANCE_TOOLS = [
    discover_recovery_application,
    generate_recovery_sequence,
    approve_recovery_map,
    detect_recovery_drift,
    audit_recovery_order,
]
