# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Recovery Assurance tools: understand what an application IS for recovery purposes, determine
its recovery order from technology, freeze an owner-approved recovery definition, and detect
when production drifts away from it.

Every tool is read-only against the CommCell. approve_recovery_map writes a local JSON baseline
only, and only after the HUMAN confirms through an MCP elicitation dialog that the AI cannot answer.
"""

import os
from dataclasses import dataclass
from typing import Any, Annotated, Dict, List

from fastmcp import Context
from fastmcp.exceptions import ToolError
from pydantic import Field

from src.logger import logger
from src.recovery.baseline import (audit_recovery_group, commit_approval, detect_drift,
                                   prepare_approval, propose_sequence)
from src.recovery.blast_radius import assess
from src.recovery.cv_reader import CommvaultReader
from src.recovery.runbook import build_runbook, list_scenarios
from src.recovery.adapters.security_sources import build_graph
from src.recovery.apply import (PAYLOAD_VALIDATED, GuardedWriter, WriteDisabled, build_create_steps,
                                desired_group, diff_against, render_preview, run_create)
from src.recovery.baseline import load_baseline
import json as _json
from src.recovery.discovery import RecoveryDiscovery


def _engine(rpo_hours: int = 24) -> RecoveryDiscovery:
    from src.cv_api_client import commvault_api_client  # imported lazily so tests can inject a fake API
    return RecoveryDiscovery(CommvaultReader(commvault_api_client), rpo_hours=rpo_hours)


def _approval_mode() -> str:
    """
    elicit (default): the server asks the human directly through the MCP client's elicitation dialog.
                      If the client does not support elicitation, approval is REFUSED (fail closed).
    host:             rely on the MCP host's own per-tool approval prompt (e.g. "always ask" for this tool).
                      Weaker: enforcement lives in the client configuration, not in this server.
    """
    mode = os.environ.get("RECOVERY_APPROVAL_MODE", "elicit").strip().lower()
    return mode if mode in ("elicit", "host") else "elicit"


APPROVAL_SCHEMA = {
    "type": "object",
    "properties": {"approver_name": {"type": "string", "title": "Your name",
                                     "description": "Name of the application owner approving this recovery definition"}},
    "required": ["approver_name"],
}


def _modern_protocol(ctx) -> bool:
    fn = getattr(ctx, "_is_modern_protocol", None)
    try:
        return bool(fn()) if fn else False
    except Exception:
        return False


def _approval_request(text: str, plan_fp: str):
    from mcp_types import ElicitRequest, ElicitRequestFormParams, InputRequiredResult
    return InputRequiredResult(
        input_requests={"approval": ElicitRequest(params=ElicitRequestFormParams(
            message=text, requested_schema=APPROVAL_SCHEMA))},
        request_state=plan_fp,
    )


def _no_dialog_support() -> dict:
    return {"status": "NOT_APPROVED",
            "reason": "This MCP client does not support confirmation dialogs (elicitation), so the server "
                      "cannot verify that a human approved. Nothing was saved.",
            "options": ["Use an MCP client that supports elicitation",
                        "Administrator sets RECOVERY_APPROVAL_MODE=host and configures the client to always "
                        "ask before running approve_recovery_map"]}


@dataclass
class ApprovalForm:
    approver_name: Annotated[str, Field(title="Your name", description="Name of the application owner approving this recovery definition")]


def discover_recovery_application(
    seed_resource: Annotated[str, Field(description="Name, hostname or client id of ONE production resource of the application, supplied by the application owner (e.g. 'TRADING-WEB-01').")],
    application_name: Annotated[str, Field(description="Business name of the application (e.g. 'TradingDemo'). Optional but improves candidate matching.")] = "",
    rpo_hours: Annotated[int, Field(description="Recovery point objective in hours used to flag stale recovery points.")] = 24,
) -> dict:
    """
    Builds an evidence-based recovery map of a business application starting from a single seed resource.
    Read-only. Returns: the seed and the applications/instances/databases Commvault discovered on it, the plans,
    copies and latest recovery points protecting it, other resources that MAY belong to the application
    (each with evidence and confidence, requiring owner confirmation), recoverability gaps, and the dependencies
    Commvault cannot see. Present candidates to the user for confirmation; never assume they belong to the application.
    """
    try:
        return _engine(rpo_hours).discover(seed_resource, application_name or None)
    except Exception as e:
        logger.error(f"Error discovering recovery application: {e}")
        return ToolError({"error": str(e)})


def generate_recovery_sequence(
    application_name: Annotated[str, Field(description="Business name of the application.")],
    seed_resource: Annotated[str, Field(description="The seed resource used for discovery.")],
    include_candidates: Annotated[List[str], Field(description="Candidates the user confirmed belong to the application.")] = [],
    exclude_candidates: Annotated[List[str], Field(description="Candidates the user rejected.")] = [],
    tier_overrides: Annotated[Dict[str, str], Field(description="EXCEPTIONS ONLY. Resource name -> tier (foundation|data|middleware|application|presentation) when the user says the inferred tier is wrong.")] = {},
    ordering_exceptions: Annotated[List[str], Field(description="EXCEPTIONS ONLY. Unusual ordering stated by the user, e.g. 'LIC-01 before ORA-01'.")] = [],
) -> dict:
    """
    Determines the recovery order of an application automatically from technology, with no input needed for normal
    architectures: foundation -> data -> middleware -> application -> presentation. Tiers come from Commvault-discovered
    agents (strong evidence) or naming (weak, flagged for confirmation). Returns Commvault Cleanroom priorities
    (1 = first), what each resource waits for, readiness gates between priorities, and a planHash fingerprint.
    Read-only. Show the plan to the user, especially classificationsNeedingConfirmation, before approve_recovery_map.
    """
    try:
        return propose_sequence(_engine(), application_name, seed_resource, include_candidates or [],
                                exclude_candidates or [], tier_overrides or {}, ordering_exceptions or [])
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error generating recovery sequence: {e}")
        return ToolError({"error": str(e)})


async def approve_recovery_map(
    application_name: Annotated[str, Field(description="Business name of the application.")],
    seed_resource: Annotated[str, Field(description="The same seed resource used for discovery.")],
    plan_hash: Annotated[str, Field(description="planHash returned by generate_recovery_sequence for the plan the user reviewed.")],
    include_candidates: Annotated[List[str], Field(description="Candidates the user CONFIRMED belong to the application.")] = [],
    exclude_candidates: Annotated[List[str], Field(description="Candidates the user REJECTED.")] = [],
    tier_overrides: Annotated[Dict[str, str], Field(description="Same tier_overrides used to generate the plan.")] = {},
    ordering_exceptions: Annotated[List[str], Field(description="Same ordering_exceptions used to generate the plan.")] = [],
    rpo_hours: Annotated[int, Field(description="Approved RPO in hours for this application.")] = 24,
    ctx: Context = None,
) -> dict:
    """
    Freezes the recovery definition (members + recovery order) for an application so drift can be detected later.
    The server re-runs discovery and sequencing, refuses if the result no longer matches plan_hash, and then asks
    the HUMAN to confirm directly through the client's confirmation dialog. The AI cannot approve on the user's behalf.
    Writes a local baseline file only; makes no change to Commvault.
    """
    try:
        pending, err = prepare_approval(_engine(rpo_hours), application_name, seed_resource,
                                        include_candidates or [], exclude_candidates or [], plan_hash,
                                        tier_overrides or {}, ordering_exceptions or [])
        if err:
            return err

        if _approval_mode() == "host":
            return commit_approval(pending, "user (host tool-approval)", "host_tool_approval")

        if ctx is None:
            return {"status": "NOT_APPROVED", "reason": "No MCP session context; human confirmation impossible."}

        plan_fp = pending["baseline"]["sequence"]["planHash"]
        if _modern_protocol(ctx):
            # MCP 2026-07-28: guard pattern. Round 1 returns InputRequiredResult; the client shows the dialog
            # to the human and retries with the answer. request_state is sealed by the framework (tamper-proof).
            responses = getattr(ctx, "input_responses", None)
            if not responses or "approval" not in responses:
                return _approval_request(pending["confirmationText"], plan_fp)
            if (getattr(ctx, "request_state", None) or "") != plan_fp:
                return {"status": "PLAN_CHANGED", "reason": "The plan changed while the user was reviewing it. Nothing was saved.",
                        "nextStep": "Call generate_recovery_sequence again."}
            resp = responses["approval"]
            action = getattr(resp, "action", None)
            content = getattr(resp, "content", None) or {}
            approver = str(content.get("approver_name", "") if isinstance(content, dict) else "").strip()
        else:
            try:
                answer = await ctx.elicit(pending["confirmationText"], response_type=ApprovalForm)
            except Exception as e:
                logger.warning(f"Elicitation unavailable: {e}")
                return _no_dialog_support()
            action = answer.action
            approver = (getattr(getattr(answer, "data", None), "approver_name", "") or "").strip()

        if action != "accept":
            return {"status": "NOT_APPROVED", "reason": f"User did not approve ({action}). Nothing was saved."}
        if not approver:
            return {"status": "NOT_APPROVED", "reason": "Approver name is required. Nothing was saved."}
        return commit_approval(pending, approver, "mcp_elicitation")
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error approving recovery map: {e}")
        return ToolError({"error": str(e)})


def detect_recovery_drift(
    application_name: Annotated[str, Field(description="Business name of an application with an approved recovery map.")],
) -> dict:
    """
    Compares production as Commvault sees it now against the approved recovery definition for an application.
    Reports new resources not in the definition (and where they would fall in the recovery order), approved members
    that disappeared or lost protection, servers whose technology changed, removed databases/subclients, plan changes,
    lost immutable/air-gapped/secondary copies, and RPO breaches. Read-only; recommends actions but changes nothing.
    """
    try:
        return detect_drift(_engine(), application_name)
    except Exception as e:
        logger.error(f"Error detecting recovery drift: {e}")
        return ToolError({"error": str(e)})


def audit_recovery_order(
    recovery_group_name: Annotated[str, Field(description="Name of an existing Commvault Cleanroom recovery group.")],
    application_name: Annotated[str, Field(description="Optional. If the application has an approved recovery definition, also check the group contains every member.")] = "",
) -> dict:
    """
    Audits an EXISTING Commvault Cleanroom recovery group: classifies each member by technology and flags priorities
    that violate recovery best practice (e.g. web or application servers recovering before their database), members
    sharing a priority with their dependency, and (with an approved definition) members missing from the group.
    Read-only; needs no input beyond the group name.
    """
    try:
        return audit_recovery_group(_engine(), recovery_group_name, application_name or None)
    except Exception as e:
        logger.error(f"Error auditing recovery order: {e}")
        return ToolError({"error": str(e)})


def _graph(graph, t0: str = ""):
    g = _json.loads(graph) if isinstance(graph, str) else dict(graph or {})
    if t0:
        g["t0"] = t0
    return g


def import_security_context(
    cortex_incident: Annotated[dict, Field(description="Optional raw Cortex XDR/XSIAM incident JSON (compromised users/hosts, detection time, categories).")] = {},
    wiz_graph: Annotated[dict, Field(description="Optional raw Wiz security-graph export (nodes/edges, or graphSearch rows).")] = {},
    defender_incident: Annotated[dict, Field(description="Optional raw Microsoft Defender XDR incident JSON (Defender API /api/incidents item, or Graph security/incidents/{id}?$expand=alerts), passed through unchanged. Supplies compromised users/devices, t0 and the playbook.")] = {},
    exposure_graph: Annotated[Any, Field(description="Optional Microsoft Security Exposure Management export: ExposureGraphEdges rows from advanced hunting (e.g. from lab/defender/blast_radius.kql), passed through unchanged. Supplies the blast radius.")] = [],
    dwell_time_hours: Annotated[float, Field(description="Optional dwell time in hours to put in the graph.")] = -1,
) -> dict:
    """
    Converts raw security-tool exports into the recovery graph format, deterministically (no AI interpretation):
    Cortex or Microsoft Defender XDR incident -> compromised identities/hosts, t0 and a suggested scenario;
    Wiz graph or Microsoft Security Exposure Management (ExposureGraphEdges rows) -> what they can reach.
    Returns the graph to pass to assess_blast_radius / build_scenario_runbook, plus a report of anything unmapped.
    Pass the exports through unchanged; do not rewrite them.
    """
    try:
        return build_graph(cortex_incident or None, wiz_graph or None, None if dwell_time_hours < 0 else dwell_time_hours,
                           defender_incident or None, exposure_graph or None)
    except Exception as e:
        logger.error(f"Error importing security context: {e}")
        return ToolError({"error": str(e)})


def list_recovery_scenarios() -> dict:
    """
    Lists the security scenarios that can drive a recovery runbook (e.g. identity_compromise, cloud_iam_compromise,
    ransomware, data_tampering, malicious_update), with their recovery-point policy and default dwell time.
    """
    try:
        return {"scenarios": list_scenarios()}
    except Exception as e:
        logger.error(f"Error listing scenarios: {e}")
        return ToolError({"error": str(e)})


def assess_blast_radius(
    graph: Annotated[dict, Field(description="Security graph JSON: {compromised:[node ids], t0, dwellTimeHours, nodes:[{id,type,name,commvaultClient}], edges:[{from,to,rel}]}. Control relations (admin_of, member_of, can_assume, authenticates, can_write, ...) define what an attacker can reach.")],
    t0: Annotated[str, Field(description="Optional override of the compromise time (ISO 8601).")] = "",
    dwell_time_hours: Annotated[float, Field(description="Optional attacker dwell time in hours; the clean cutoff is t0 minus this.")] = -1,
) -> dict:
    """
    Computes the blast radius of a compromise: every node the compromised identities can control (with the attack path as
    evidence), which of them are Commvault-protected (the recovery scope) with their last clean recovery point before
    the cutoff, identity objects needing credential action, and gaps (affected but unprotected, no clean point). Read-only.
    """
    try:
        return assess(_engine(), _graph(graph, t0), None if dwell_time_hours < 0 else dwell_time_hours)
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error assessing blast radius: {e}")
        return ToolError({"error": str(e)})


def _runbook_from_inputs(graph, cortex_incident, wiz_graph, scenario, t0, dwell_time_hours,
                         recovery_group_name, application_name, defender_incident=None, exposure_graph=None) -> dict:
    selection, g = None, None
    if cortex_incident or wiz_graph or defender_incident or exposure_graph:
        imp = build_graph(cortex_incident or None, wiz_graph or None, None if dwell_time_hours < 0 else dwell_time_hours,
                          defender_incident or None, exposure_graph or None)
        g = imp["graph"]
        if imp.get("matchedScenarios"):
            selection = {"source": f"derived from {imp.get('incidentSource') or 'the'} incident {imp.get('incidentId')}",
                         "reason": imp.get("scenarioReason"), "playbooks": imp["matchedScenarios"]}
        import_report = imp["report"]
    else:
        g, import_report = _graph(graph), None
    if t0:
        g["t0"] = t0
    if scenario:
        selection = {"source": "specified by caller (override)", "playbooks": [x.strip() for x in scenario.split(",") if x.strip()]}
    elif not selection and g.get("scenario"):
        selection = {"source": "graph 'scenario' field", "playbooks": [g["scenario"]] if isinstance(g["scenario"], str) else g["scenario"]}
    if not selection:
        return {"status": "NEEDS_SCENARIO",
                "reason": "No incident to derive the recovery playbook from. Provide cortex_incident or defender_incident, or set scenario.",
                "available": [s["id"] for s in list_scenarios()]}
    members = None
    if application_name:
        base = load_baseline(application_name)
        members = list(base["members"]) if base else None
    rb = build_runbook(_engine(), selection["playbooks"], g, None if dwell_time_hours < 0 else dwell_time_hours,
                       recovery_group_name, members, selection)
    if import_report:
        rb["importReport"] = import_report
    return rb


async def _human_approval(ctx, text: str, fingerprint: str):
    """Ask the HUMAN to confirm through the MCP client (elicitation). Returns (approver, None) or (None, result_dict).
    Supports MCP <=2025-11-25 (ctx.elicit) and 2026-07-28 (guard pattern with sealed request_state)."""
    if _approval_mode() == "host":
        return "user (host tool-approval)", None
    if ctx is None:
        return None, {"status": "NOT_APPROVED", "reason": "No MCP session context; human confirmation impossible."}
    if _modern_protocol(ctx):
        responses = getattr(ctx, "input_responses", None)
        if not responses or "approval" not in responses:
            return None, _approval_request(text, fingerprint)
        if (getattr(ctx, "request_state", None) or "") != fingerprint:
            return None, {"status": "PLAN_CHANGED", "reason": "The plan changed while the user was reviewing it. Nothing was done."}
        resp = responses["approval"]
        action = getattr(resp, "action", None)
        content = getattr(resp, "content", None) or {}
        approver = str(content.get("approver_name", "") if isinstance(content, dict) else "").strip()
    else:
        try:
            answer = await ctx.elicit(text, response_type=ApprovalForm)
        except Exception as e:
            logger.warning(f"Elicitation unavailable: {e}")
            return None, _no_dialog_support()
        action = answer.action
        approver = (getattr(getattr(answer, "data", None), "approver_name", "") or "").strip()
    if action != "accept":
        return None, {"status": "NOT_APPROVED", "reason": f"User did not approve ({action}). Nothing was done."}
    if not approver:
        return None, {"status": "NOT_APPROVED", "reason": "Approver name is required. Nothing was done."}
    return approver, None


def preview_recovery_group(
    base_recovery_group_name: Annotated[str, Field(description="Existing Cleanroom recovery group to copy the target from and compare with (it is NOT modified).")],
    graph: Annotated[dict, Field(description="Security graph JSON (same as build_scenario_runbook). Not needed if cortex_incident/wiz_graph are given.")] = {},
    cortex_incident: Annotated[dict, Field(description="Optional raw Cortex incident JSON, passed through unchanged.")] = {},
    wiz_graph: Annotated[dict, Field(description="Optional raw Wiz graph export, passed through unchanged.")] = {},
    defender_incident: Annotated[dict, Field(description="Optional raw Microsoft Defender XDR incident JSON (Defender API /api/incidents item, or Graph security/incidents/{id}?$expand=alerts), passed through unchanged. Supplies compromised users/devices, t0 and the playbook.")] = {},
    exposure_graph: Annotated[Any, Field(description="Optional Microsoft Security Exposure Management export: ExposureGraphEdges rows from advanced hunting (e.g. from lab/defender/blast_radius.kql), passed through unchanged. Supplies the blast radius.")] = [],
    scenario: Annotated[str, Field(description="Optional playbook override; normally derived from the incident.")] = "",
    t0: Annotated[str, Field(description="Optional compromise time override (ISO 8601).")] = "",
    dwell_time_hours: Annotated[float, Field(description="Optional dwell time in hours.")] = -1,
    new_group_name: Annotated[str, Field(description="Optional name for the new group; default IR-<playbook>-<date>.")] = "",
) -> dict:
    """
    PHASE 2 PREVIEW (read-only). Builds the incident runbook, then shows the NEW Cleanroom recovery group it would create:
    target, members that Cleanroom can recover (VM-level backups) with priorities and a specific pre-cutoff recovery point
    each, members left out (with the reason), the difference from the existing group, and a planHash. Nothing is written.
    Show this to the user; only if they want it, call create_recovery_group with the same inputs and the planHash.
    """
    try:
        rb = _runbook_from_inputs(graph, cortex_incident, wiz_graph, scenario, t0, dwell_time_hours, base_recovery_group_name, "",
                                  defender_incident, exposure_graph)
        if rb.get("status") not in ("RUNBOOK_READY",):
            return rb
        eng = _engine()
        base = eng.r.get_recovery_group(base_recovery_group_name) if base_recovery_group_name else None
        group = desired_group(rb, base, new_group_name, eng.r.get_cleanroom_supported())
        diff = diff_against(group, base)
        return {"status": "PREVIEW", "readOnly": True, "group": group, "differences": diff,
                "previewText": render_preview(group, diff), "planHash": group["planHash"],
                "writeSteps": build_create_steps(group), "payloadValidated": PAYLOAD_VALIDATED,
                "runbookSummary": rb["summary"],
                "nextStep": "Show previewText to the user. To create it, call create_recovery_group with the same inputs "
                            f"and plan_hash={group['planHash']}; the server asks the user to confirm directly."}
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error previewing recovery group: {e}")
        return ToolError({"error": str(e)})


async def create_recovery_group(
    base_recovery_group_name: Annotated[str, Field(description="Same base group used for the preview (not modified).")],
    plan_hash: Annotated[str, Field(description="planHash from preview_recovery_group for the plan the user reviewed.")],
    graph: Annotated[dict, Field(description="Same graph as the preview.")] = {},
    cortex_incident: Annotated[dict, Field(description="Same Cortex incident as the preview.")] = {},
    wiz_graph: Annotated[dict, Field(description="Same Wiz graph as the preview.")] = {},
    defender_incident: Annotated[dict, Field(description="Optional raw Microsoft Defender XDR incident JSON (Defender API /api/incidents item, or Graph security/incidents/{id}?$expand=alerts), passed through unchanged. Supplies compromised users/devices, t0 and the playbook.")] = {},
    exposure_graph: Annotated[Any, Field(description="Optional Microsoft Security Exposure Management export: ExposureGraphEdges rows from advanced hunting (e.g. from lab/defender/blast_radius.kql), passed through unchanged. Supplies the blast radius.")] = [],
    scenario: Annotated[str, Field(description="Same scenario override as the preview, if any.")] = "",
    t0: Annotated[str, Field(description="Same t0 override as the preview, if any.")] = "",
    dwell_time_hours: Annotated[float, Field(description="Same dwell time as the preview, if any.")] = -1,
    new_group_name: Annotated[str, Field(description="Same new group name as the preview, if any.")] = "",
    ctx: Context = None,
) -> dict:
    """
    PHASE 2 WRITE. Creates the NEW Cleanroom recovery group shown by preview_recovery_group. Re-computes the plan on the
    server and refuses if it no longer matches plan_hash; asks the HUMAN to confirm through the client's dialog (the AI
    cannot approve); uses a separate write credential; only the captured create calls are allowed, and only against the
    group this call itself creates (no update of existing groups, no delete, no launch). Sets per-member priorities and
    the POINT_IN_TIME recovery point, then reads the group back and reports verified priorities and Commvault readiness.
    Disabled unless the administrator set RECOVERY_WRITE_ENABLED=true. Never starts a recovery.
    """
    try:
        try:
            writer = GuardedWriter.from_environment()
        except WriteDisabled as e:
            return {"status": "WRITE_DISABLED", "reason": str(e),
                    "hint": "Use preview_recovery_group to see the plan; creation is off in this deployment."}
        rb = _runbook_from_inputs(graph, cortex_incident, wiz_graph, scenario, t0, dwell_time_hours, base_recovery_group_name, "",
                                  defender_incident, exposure_graph)
        if rb.get("status") != "RUNBOOK_READY":
            return rb
        eng = _engine()
        base = eng.r.get_recovery_group(base_recovery_group_name) if base_recovery_group_name else None
        group = desired_group(rb, base, new_group_name, eng.r.get_cleanroom_supported())
        if group["planHash"] != (plan_hash or "").strip():
            return {"status": "PLAN_CHANGED", "expectedPlanHash": plan_hash, "currentPlanHash": group["planHash"],
                    "reason": "The plan no longer matches what the user reviewed. Nothing was created.",
                    "nextStep": "Call preview_recovery_group again and show the user the new plan."}
        if not group["members"]:
            return {"status": "NOTHING_TO_CREATE", "reason": "No member is eligible for a Cleanroom recovery group.",
                    "excluded": group["excluded"]}
        if not (group["target"] or {}).get("id"):
            return {"status": "NO_TARGET", "reason": "Could not determine the cleanroom target from the base group."}
        approver, refusal = await _human_approval(ctx, render_preview(group, diff_against(group, base)), group["planHash"])
        if refusal is not None:
            return refusal
        result = run_create(writer, group)
        result.update({"approvedBy": approver, "planHash": group["planHash"], "group": group["name"],
                       "members": [f"P{m['priority']}: {m['name']}" for m in group["members"]],
                       "note": "Created only. Nothing was recovered or launched; start the recovery from Command Center."})
        logger.info(f"Recovery group create by {approver}: {result}")
        return result
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error creating recovery group: {e}")
        return ToolError({"error": str(e)})


def build_scenario_runbook(
    graph: Annotated[dict, Field(description="Security graph JSON (same format as assess_blast_radius). Not needed if cortex_incident/wiz_graph are given.")] = {},
    cortex_incident: Annotated[dict, Field(description="Optional raw Cortex XDR/XSIAM incident JSON, passed through unchanged. Supplies compromised entities, t0 and the playbook.")] = {},
    wiz_graph: Annotated[dict, Field(description="Optional raw Wiz security-graph export, passed through unchanged. Supplies the blast radius.")] = {},
    defender_incident: Annotated[dict, Field(description="Optional raw Microsoft Defender XDR incident JSON (Defender API /api/incidents item, or Graph security/incidents/{id}?$expand=alerts), passed through unchanged. Supplies compromised users/devices, t0 and the playbook.")] = {},
    exposure_graph: Annotated[Any, Field(description="Optional Microsoft Security Exposure Management export: ExposureGraphEdges rows from advanced hunting (e.g. from lab/defender/blast_radius.kql), passed through unchanged. Supplies the blast radius.")] = [],
    scenario: Annotated[str, Field(description="OPTIONAL override. Normally the recovery playbook is derived from the incident. Comma-separate for chained attacks, e.g. 'identity_compromise,ransomware'.")] = "",
    t0: Annotated[str, Field(description="Optional override of the compromise time (ISO 8601).")] = "",
    dwell_time_hours: Annotated[float, Field(description="Optional dwell time in hours; defaults to the graph value, then the playbook default.")] = -1,
    recovery_group_name: Annotated[str, Field(description="Optional existing Cleanroom recovery group to check against this incident (recovery point setting, order, membership).")] = "",
    application_name: Annotated[str, Field(description="Optional application with an approved recovery definition; its other members are recovered too for consistency.")] = "",
) -> dict:
    """
    Builds a phased recovery runbook for a security incident. Give it the raw incident (Cortex or Microsoft Defender XDR)
    and the reachability graph (Wiz or Microsoft Security Exposure Management), or a graph in the tool format; the recovery playbook (identity compromise, cloud IAM compromise, ransomware, data tampering,
    malicious update, or a combination) is derived from the incident automatically unless overridden.
    Phases: contain and preserve evidence, trusted recovery plane, clean recovery points (e.g. never LATEST after an
    identity compromise), recover affected workloads in dependency order with per-resource points and readiness gates,
    validate, rotate credentials, reconnect. Each step is marked AUTO (Commvault) or MANUAL (owner team). Also checks an
    existing recovery group against the incident. Read-only: nothing is executed. Includes a markdown version.
    """
    try:
        return _runbook_from_inputs(graph, cortex_incident, wiz_graph, scenario, t0, dwell_time_hours,
                                    recovery_group_name, application_name, defender_incident, exposure_graph)
    except ValueError as e:
        return {"status": "INVALID_INPUT", "reason": str(e)}
    except Exception as e:
        logger.error(f"Error building scenario runbook: {e}")
        return ToolError({"error": str(e)})


RECOVERY_ASSURANCE_TOOLS = [
    discover_recovery_application,
    generate_recovery_sequence,
    approve_recovery_map,
    detect_recovery_drift,
    audit_recovery_order,
    list_recovery_scenarios,
    import_security_context,
    assess_blast_radius,
    build_scenario_runbook,
    preview_recovery_group,
    create_recovery_group,
]
