# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Read-only adapter between the Commvault REST API and the recovery-discovery engine.

Every Commvault response shape the engine depends on is parsed HERE and nowhere else,
so when a real CommCell returns something slightly different from the documented shape,
only this file changes. Lines marked `LAB-VALIDATE` are the field paths we expect to
confirm or adjust against an 11.46 CommCell.

This module never issues POST/PUT/DELETE. It only calls `api.get(...)`.
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional

SUCCESS_STATUSES = {"completed", "completed w/ one or more errors", "completed w/ one or more warnings"}
IMMUTABILITY_KEYS = ("isImmutable", "immutable", "enableWORM", "wormStoragePoolFlag", "isWormStorage")
AIR_GAP_HINTS = ("AIR_GAP", "AIRGAP", "METALLIC", "CLOUD_VAULT")


def _first(d: Any, *paths: str, default=None):
    """Return the first non-None value found among dotted paths."""
    for path in paths:
        cur = d
        ok = True
        for part in path.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
                cur = cur[int(part)]
            else:
                ok = False
                break
        if ok and cur is not None:
            return cur
    return default


class CommvaultReader:
    """Thin, defensive, read-only view of a CommCell."""

    def __init__(self, api):
        self.api = api
        self.calls: List[str] = []  # audit trail of endpoints touched

    def _get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.calls.append(endpoint + (f"?{params}" if params else ""))
        resp = self.api.get(endpoint, params=params)
        if not isinstance(resp, dict):
            raise ValueError(f"Unexpected response from {endpoint}")
        return resp

    # ---------------------------------------------------------------- clients
    def list_clients(self) -> List[Dict[str, Any]]:
        resp = self._get("Client")
        out = []
        for item in resp.get("clientProperties", []):
            ent = _first(item, "client.clientEntity", default={})  # LAB-VALIDATE
            if ent.get("clientId") is not None:
                out.append({
                    "id": str(ent.get("clientId")),
                    "name": ent.get("clientName"),
                    "displayName": ent.get("displayName") or ent.get("clientName"),
                    "hostName": ent.get("hostName"),
                })
        return out

    def resolve_client(self, name_or_id: str) -> Optional[Dict[str, Any]]:
        """Resolve a seed (client name, display name, hostname or numeric id) to a client."""
        seed = name_or_id.strip()
        if seed.isdigit():
            return self.get_client(seed)
        try:
            resp = self._get("getid", params={"clientname": seed})
            cid = _first(resp, "clientId", "client.clientId")  # LAB-VALIDATE
            if cid not in (None, "", 0, "0", -1, "-1"):
                return self.get_client(str(cid))
        except Exception:
            pass
        # Fallback: case-insensitive match on name / display name / hostname / short hostname.
        s = seed.lower()
        for c in self.list_clients():
            names = {str(c.get("name") or "").lower(), str(c.get("displayName") or "").lower(),
                     str(c.get("hostName") or "").lower(), str(c.get("hostName") or "").lower().split(".")[0]}
            if s in names:
                return self.get_client(c["id"])
        return None

    def get_client(self, client_id: str) -> Optional[Dict[str, Any]]:
        resp = self._get(f"Client/{client_id}")
        props = _first(resp, "clientProperties.0")  # LAB-VALIDATE
        if not props:
            return None
        ent = _first(props, "client.clientEntity", default={})
        groups = [
            {"id": str(g.get("clientGroupId")), "name": g.get("clientGroupName")}
            for g in props.get("clientGroups", []) or []
            if g.get("clientGroupId") is not None
        ]
        is_vm = bool(
            _first(props, "clientProps.IsVirtualClient", "clientProps.isVirtualClient", default=False)  # LAB-VALIDATE
            or props.get("vmStatusInfo")
        )
        return {
            "id": str(ent.get("clientId", client_id)),
            "name": ent.get("clientName"),
            "displayName": ent.get("displayName") or ent.get("clientName"),
            "hostName": ent.get("hostName"),
            "type": "VM" if is_vm else "Server",
            "groups": groups,
        }

    # ----------------------------------------------------------------- agents
    def get_agents(self, client_id: str) -> List[str]:
        try:
            resp = self._get("Agent", params={"clientId": client_id})
        except Exception:
            return []
        apps = []
        for a in resp.get("agentProperties", []) or []:
            name = _first(a, "idaEntity.appName")  # LAB-VALIDATE
            if name and name not in apps:
                apps.append(name)
        return apps

    # ------------------------------------------------------------- subclients
    def get_subclients(self, client_id: str) -> List[Dict[str, Any]]:
        resp = self._get("subclient", params={"clientId": client_id})
        out = []
        for sc in resp.get("subClientProperties", []) or []:
            e = sc.get("subClientEntity", {})
            if e.get("subclientId") is None:
                continue
            out.append({
                "id": str(e.get("subclientId")),
                "name": e.get("subclientName"),
                "appName": e.get("appName"),
                "instanceName": e.get("instanceName"),
                "backupsetName": e.get("backupsetName"),
            })
        return out

    def get_subclient_detail(self, subclient_id: str) -> Dict[str, Any]:
        resp = self._get(f"subclient/{subclient_id}")
        p = _first(resp, "subClientProperties.0", default={})
        plan = p.get("planEntity") or {}  # LAB-VALIDATE
        databases = []
        for c in p.get("content", []) or []:
            db = _first(c, "mssqlDbContent.databaseName", "oracleContent.databaseName", "dbContent.databaseName")  # LAB-VALIDATE
            if db:
                databases.append(db)
        return {
            "planId": str(plan["planId"]) if plan.get("planId") is not None else None,
            "planName": plan.get("planName"),
            "storagePolicy": _first(p, "commonProperties.storageDevice.dataBackupStoragePolicy.storagePolicyName"),
            "databases": databases,
        }

    # ------------------------------------------------------------------ plans
    def get_plan(self, plan_id: str) -> Dict[str, Any]:
        resp = self._get(f"v4/serverplan/{plan_id}")  # LAB-VALIDATE (server plans; other plan types differ)
        copies = []
        for d in resp.get("backupDestinations", []) or []:
            pool = d.get("storagePool") or {}
            storage_type = str(d.get("storageType") or pool.get("type") or "")
            immut = None
            for k in IMMUTABILITY_KEYS:
                if k in d or k in pool:
                    immut = bool(d.get(k, pool.get(k)))
                    break
            copies.append({
                "name": _first(d, "planBackupDestination.name", "backupDestinationName", default="copy"),
                "storagePool": pool.get("name"),
                "region": _first(d, "region.displayName", "region.name"),
                "isPrimary": not bool(d.get("isMirrorCopy") or d.get("isSecondary")) and bool(d.get("isDefault", True)),
                "retentionDays": d.get("retentionPeriodDays"),
                "immutable": immut,  # None = could not be determined from the API
                "airGapped": any(h in storage_type.upper() or h in str(pool.get("name", "")).upper() for h in AIR_GAP_HINTS)
                if storage_type or pool.get("name") else None,
            })
        if copies and not any(c["isPrimary"] for c in copies):
            copies[0]["isPrimary"] = True
        return {"id": str(plan_id), "name": _first(resp, "plan.name", "planName", "name"), "copies": copies}

    # ------------------------------------------------------------------- jobs
    def get_recent_backups(self, client_id: str, lookback_hours: int = 168) -> List[Dict[str, Any]]:
        params = {"clientId": client_id, "jobFilter": "Backup", "completedJobLookupTime": lookback_hours * 3600}
        try:
            resp = self._get("Job", params=params)
        except Exception:
            return []
        out = []
        for j in resp.get("jobs", []) or []:
            s = j.get("jobSummary", {})
            out.append({
                "jobId": s.get("jobId"),
                "status": s.get("status"),
                "success": str(s.get("status", "")).lower() in SUCCESS_STATUSES,
                "endTime": s.get("jobEndTime"),
                "subclientId": str(_first(s, "subclient.subclientId", default="")),
                "subclientName": _first(s, "subclient.subclientName"),
                "level": s.get("backupLevelName"),
            })
        return out

    # -------------------------------------------------------- recovery groups
    def get_recovery_group(self, name: str) -> Optional[Dict[str, Any]]:
        """Cleanroom recovery group with per-entity execution priority (1 = recovered first)."""
        resp = self._get("V4/RecoveryGroups")  # LAB-VALIDATE path; response field 'recoveryGroups' per API docs
        match = next((g for g in resp.get("recoveryGroups", []) or []
                      if str(g.get("name", "")).lower() == name.strip().lower()), None)
        if not match:
            return None
        detail = self._get(f"V4/RecoveryGroups/{match['id']}", params={"getEntityDetails": "true"})  # LAB-VALIDATE path
        entities = []
        for e in detail.get("entities", []) or []:
            eo = _first(e, "recoveryConfiguration.executionOrder", default={}) or {}  # per API docs
            entities.append({
                "name": _first(e, "name", "virtualMachine.name", "client.name", "entity.name"),
                "priority": eo.get("priority"),
                "order": eo.get("order"),
            })
        return {"id": str(match["id"]), "name": _first(detail, "recoveryGroup.name", default=match.get("name")),
                "delayBetweenPrioritiesMinutes": _first(detail, "recoveryGroup.delayBetweenPriorityMachines"),
                "entities": [e for e in entities if e["name"]]}

    # ---------------------------------------------------------- client groups
    def get_group_members(self, group_id: str) -> List[Dict[str, Any]]:
        resp = self._get(f"ClientGroup/{group_id}")
        members = _first(resp, "clientGroupDetail.associatedClients", default=[]) or []  # LAB-VALIDATE
        return [{"id": str(m.get("clientId")), "name": m.get("clientName")} for m in members if m.get("clientId") is not None]


def now_epoch() -> int:
    return int(time.time())


def name_tokens(name: str) -> List[str]:
    return [t for t in re.split(r"[-_.\s]+", (name or "").lower()) if t]
