# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Read-only adapter between the Commvault REST API and the recovery-discovery engine.

Every Commvault response shape the engine depends on is parsed HERE and nowhere else,
so when a real CommCell returns something slightly different from the documented shape,
only this file changes. Lines marked `LAB-VALIDATE` are the field paths we expect to
confirm or adjust against an 11.46 CommCell.

This module never issues POST/PUT/DELETE. It only calls `api.get(...)`.
"""

from __future__ import annotations

import re
import time
from typing import Any, Dict, List, Optional

SUCCESS_STATUSES = {"completed", "completed w/ one or more errors", "completed w/ one or more warnings"}
RECOVERY_GROUP_PATHS = ("V4/RecoveryGroups",)                     # V4 list returned {} on the 11.46 lab
RECOVERY_GROUP_DETAIL_PATHS = ("RecoveryGroup", "RecoveryGroups", "V4/RecoveryGroups")  # 11.46 lab: RecoveryGroup/<id> = 200, others 403
SYSTEM_DATABASES = {"master", "model", "msdb", "tempdb", "distribution", "sysdb"}


def _first(d: Any, *paths: str, default=None):
    """Return the first non-None value found among dotted paths."""
    for path in paths:
        cur = d
        ok = True
        for part in path.split("."):
            if isinstance(cur, dict) and part in cur:
                cur = cur[part]
            elif isinstance(cur, list) and part.isdigit() and int(part) < len(cur):
                cur = cur[int(part)]
            else:
                ok = False
                break
        if ok and cur is not None:
            return cur
    return default


class CommvaultReader:
    """Thin, defensive, read-only view of a CommCell."""

    def __init__(self, api):
        self.api = api
        self.calls: List[str] = []  # audit trail of endpoints touched

    def _get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self.calls.append(endpoint + (f"?{params}" if params else ""))
        resp = self.api.get(endpoint, params=params)
        if not isinstance(resp, dict):
            raise ValueError(f"Unexpected response from {endpoint}")
        return resp

    # ---------------------------------------------------------------- clients
    def list_clients(self) -> List[Dict[str, Any]]:
        resp = self._get("Client")
        out = []
        for item in resp.get("clientProperties", []):
            ent = _first(item, "client.clientEntity", default={})  # LAB-VALIDATE
            if ent.get("clientId") is not None:
                out.append({
                    "id": str(ent.get("clientId")),
                    "name": ent.get("clientName"),
                    "displayName": ent.get("displayName") or ent.get("clientName"),
                    "hostName": ent.get("hostName"),
                })
        return out

    def resolve_client(self, name_or_id: str) -> Optional[Dict[str, Any]]:
        """Resolve a seed (client name, display name, hostname or numeric id) to a client."""
        seed = name_or_id.strip()
        if seed.isdigit():
            return self.get_client(seed)
        try:
            resp = self._get("getid", params={"clientname": seed})
            cid = _first(resp, "clientId", "client.clientId")  # LAB-VALIDATE
            if cid not in (None, "", 0, "0", -1, "-1"):
                return self.get_client(str(cid))
        except Exception:
            pass
        # Fallback: case-insensitive match on name / display name / hostname / short hostname.
        s = seed.lower()
        for c in self.list_clients():
            names = {str(c.get("name") or "").lower(), str(c.get("displayName") or "").lower(),
                     str(c.get("hostName") or "").lower(), str(c.get("hostName") or "").lower().split(".")[0]}
            if s in names:
                return self.get_client(c["id"])
        return None

    def get_client(self, client_id: str) -> Optional[Dict[str, Any]]:
        resp = self._get(f"Client/{client_id}")
        props = _first(resp, "clientProperties.0")  # LAB-VALIDATE
        if not props:
            return None
        ent = _first(props, "client.clientEntity", default={})
        groups = [
            {"id": str(g.get("clientGroupId")), "name": g.get("clientGroupName")}
            for g in props.get("clientGroups", []) or []
            if g.get("clientGroupId") is not None
        ]
        is_vm = bool(
            _first(props, "clientProps.IsVirtualClient", "clientProps.isVirtualClient", default=False)  # LAB-VALIDATE
            or props.get("vmStatusInfo")
        )
        linked = []
        dag = _first(props, "clientProps.DAGpseudoClient")  # 11.46: Exchange server -> its DAG pseudo-client
        if isinstance(dag, dict) and dag.get("clientId") not in (None, 0, str(ent.get("clientId"))):
            linked.append({"id": str(dag["clientId"]), "name": dag.get("clientName"),
                           "reason": "Exchange DAG pseudo-client that holds this server's Exchange protection"})
        return {
            "id": str(ent.get("clientId", client_id)),
            "name": ent.get("clientName"),
            "displayName": ent.get("displayName") or ent.get("clientName"),
            "hostName": ent.get("hostName"),
            "type": "VM" if is_vm else "Server",
            "groups": groups,
            "linkedClients": linked,
        }

    # ----------------------------------------------------------------- agents
    def get_agents(self, client_id: str) -> List[str]:
        try:
            resp = self._get("Agent", params={"clientId": client_id})
        except Exception:
            return []
        apps = []
        for a in resp.get("agentProperties", []) or []:
            name = _first(a, "idaEntity.appName")  # LAB-VALIDATE
            if name and name not in apps:
                apps.append(name)
        return apps

    # ------------------------------------------------------------- subclients
    def get_subclients(self, client_id: str) -> Optional[List[Dict[str, Any]]]:
        try:
            resp = self._get("subclient", params={"clientId": client_id})
        except Exception as e:
            # 11.46 returns HTTP 404 for clients whose subclients this endpoint cannot list (seen on exchange1,
            # which IS protected by an Exchange agent subclient). None = "unknown", never "unprotected".
            if "404" in str(e):
                return None
            raise
        out = []
        for sc in resp.get("subClientProperties", []) or []:
            e = sc.get("subClientEntity", {})
            if e.get("subclientId") is None:
                continue
            out.append({
                "id": str(e.get("subclientId")),
                "name": e.get("subclientName"),
                "appName": e.get("appName"),
                "instanceName": e.get("instanceName"),
                "backupsetName": e.get("backupsetName"),
            })
        return out

    def get_subclient_detail(self, subclient_id: str) -> Dict[str, Any]:
        resp = self._get(f"subclient/{subclient_id}")
        p = _first(resp, "subClientProperties.0", default={})
        plan = p.get("planEntity") or {}  # LAB-VALIDATE
        databases = []
        for c in p.get("content", []) or []:
            db = _first(c, "mssqlDbContent.databaseName", "exchangeDBContent.databaseName", "oracleContent.databaseName",
                        "dbContent.databaseName")
            if db:
                databases.append(db)
        return {
            "planId": str(plan["planId"]) if plan.get("planId") is not None else None,
            "planName": plan.get("planName"),
            "storagePolicy": _first(p, "commonProperties.storageDevice.dataBackupStoragePolicy.storagePolicyName"),
            "databases": databases,
        }

    # ------------------------------------------------------------------ plans
    def get_plan(self, plan_id: str) -> Dict[str, Any]:
        """Server plan copies. Field semantics validated on an 11.46 CommCell (2026-10-20 lab probe)."""
        resp = self._get(f"v4/serverplan/{plan_id}")
        copies = []
        for d in resp.get("backupDestinations", []) or []:
            pool = d.get("storagePool") or {}
            device = str(_first(pool, "deviceType.name", default="")).upper()
            dest_name = str(_first(d, "planBackupDestination.name", default="copy"))
            region = _first(pool, "region.displayName") or _first(d, "region.displayName") or ""
            worm = pool.get("wormStoragePoolFlag")
            # Immutability evidence, strongest first.
            if d.get("complianceLock") is True:
                immut, immut_ev = True, "compliance lock enabled on copy"
            elif (d.get("dataRetentionLockDays") or 0) > 0:
                immut, immut_ev = True, f"retention lock {d['dataRetentionLockDays']} days"
            elif isinstance(worm, int) and worm & 1:
                immut, immut_ev = True, f"WORM flag on storage pool ({worm})"  # LAB-VALIDATE bit meaning
            else:
                immut, immut_ev = False, "no compliance/retention lock or WORM flag"
            air = ("RECOVERY_RESERVE" in device or "AIR_GAP" in device or "AIRGAP" in device
                   or re.search(r"air\s*gap", dest_name, re.I) is not None)
            is_snap = bool(d.get("isSnapCopy")) or "SNAP" in str(d.get("copyTypeName", "")).upper()
            copies.append({
                "name": dest_name,
                "storagePool": pool.get("name"),
                "storageType": d.get("storageType"),
                "deviceType": device or None,
                "region": region or "on-premises",
                "isPrimary": bool(d.get("isDefault")),
                "isSnapshot": is_snap,
                "retentionDays": d.get("retentionPeriodDays"),
                "immutable": immut,
                "immutableEvidence": immut_ev,
                "airGapped": air,
            })
        if copies and not any(c["isPrimary"] for c in copies):
            non_snap = [c for c in copies if not c["isSnapshot"]] or copies
            non_snap[0]["isPrimary"] = True
        return {"id": str(plan_id), "name": _first(resp, "plan.name", "planName", "name"),
                "tier": resp.get("planTier"), "copies": copies}

    # ------------------------------------------------------------------- jobs
    def get_recent_backups(self, client_id: str, lookback_hours: int = 168) -> List[Dict[str, Any]]:
        params = {"clientId": client_id, "jobFilter": "Backup", "completedJobLookupTime": lookback_hours * 3600}
        try:
            resp = self._get("Job", params=params)
        except Exception:
            return []
        out = []
        for j in resp.get("jobs", []) or []:
            s = j.get("jobSummary", {})
            out.append({
                "jobId": s.get("jobId"),
                "status": s.get("status"),
                "success": str(s.get("status", "")).lower() in SUCCESS_STATUSES,
                "endTime": s.get("jobEndTime"),
                "subclientId": str(_first(s, "subclient.subclientId", default="")),
                "subclientName": _first(s, "subclient.subclientName"),
                "appName": s.get("appTypeName") or _first(s, "subclient.appName"),
                "level": s.get("backupLevelName"),
            })
        return out

    # -------------------------------------------------------- recovery groups
    def get_recovery_group(self, name: str) -> Optional[Dict[str, Any]]:
        """Cleanroom recovery group with per-entity execution priority (1 = recovered first).

        Chain observed in Command Center 11.46 (2026-10-20 lab):
          Security/Assembly                 -> assemblies[] {id, name, resourcesCount, runbooksCount, isRGMigrated}
          RecoveryGroups?assemblyId=<id>    -> recoveryGroups[] {id, name, vendor, entityCount, runbook, target}
          <detail>/<rgId>?getEntityDetails  -> entities[].recoveryConfiguration.executionOrder.priority (per API docs)
          ClientGroup/<assemblyId>          -> members (assembly id == client group id), used when no priorities
        """
        want = name.strip().lower()
        assembly, rg = None, None
        try:
            for a in self._get("Security/Assembly").get("assemblies", []) or []:
                if str(a.get("name", "")).lower() == want:
                    assembly = a
                    break
        except Exception:
            pass
        lists = ([("RecoveryGroups", {"assemblyId": assembly["id"]})] if assembly else []) + \
                [("RecoveryGroups", None)] + [(p, None) for p in RECOVERY_GROUP_PATHS]
        for path, params in lists:
            try:
                groups = self._get(path, params=params).get("recoveryGroups") or []
            except Exception:
                continue
            rg = next((g for g in groups if str(g.get("name", "")).lower() == want), None) or \
                (groups[0] if assembly and params and len(groups) == 1 else None)
            if rg:
                break
        if not rg and not assembly:
            return None

        entities, priority_source = [], None
        if rg:
            for path in RECOVERY_GROUP_DETAIL_PATHS:  # LAB-VALIDATE: which detail path returns entities
                try:
                    detail = self._get(f"{path}/{rg['id']}", params={"getEntityDetails": "true"})
                except Exception:
                    continue
                for e in detail.get("entities", []) or []:
                    # 11.46: entities[].executionOrder.priority (API docs: recoveryConfiguration.executionOrder)
                    eo = _first(e, "executionOrder", "recoveryConfiguration.executionOrder", default={}) or {}
                    n = _first(e, "name", "virtualMachine.name", "client.name", "entity.name")
                    if n:
                        entities.append({"name": n, "priority": eo.get("priority"), "order": eo.get("order")})
                if entities:
                    # Only claim priorities if the API actually returned them; otherwise an audit would
                    # report a false "compliant".
                    priority_source = path if any(e["priority"] is not None for e in entities) else None
                    break
        if not entities and assembly:
            try:
                entities = [{"name": m["name"], "priority": None, "order": None}
                            for m in self.get_group(str(assembly["id"]))["members"]]
            except Exception:
                pass
        return {
            "id": str(rg["id"]) if rg else None,
            "name": (rg or assembly).get("name"),
            "assemblyId": str(assembly["id"]) if assembly else None,
            "runbook": _first(rg or {}, "runbook.name"),
            "target": _first(rg or {}, "target.name"),
            "vendor": (rg or {}).get("vendor"),
            "recoveryPointCategory": _rp_category(_first(rg or {}, "recoveryPointDetails.recoveryPointCategory")),
            "prioritiesAvailable": priority_source is not None,
            "entities": entities,
        }

    # ---------------------------------------------------------- client groups
    def get_group(self, group_id: str) -> Dict[str, Any]:
        """Client group with its kind. Kinds validated on 11.46:
        application_assembly  configurationGroupType 2 / isRGMigrated (created from a recovery group) -> strong app evidence
        configuration         configuration groups (e.g. 'ThreatScan configuration group')         -> not app evidence
        smart                 rule-based smart client groups                                       -> not app evidence
        manual                plain groups; infrastructure-named ones (ESX1, vCenter, ...) are filtered later
        """
        resp = self._get(f"ClientGroup/{group_id}")
        d = resp.get("clientGroupDetail", {}) or {}
        name = _first(d, "clientGroup.clientGroupName", default="")
        desc = d.get("description") or ""
        cfg_type = d.get("configurationGroupType")
        if cfg_type == 2 or d.get("isRGMigrated") or re.search(r"recovery group", desc, re.I):
            kind = "application_assembly"
        elif re.search(r"configuration group", name, re.I) or (isinstance(cfg_type, int) and cfg_type not in (0, 2)):
            kind = "configuration"
        elif d.get("isSmartClientGroup") or d.get("isCompanySmartClientGroup"):
            kind = "smart"
        else:
            kind = "manual"
        members = [{"id": str(m.get("clientId")), "name": m.get("clientName")}
                   for m in d.get("associatedClients", []) or [] if m.get("clientId") is not None]
        return {"id": str(group_id), "name": name, "description": desc, "kind": kind, "members": members}

    def get_group_members(self, group_id: str) -> List[Dict[str, Any]]:
        return self.get_group(group_id)["members"]


RECOVERY_POINT_CATEGORIES = {0: "LATEST"}  # 11.46: raw API returns 0 where Command Center shows "LATEST"


def _rp_category(v: Any) -> Optional[str]:
    if v is None:
        return None
    if isinstance(v, int) or (isinstance(v, str) and v.isdigit()):
        return RECOVERY_POINT_CATEGORIES.get(int(v), f"CATEGORY_{int(v)}")
    return str(v).upper()


def now_epoch() -> int:
    return int(time.time())


def name_tokens(name: str) -> List[str]:
    return [t for t in re.split(r"[-_.\s]+", (name or "").lower()) if t]
