# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Recovery-application discovery engine.

Given ONE seed resource supplied by the application owner, build an evidence-based
recovery map from what Commvault itself knows. Rules:

  * Every relationship carries `evidence` (why we believe it) and a `confidence`.
  * Nothing is inferred by an LLM. Candidates come only from deterministic signals
    (shared client group, naming convention) and are labelled as needing owner review.
  * What Commvault cannot see (DNS, AD, network, SaaS, external dependencies) is
    reported explicitly as unknown rather than silently omitted.
  * Read-only: the engine only performs GET requests through CommvaultReader.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from src.recovery.cv_reader import SYSTEM_DATABASES, CommvaultReader, name_tokens, now_epoch

CONFIRMED, HIGH, MEDIUM, LOW = "confirmed", "high", "medium", "low"
GENERIC_TOKENS = {"prod", "prd", "dev", "test", "qa", "uat", "srv", "server", "vm", "win", "lnx",
                  "linux", "sql", "db", "web", "app", "api", "01", "02", "03", "dc", "host"}
INFRA_GROUP = re.compile(
    r"^(esx|esxi|vcenter|vc\d|hyper-?v|hv\d|cluster|datastore|hosts?\b|all\b|default|servers?\b|vms?\b|windows|linux|unix|"
    r"laptops?|desktops?|endpoints?|infra|proxy|proxies|media ?agents?|index ?servers?)"
    r"|\b(esxi?\d*|vcenter|hyper-?v|datastore|all (servers|clients|vms|production vms))\b", re.I)
INFRA_AGENTS = {"virtual server", "file system", "windows file system", "linux file system", "unix file system"}

OUTSIDE_COMMVAULT = [
    "Identity services the application authenticates against (Active Directory / Entra ID / LDAP)",
    "DNS records and load-balancer / ingress entries that route users to the application",
    "Network and firewall policy required for the application to function after recovery",
    "Secrets, certificates and key-management dependencies",
    "Upstream/downstream services and SaaS integrations the application calls",
    "Resources that belong to the application but are not protected by this CommCell at all",
]


def _iso(epoch: Optional[int]) -> Optional[str]:
    if not epoch:
        return None
    return datetime.fromtimestamp(int(epoch), tz=timezone.utc).isoformat().replace("+00:00", "Z")


class RecoveryDiscovery:
    def __init__(self, reader: CommvaultReader, rpo_hours: int = 24, max_group_size: int = 25,
                 include_name_heuristic: bool = True):
        self.r = reader
        self.rpo_hours = rpo_hours
        self.max_group_size = max_group_size
        self.include_name_heuristic = include_name_heuristic
        self._plan_cache: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------ profiling
    def _plan(self, plan_id: str) -> Dict[str, Any]:
        if plan_id not in self._plan_cache:
            try:
                self._plan_cache[plan_id] = self.r.get_plan(plan_id)
            except Exception:
                self._plan_cache[plan_id] = {"id": plan_id, "name": None, "copies": [], "unreadable": True}
        return self._plan_cache[plan_id]

    def profile(self, client: Dict[str, Any]) -> Dict[str, Any]:
        """Protection profile for one client: agents, subclients, plans, last good backup.

        If the subclient list cannot be read (11.46 answers 404 for e.g. Exchange agent clients), protection is
        decided from backup job history instead, and subclients are reconstructed from those jobs. A client is only
        reported unprotected when the evidence says so; otherwise its protection is "unknown"."""
        cid = client["id"]
        agents = self.r.get_agents(cid)
        listed = self.r.get_subclients(cid)
        listing_ok = listed is not None
        lookback = max(self.rpo_hours * 7, 168) if listing_ok else max(self.rpo_hours * 30, 720)
        backups = self.r.get_recent_backups(cid, lookback_hours=lookback)
        via = []
        # Protection held by a linked client (e.g. Exchange DAG pseudo-client): merge its agents, subclients and jobs.
        for lc in client.get("linkedClients", []) or []:
            try:
                l_sub = self.r.get_subclients(lc["id"]) or []
                l_jobs = self.r.get_recent_backups(lc["id"], lookback_hours=max(self.rpo_hours * 30, 720))
                for a in self.r.get_agents(lc["id"]):
                    if a not in agents:
                        agents.append(a)
            except Exception:
                continue
            for sc in l_sub:
                sc["viaClient"] = lc["name"]
            listed = (listed or []) + l_sub
            backups = backups + l_jobs
            listing_ok = listing_ok or bool(l_sub)
            via.append(f"{lc['name']} (id {lc['id']}): {lc['reason']}")
        if listing_ok:
            subclients = listed
        else:  # reconstruct subclients from job history
            seen: Dict[str, Dict[str, Any]] = {}
            for b in backups:
                if b["subclientId"] and b["subclientId"] not in seen:
                    seen[b["subclientId"]] = {"id": b["subclientId"], "name": b.get("subclientName") or "unknown",
                                              "appName": b.get("appName"), "instanceName": None, "backupsetName": None,
                                              "fromJobHistory": True}
            subclients = list(seen.values())
        plans: Dict[str, Dict[str, Any]] = {}
        for sc in subclients:
            try:
                d = self.r.get_subclient_detail(sc["id"])
            except Exception:
                d = {"planId": None, "planName": None, "storagePolicy": None, "databases": []}
            sc.update({k: d[k] for k in ("planId", "planName", "storagePolicy", "databases")})
            good = [b for b in backups if b["success"] and b["subclientId"] == sc["id"] and b["endTime"]]
            sc["lastGoodBackupEpoch"] = max((b["endTime"] for b in good), default=None)
            sc["lastGoodBackup"] = _iso(sc["lastGoodBackupEpoch"])
            if d["planId"]:
                try:
                    plans[d["planId"]] = self._plan(d["planId"])
                except Exception:
                    pass
        good_all = [b["endTime"] for b in backups if b["success"] and b["endTime"]]
        latest = max(good_all, default=None)
        hours_since = round((now_epoch() - int(latest)) / 3600, 1) if latest else None
        has_plan = any(sc.get("planId") or sc.get("storagePolicy") for sc in subclients)
        if listing_ok:
            protected, unknown = bool(subclients) and has_plan, False
            evidence = "subclient associated with a plan/storage policy" if protected else "no subclient with a plan/storage policy"
            if via:
                evidence += "; protection held by linked client " + "; ".join(via)
        elif good_all:
            protected, unknown = True, False
            evidence = f"{len(good_all)} successful backup job(s) in the last {lookback // 24} days (subclient list not available via API)"
        else:
            protected, unknown = False, True
            evidence = "subclient list not available via API and no successful backup job found; verify in Command Center"
        return {
            "agents": agents,
            "subclients": subclients,
            "plans": list(plans.values()),
            "protected": protected,
            "protectionUnknown": unknown,
            "protectionEvidence": evidence,
            "latestRecoveryPoint": _iso(latest),
            "hoursSinceLastGoodBackup": hours_since,
        }

    # ------------------------------------------------------------- discover
    def discover(self, seed_resource: str, application_name: Optional[str] = None) -> Dict[str, Any]:
        app = application_name or seed_resource
        seed = self.r.resolve_client(seed_resource)
        if not seed:
            return {
                "application": app, "seed": seed_resource, "status": "SEED_NOT_FOUND", "readOnly": True,
                "summary": f"'{seed_resource}' was not found in this CommCell (checked client name, display name, hostname).",
                "nextStep": "Confirm the exact Commvault client name of one production resource of the application.",
            }

        resources: List[Dict[str, Any]] = []
        relationships: List[Dict[str, Any]] = []
        notes: List[str] = []

        seed_profile = self.profile(seed)
        resources.append(self._resource(seed, "seed", CONFIRMED,
                                        ["Provided by application owner as the seed resource",
                                         f"Resolved to Commvault client id {seed['id']}"], seed_profile))
        self._component_edges(seed, seed_profile, relationships)

        # ---- candidate siblings (deterministic signals only)
        candidates: Dict[str, Dict[str, Any]] = {}
        for g in seed.get("groups", []):
            try:
                grp = self.r.get_group(g["id"])
            except Exception:
                notes.append(f"Client group '{g['name']}' could not be read.")
                continue
            members, kind = grp["members"], grp["kind"]
            if kind in ("configuration", "smart"):
                notes.append(f"Client group '{grp['name']}' is a {kind} group (operational grouping); not used as application evidence.")
                continue
            if kind == "manual" and INFRA_GROUP.search(grp["name"] or ""):
                notes.append(f"Client group '{grp['name']}' looks like an infrastructure grouping (hypervisor/host/OS); "
                             "not used as application evidence.")
                continue
            if len(members) > self.max_group_size:
                notes.append(f"Client group '{grp['name']}' has {len(members)} members; too broad to imply "
                             f"application membership (limit {self.max_group_size}), ignored.")
                continue
            strong = kind == "application_assembly"
            for m in members:
                if m["id"] == seed["id"]:
                    continue
                c = candidates.setdefault(m["id"], {"id": m["id"], "name": m["name"], "evidence": [], "score": 0})
                if strong:
                    c["evidence"].append(f"In application group '{grp['name']}' with the seed (group created from a Commvault recovery group)")
                    c["score"] += 3
                else:
                    c["evidence"].append(f"Shares Commvault client group '{grp['name']}' with the seed")
                    c["score"] += 2

        if self.include_name_heuristic:
            seed_tokens = name_tokens(seed.get("name"))
            anchors = {t for t in name_tokens(app) if t not in GENERIC_TOKENS and len(t) > 2}
            if seed_tokens and seed_tokens[0] not in GENERIC_TOKENS and len(seed_tokens[0]) > 2:
                anchors.add(seed_tokens[0])
            if anchors:
                try:
                    for c in self.r.list_clients():
                        if c["id"] == seed["id"]:
                            continue
                        hit = anchors.intersection(name_tokens(c.get("name")))
                        if hit:
                            cand = candidates.setdefault(c["id"], {"id": c["id"], "name": c["name"], "evidence": [], "score": 0})
                            cand["evidence"].append(f"Naming convention match on '{sorted(hit)[0]}' (heuristic only)")
                            cand["score"] += 1
                except Exception:
                    notes.append("Client list could not be read; naming-convention matching skipped.")

        for lc in seed.get("linkedClients", []) or []:
            if candidates.pop(lc["id"], None) is not None:
                notes.append(f"{lc['name']} is the seed's linked client ({lc['reason']}); merged into the seed, not a candidate.")
        for cand in candidates.values():
            # Application group (from a recovery group) or two independent signals -> high;
            # one shared plain group -> medium; naming alone -> low.
            conf = HIGH if cand["score"] >= 3 else (MEDIUM if cand["score"] == 2 else LOW)
            full = self.r.get_client(cand["id"]) or {"id": cand["id"], "name": cand["name"], "type": "Unknown", "groups": []}
            try:
                prof = self.profile(full)
            except Exception as e:
                notes.append(f"Candidate {full['name']}: protection details could not be read ({str(e)[:120]}).")
                continue
            resources.append(self._resource(full, "candidate", conf, cand["evidence"], prof, needs_review=True))
            relationships.append({"from": app, "to": full["name"], "type": "possible_member", "confidence": conf,
                                  "evidence": cand["evidence"]})

        gaps = self._gaps(resources)
        core = [r for r in resources if r["role"] != "candidate"]
        cands = [r for r in resources if r["role"] == "candidate"]
        summary = self._summary(app, seed, seed_profile, cands, gaps)

        return {
            "application": app,
            "seed": seed_resource,
            "status": "DISCOVERED",
            "discoveredAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "readOnly": True,
            "summary": summary,
            "resources": resources,
            "relationships": relationships,
            "gaps": gaps,
            "unknownOutsideCommvault": OUTSIDE_COMMVAULT,
            "notes": notes,
            "counts": {"confirmedResources": len(core), "candidatesNeedingReview": len(cands),
                       "gaps": len(gaps), "commvaultApiCalls": len(self.r.calls)},
            "nextStep": ("Ask the application owner to confirm or reject each candidate, then call "
                         "approve_recovery_map to freeze this as the approved recovery definition."
                         if cands else
                         "Ask the application owner whether anything is missing, then call approve_recovery_map."),
        }

    # ------------------------------------------------------------- helpers
    def _resource(self, client, role, confidence, evidence, prof, needs_review=False):
        return {
            "name": client.get("name"),
            "id": client.get("id"),
            "type": client.get("type"),
            "role": role,
            "confidence": confidence,
            "needsOwnerReview": needs_review,
            "evidence": evidence,
            "clientGroups": [g["name"] for g in client.get("groups", [])],
            "protection": {
                "protected": prof["protected"],
                "protectionUnknown": prof.get("protectionUnknown", False),
                "protectionEvidence": prof.get("protectionEvidence"),
                "applications": prof["agents"],
                "subclients": [{k: sc.get(k) for k in ("name", "appName", "instanceName", "planName",
                                                       "storagePolicy", "databases", "lastGoodBackup")}
                               for sc in prof["subclients"]],
                "plans": prof["plans"],
                "latestRecoveryPoint": prof["latestRecoveryPoint"],
                "hoursSinceLastGoodBackup": prof["hoursSinceLastGoodBackup"],
            },
        }

    def _component_edges(self, client, prof, edges):
        name = client["name"]
        for agent in prof["agents"]:
            if agent.lower() in INFRA_AGENTS:
                continue
            edges.append({"from": name, "to": agent, "type": "application_on_client", "confidence": HIGH,
                          "evidence": [f"Commvault agent '{agent}' is installed/discovered on {name}"]})
        for sc in prof["subclients"]:
            if sc.get("instanceName") and sc.get("appName", "").lower() not in INFRA_AGENTS:
                edges.append({"from": name, "to": f"{sc['appName']} instance {sc['instanceName']}",
                              "type": "instance_on_client", "confidence": CONFIRMED,
                              "evidence": [f"Subclient '{sc['name']}' protects instance {sc['instanceName']}"]})
            for db in sc.get("databases") or []:
                edges.append({"from": f"{sc.get('appName')} instance {sc.get('instanceName')}", "to": db,
                              "type": "database_in_instance", "confidence": CONFIRMED,
                              "evidence": [f"Database listed in content of subclient '{sc['name']}'"]})
            if sc.get("planName"):
                edges.append({"from": f"{name}/{sc['name']}", "to": f"plan {sc['planName']}",
                              "type": "protected_by_plan", "confidence": CONFIRMED,
                              "evidence": [f"Plan associated to subclient '{sc['name']}'"]})
        for p in prof["plans"]:
            for c in p.get("copies", []):
                edges.append({"from": f"plan {p.get('name')}", "to": f"copy {c['name']}",
                              "type": "plan_copy", "confidence": CONFIRMED,
                              "evidence": [f"Copy on storage pool '{c.get('storagePool')}'"
                                           + (f" in region '{c['region']}'" if c.get("region") else "")]})

    def _gaps(self, resources):
        gaps = []

        for r in resources:
            n, p = r["name"], r["protection"]
            is_cand = r["role"] == "candidate"

            def add(sev, res, finding, impact, _c=is_cand):
                gaps.append({"severity": sev, "resource": res, "resourceIsCandidate": _c, "finding": finding,
                             "impact": ("If confirmed as part of the application: " + impact) if _c else impact})

            if p.get("protectionUnknown"):
                add("medium", n, "Protection could not be determined from the API",
                    "Verify in Command Center whether this resource is backed up.")
                continue
            if is_cand and not p["protected"]:
                add("high", n, "Possible application component has no Commvault protection",
                    "it cannot be recovered at all.")
                continue
            if not p["protected"]:
                add("critical", n, "No protected subclient with a plan or storage policy",
                    "This resource cannot be recovered from Commvault.")
                continue
            app_subclients = {str(sc.get("appName") or "").lower() for sc in p["subclients"]}
            for agent in p["applications"]:
                if agent.lower() not in INFRA_AGENTS and agent.lower() not in app_subclients:
                    add("high", n, f"'{agent}' is discovered on the client but has no application-level subclient",
                        "Only crash-consistent recovery may be possible for this application.")
            for sc in p["subclients"]:
                if not sc.get("planName") and not sc.get("storagePolicy"):
                    add("high", n, f"Subclient '{sc['name']}' has no plan or storage policy",
                        "Content of this subclient is not being protected.")
            h = p["hoursSinceLastGoodBackup"]
            if h is None:
                add("critical", n, "No successful backup found in the lookback window",
                    "There may be no usable recovery point.")
            elif h > self.rpo_hours:
                add("high", n, f"Last successful backup was {h}h ago (RPO target {self.rpo_hours}h)",
                    "Recovery would lose more data than the stated objective.")
            all_copies = [c for pl in p["plans"] for c in pl.get("copies", [])]
            copies = [c for c in all_copies if not c.get("isSnapshot")]  # snapshots are not independent copies
            if p["plans"] and len(copies) <= 1:
                add("high", n, "Plan has a single copy - no secondary copy",
                    "A ransomware event or storage loss on the primary copy leaves nothing to recover from.")
            elif copies:
                regions = {c.get("region") or "on-premises" for c in copies}
                if len(regions) == 1:
                    add("medium", n, "All copies are in the same region",
                        "A regional outage affects every recovery point.")
                imm = [c.get("immutable") for c in copies]
                if all(v is False for v in imm):
                    add("high", n, "No immutable copy", "Backups can be altered or deleted by an attacker with admin access.")
                elif all(v is None for v in imm):
                    add("medium", n, "Immutability could not be verified from the API",
                        "Confirm WORM/immutable settings on the storage pools.")
                air = [c.get("airGapped") for c in copies]
                if not any(air):
                    add("medium", n, "No air-gapped copy detected" + (" (unverified)" if all(a is None for a in air) else ""),
                        "Recovery depends on storage reachable from the production network.")
        order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        return sorted(gaps, key=lambda g: order[g["severity"]])

    def _summary(self, app, seed, prof, cands, gaps):
        apps = [a for a in prof["agents"] if a.lower() not in INFRA_AGENTS]
        dbs = sorted({d for sc in prof["subclients"] for d in (sc.get("databases") or [])
                      if d.lower() not in SYSTEM_DATABASES})
        plans = sorted({p.get("name") for p in prof["plans"] if p.get("name")})
        parts = [f"{app}: seed {seed['name']} ({seed['type']}) resolved in Commvault."]
        if apps:
            parts.append("Applications on it: " + ", ".join(apps) + (f" (databases: {', '.join(dbs)})" if dbs else "") + ".")
        parts.append(f"Protected by: {', '.join(plans)}." if plans else "Not protected by any plan.")
        if prof["latestRecoveryPoint"]:
            parts.append(f"Latest good recovery point: {prof['latestRecoveryPoint']}.")
        if cands:
            parts.append(f"{len(cands)} other resource(s) look related and need owner confirmation: "
                         + ", ".join(c["name"] for c in cands) + ".")
        crit = sum(1 for g in gaps if g["severity"] in ("critical", "high"))
        if crit:
            parts.append(f"{crit} critical/high recoverability gap(s) found.")
        parts.append("Dependencies outside Commvault (AD, DNS, network, external services) are not visible and must be confirmed by the owner.")
        return " ".join(parts)
