# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
A small simulated CommCell that answers the same GET endpoints CommvaultReader uses,
with response shapes modelled on the Commvault REST API. Used by tests and by the
offline demo server (demo/sim_server.py). Not imported by production code paths.

Scenario "TradingDemo":
  TRADING-WEB-01   VM, seed, file system subclient, Tier-0 plan
  TRADING-SQL-01   VM, SQL Server instance with TradingDB + TradingAudit, Tier-0 plan
  TRADING-API-01   VM, Bronze plan (single copy -> gap)
  trading-reporting-01  name match only, NOT protected
  All three TRADING-* are in client group "TradingDemo-Prod"; everything is also in a
  40-member "All Production VMs" group that must be ignored as too broad.

apply_drift() simulates six months of production change (new API node, new Kafka broker,
database dropped from backup, stale SQL backups).
Recovery group "TradingDemo-Cleanroom" exists with the web tier recovering first (wrong).
"""

from __future__ import annotations

import copy
import time
from typing import Any, Dict, Optional

H = 3600


class SimulatedCommCell:
    def __init__(self, now: Optional[int] = None):
        self.now = now or int(time.time())
        self.drifted = False
        self.clients: Dict[str, Dict[str, Any]] = {}
        self.groups = {
            "11": {"name": "TradingDemo-Prod", "members": ["101", "102", "103"]},
            "12": {"name": "All Production VMs", "members": ["101", "102", "103"] + [str(900 + i) for i in range(37)]},
        }
        tier0 = {"name": "Tier-0-Prod", "backupDestinations": [
            {"planBackupDestination": {"name": "Primary"}, "isMirrorCopy": False, "retentionPeriodDays": 30,
             "storagePool": {"name": "DDB-East-Pool", "isImmutable": True}, "region": {"name": "us-east-1", "displayName": "US East"},
             "storageType": "DISK"},
            {"planBackupDestination": {"name": "Cyber-Vault"}, "isMirrorCopy": True, "retentionPeriodDays": 90,
             "storagePool": {"name": "AirGapProtect-West", "isImmutable": True}, "region": {"name": "us-west-2", "displayName": "US West"},
             "storageType": "AIR_GAP_PROTECT"},
        ]}
        bronze = {"name": "Bronze-Standard", "backupDestinations": [
            {"planBackupDestination": {"name": "Primary"}, "isMirrorCopy": False, "retentionPeriodDays": 14,
             "storagePool": {"name": "DDB-East-Pool", "isImmutable": False}, "region": {"name": "us-east-1", "displayName": "US East"},
             "storageType": "DISK"},
        ]}
        self.plans = {"1": tier0, "2": bronze}
        self._client("101", "TRADING-WEB-01", True, ["11", "12"], ["Virtual Server", "File System"],
                     [("201", "default", "File System", "DefaultInstanceName", "1", [])], [-6])
        self._client("102", "TRADING-SQL-01", True, ["11", "12"], ["Virtual Server", "SQL Server"],
                     [("202", "TradingSQL", "SQL Server", "TRADING-SQL-01\\MSSQLSERVER", "1", ["TradingDB", "TradingAudit"])], [-4, -28])
        self._client("103", "TRADING-API-01", True, ["11", "12"], ["Virtual Server", "File System"],
                     [("203", "default", "File System", "DefaultInstanceName", "2", [])], [-10])
        self._client("104", "trading-reporting-01", False, [], ["File System"], [], [])
        for i in range(37):
            self._client(str(900 + i), f"CORP-VM-{i:02d}", True, ["12"], ["Virtual Server"], [], [])
        # Existing Cleanroom recovery group, built by hand years ago - in the wrong order.
        self.recovery_groups = {"7": {"name": "TradingDemo-Cleanroom", "entities": [
            ("TRADING-WEB-01", 1), ("TRADING-API-01", 2), ("TRADING-SQL-01", 2)]}}

    # -------------------------------------------------------------- builders
    def _client(self, cid, name, is_vm, groups, agents, subclients, backups_hours_ago):
        self.clients[cid] = {
            "id": cid, "name": name, "vm": is_vm, "groups": groups, "agents": agents,
            "subclients": [{"id": s[0], "name": s[1], "app": s[2], "instance": s[3], "plan": s[4], "dbs": list(s[5])}
                           for s in subclients],
            "backups": [self.now + h * H for h in backups_hours_ago],
        }

    def apply_drift(self):
        """Six months later: new API node deployed, a database dropped from protection, SQL backups stale."""
        if self.drifted:
            return
        self.drifted = True
        self._client("105", "TRADING-API-02", True, ["11", "12"], ["Virtual Server", "File System"],
                     [("205", "default", "File System", "DefaultInstanceName", "2", [])], [-3])
        self._client("106", "TRADING-KAFKA-01", True, ["11"], ["Virtual Server", "File System"],
                     [("206", "default", "File System", "DefaultInstanceName", "1", [])], [-2])
        self.groups["11"]["members"] += ["105", "106"]
        self.groups["12"]["members"].append("105")
        sql = self.clients["102"]
        sql["subclients"][0]["dbs"] = ["TradingDB"]
        sql["backups"] = [self.now - 41 * H]

    # ---------------------------------------------------------------- router
    def get(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        params = params or {}
        ep = endpoint.strip("/")
        if ep == "getid":
            n = str(params.get("clientname", "")).lower()
            for c in self.clients.values():
                if c["name"].lower() == n:
                    return {"clientId": int(c["id"])}
            return {"clientId": -1}
        if ep == "Client":
            return {"clientProperties": [{"client": {"clientEntity": self._entity(c)}} for c in self.clients.values()]}
        if ep.startswith("Client/"):
            c = self.clients.get(ep.split("/")[1])
            if not c:
                return {"clientProperties": []}
            props = {"client": {"clientEntity": self._entity(c)},
                     "clientGroups": [{"clientGroupId": int(g), "clientGroupName": self.groups[g]["name"]} for g in c["groups"]],
                     "clientProps": {"IsVirtualClient": c["vm"]}}
            return {"clientProperties": [props]}
        if ep == "Agent":
            c = self.clients.get(str(params.get("clientId")))
            return {"agentProperties": [{"idaEntity": {"appName": a}} for a in (c["agents"] if c else [])]}
        if ep == "subclient":
            c = self.clients.get(str(params.get("clientId")))
            scs = c["subclients"] if c else []
            return {"filterQueryCount": len(scs), "subClientProperties": [{"subClientEntity": {
                "clientName": c["name"], "subclientId": int(s["id"]), "subclientName": s["name"], "appName": s["app"],
                "instanceName": s["instance"], "backupsetName": "defaultBackupSet"}} for s in scs]}
        if ep.startswith("subclient/"):
            sid = ep.split("/")[1]
            for c in self.clients.values():
                for s in c["subclients"]:
                    if s["id"] == sid:
                        plan = self.plans[s["plan"]]
                        return {"subClientProperties": [{
                            "planEntity": {"planId": int(s["plan"]), "planName": plan["name"]},
                            "content": [{"mssqlDbContent": {"databaseName": d}} for d in s["dbs"]]}]}
            return {"subClientProperties": []}
        if ep.startswith("v4/serverplan/"):
            p = self.plans[ep.split("/")[2]]
            return copy.deepcopy(p)
        if ep == "Job":
            c = self.clients.get(str(params.get("clientId")))
            jobs = []
            if c and c["subclients"]:
                for i, t in enumerate(c["backups"]):
                    sc = c["subclients"][0]
                    jobs.append({"jobSummary": {"jobId": int(c["id"]) * 100 + i, "status": "Completed",
                                                "jobEndTime": t, "backupLevelName": "Incremental",
                                                "subclient": {"subclientId": int(sc["id"]), "subclientName": sc["name"]}}})
            return {"totalRecordsWithoutPaging": len(jobs), "jobs": jobs}
        if ep.startswith("ClientGroup/"):
            g = self.groups.get(ep.split("/")[1])
            members = [{"clientId": int(m), "clientName": self.clients[m]["name"]} for m in (g["members"] if g else [])]
            return {"clientGroupDetail": {"associatedClients": members}}
        if ep == "V4/RecoveryGroups":
            return {"recoveryGroups": [{"id": int(k), "name": g["name"]} for k, g in self.recovery_groups.items()]}
        if ep.startswith("V4/RecoveryGroups/"):
            g = self.recovery_groups[ep.split("/")[2]]
            return {"recoveryGroup": {"id": int(ep.split("/")[2]), "name": g["name"], "delayBetweenPriorityMachines": 10},
                    "entities": [{"name": n, "recoveryConfiguration": {"executionOrder": {"priority": pr, "order": i}}}
                                 for i, (n, pr) in enumerate(g["entities"])]}
        raise ValueError(f"Simulator: unsupported endpoint {endpoint}")

    @staticmethod
    def _entity(c):
        return {"clientId": int(c["id"]), "clientName": c["name"], "displayName": c["name"],
                "hostName": c["name"].lower() + ".corp.local"}
