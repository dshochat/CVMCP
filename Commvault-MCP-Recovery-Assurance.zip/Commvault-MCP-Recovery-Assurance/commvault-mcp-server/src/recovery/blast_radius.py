# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Blast radius: from a security graph (identities, roles, servers, apps and the relations between them)
and a set of compromised nodes, determine which resources an attacker could control, map them to
Commvault clients, and pick a clean recovery point from before the compromise.

Input graph (tool-neutral JSON; adapters for BloodHound / cloud IAM analyzers can produce it):
{
  "compromised": ["user:svc-backup"],                 # node ids
  "t0": "2026-10-18T02:10:00Z",                         # earliest known compromise time (ISO 8601)
  "dwellTimeHours": 72,                                 # optional; scenario default if omitted
  "nodes": [{"id": "vm:PAY-SQL-01", "type": "server", "commvaultClient": "PAY-SQL-01", "name": "..."}],
  "edges": [{"from": "user:svc-backup", "to": "vm:PAY-SQL-01", "rel": "admin_of"},
            {"from": "app:PAY-API", "to": "vm:PAY-SQL-01", "rel": "depends_on"}]
}

Rules:
  * Control propagates FROM -> TO along control relations only (CONTROL_RELS). Other relations
    (e.g. depends_on) are not attack paths; depends_on is used later as a recovery-ordering hint.
  * "Can reach" over-approximates "was touched". That is the safe direction for recovery, and the
    output says so. Every affected node carries the shortest attack path as evidence.
  * Deterministic; no inference. Unknown relation types are ignored and reported.
"""

from __future__ import annotations

from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from src.recovery.discovery import RecoveryDiscovery

CONTROL_RELS = {
    "admin_of", "owns", "manages", "can_write", "can_modify", "can_assume", "member_of", "authenticates",
    "has_credentials_for", "can_execute_on", "can_login_to", "can_reset_password", "delegated_to",
    "runs_as", "hosts", "deploys_to", "has_access_key_for", "can_impersonate", "trusts", "generic_all",
}
INFO_RELS = {"depends_on", "connects_to", "reads_from", "replicates_to", "located_in"}
SERVER_TYPES = {"server", "vm", "host", "database", "db_server", "domain_controller", "workload", "instance",
                "cloud_vm", "file_server", "app_server", "web_server", "storage", "kubernetes_cluster"}
IDENTITY_TYPES = {"user", "group", "service_account", "role", "iam_role", "iam_user", "policy", "service_principal",
                  "managed_identity", "access_key", "app_registration", "gpo", "domain", "tenant", "ou", "credential"}
MAX_NODES, MAX_EDGES, DEFAULT_MAX_DEPTH = 5000, 20000, 6


def parse_time(value: Any) -> Optional[int]:
    if value in (None, ""):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    s = str(value).strip().replace("Z", "+00:00")
    dt = datetime.fromisoformat(s)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int(dt.timestamp())


def iso(epoch: Optional[int]) -> Optional[str]:
    if epoch is None:
        return None
    return datetime.fromtimestamp(int(epoch), tz=timezone.utc).isoformat().replace("+00:00", "Z")


def validate_graph(graph: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], List[Dict[str, Any]], List[str], List[str]]:
    """Return (nodes_by_id, edges, compromised_ids, warnings). Raises ValueError on invalid input."""
    if not isinstance(graph, dict):
        raise ValueError("graph must be a JSON object")
    nodes_in, edges_in = graph.get("nodes") or [], graph.get("edges") or []
    if not isinstance(nodes_in, list) or not isinstance(edges_in, list):
        raise ValueError("graph.nodes and graph.edges must be arrays")
    if len(nodes_in) > MAX_NODES or len(edges_in) > MAX_EDGES:
        raise ValueError(f"graph too large (max {MAX_NODES} nodes / {MAX_EDGES} edges)")
    warnings: List[str] = []
    nodes: Dict[str, Dict[str, Any]] = {}
    for n in nodes_in:
        if not isinstance(n, dict) or not n.get("id"):
            raise ValueError("every node needs an 'id'")
        nid = str(n["id"])
        nodes[nid] = {"id": nid, "type": str(n.get("type", "unknown")).lower(),
                      "name": n.get("name") or nid.split(":", 1)[-1],
                      "commvaultClient": n.get("commvaultClient")}
    edges, unknown_rels = [], set()
    for e in edges_in:
        if not isinstance(e, dict) or not e.get("from") or not e.get("to") or not e.get("rel"):
            raise ValueError("every edge needs 'from', 'to' and 'rel'")
        a, b, rel = str(e["from"]), str(e["to"]), str(e["rel"]).lower()
        for x in (a, b):
            if x not in nodes:  # tolerate edges to undeclared nodes; declare them as unknown
                nodes[x] = {"id": x, "type": "unknown", "name": x.split(":", 1)[-1], "commvaultClient": None}
        if rel not in CONTROL_RELS and rel not in INFO_RELS:
            unknown_rels.add(rel)
        edges.append({"from": a, "to": b, "rel": rel})
    if unknown_rels:
        warnings.append("Unknown relation types ignored for blast radius: " + ", ".join(sorted(unknown_rels)))
    comp = [str(c) for c in graph.get("compromised") or []]
    if not comp:
        raise ValueError("graph.compromised must list at least one node id")
    missing = [c for c in comp if c not in nodes]
    if missing:
        raise ValueError(f"compromised node(s) not in graph: {', '.join(missing)}")
    return nodes, edges, comp, warnings


def traverse(nodes, edges, compromised, max_depth=DEFAULT_MAX_DEPTH) -> Dict[str, List[Dict[str, str]]]:
    """BFS along control edges. Returns {node_id: shortest path as list of hops} (compromised -> [])."""
    out_edges: Dict[str, List[Dict[str, str]]] = {}
    for e in edges:
        if e["rel"] in CONTROL_RELS:
            out_edges.setdefault(e["from"], []).append(e)
    paths: Dict[str, List[Dict[str, str]]] = {c: [] for c in compromised}
    q = deque((c, 0) for c in compromised)
    while q:
        nid, depth = q.popleft()
        if depth >= max_depth:
            continue
        for e in out_edges.get(nid, []):
            if e["to"] not in paths:
                paths[e["to"]] = paths[nid] + [e]
                q.append((e["to"], depth + 1))
    return paths


def _client_name(node: Dict[str, Any]) -> Optional[str]:
    if node.get("commvaultClient"):
        return str(node["commvaultClient"])
    if node["type"] in SERVER_TYPES:
        return node["name"]
    return None


def clean_point(reader, client_id: str, cutoff: int, now: int) -> Dict[str, Any]:
    """Latest successful backup that completed before the cutoff, plus whether newer (suspect) ones exist."""
    lookback_h = max(int((now - cutoff) / 3600) + 7 * 24, 7 * 24)
    jobs = reader.get_recent_backups(client_id, lookback_hours=lookback_h)
    good = [j for j in jobs if j["success"] and j["endTime"]]
    before = [j for j in good if int(j["endTime"]) < cutoff]
    after = [j for j in good if int(j["endTime"]) >= cutoff]
    best = max(before, key=lambda j: int(j["endTime"]), default=None)
    return {
        "cutoff": iso(cutoff),
        "cleanCandidate": ({"jobId": best["jobId"], "completed": iso(best["endTime"]), "level": best.get("level"),
                            "subclient": best.get("subclientName")} if best else None),
        "suspectPointsAfterCutoff": len(after),
        "verification": "Threat Scan of this recovery point is recommended before use (not yet automated).",
    }


def assess(discovery: RecoveryDiscovery, graph: Dict[str, Any], dwell_hours: Optional[float] = None,
           max_depth: int = DEFAULT_MAX_DEPTH, now: Optional[int] = None) -> Dict[str, Any]:
    nodes, edges, comp, warnings = validate_graph(graph)
    t0 = parse_time(graph.get("t0"))
    if dwell_hours is None:
        dwell_hours = float(graph.get("dwellTimeHours") or 0)
    now = now or int(datetime.now(timezone.utc).timestamp())
    cutoff = (t0 - int(dwell_hours * 3600)) if t0 else None
    if t0 is None:
        warnings.append("No t0 (compromise time) given: clean recovery points cannot be selected.")
    paths = traverse(nodes, edges, comp, max_depth)

    def path_text(p):
        return " -> ".join([p[0]["from"]] + [f"[{h['rel']}] {h['to']}" for h in p]) if p else "directly compromised"

    affected, identity_objects, commvault_resources, gaps = [], [], [], []
    for nid, p in sorted(paths.items(), key=lambda kv: (len(kv[1]), kv[0])):
        node = nodes[nid]
        entry = {"id": nid, "type": node["type"], "name": node["name"], "hops": len(p), "attackPath": path_text(p)}
        affected.append(entry)
        cname = _client_name(node)
        if cname is None:
            if node["type"] in IDENTITY_TYPES or node["type"] == "unknown":
                identity_objects.append(entry)
            continue
        client = discovery.r.resolve_client(cname)
        if not client:
            gaps.append({"severity": "high", "resource": node["name"],
                         "finding": f"Affected {node['type']} '{cname}' is not a Commvault client",
                         "impact": "It cannot be recovered from Commvault; rebuild or recover by other means.",
                         "attackPath": entry["attackPath"]})
            continue
        try:
            prof = discovery.profile(client)
        except Exception as e:  # one unreadable client must not stop the assessment
            gaps.append({"severity": "high", "resource": client["name"],
                         "finding": f"Protection details could not be read from Commvault ({str(e)[:120]})",
                         "impact": "Recoverability of this affected resource is unknown.", "attackPath": entry["attackPath"]})
            continue
        res = discovery._resource(client, "affected", "confirmed", [f"Attack path: {entry['attackPath']}"], prof)
        res["graphNode"] = nid
        res["hops"] = len(p)
        if prof.get("protectionUnknown"):
            gaps.append({"severity": "medium", "resource": client["name"],
                         "finding": "Protection could not be determined from the API",
                         "impact": "Verify in Command Center before relying on it in this runbook.",
                         "attackPath": entry["attackPath"]})
        elif not prof["protected"]:
            gaps.append({"severity": "critical", "resource": client["name"],
                         "finding": "Affected resource is not protected by Commvault",
                         "impact": "No recovery point exists to restore it.", "attackPath": entry["attackPath"]})
        if cutoff is not None and prof["protected"]:
            cp = clean_point(discovery.r, client["id"], cutoff, now)
            res["recoveryPoint"] = cp
            if cp["cleanCandidate"] is None:
                gaps.append({"severity": "critical", "resource": client["name"],
                             "finding": f"No successful backup before the clean cutoff {cp['cutoff']}",
                             "impact": "Every available recovery point may contain the attacker's changes.",
                             "attackPath": entry["attackPath"]})
            retention = min((c.get("retentionDays") or 10**6 for pl in prof["plans"] for c in pl.get("copies", [])),
                            default=None)
            if retention and retention < 10**6 and (now - cutoff) / 86400 > retention:
                gaps.append({"severity": "high", "resource": client["name"],
                             "finding": f"Clean cutoff is older than the shortest copy retention ({retention} days)",
                             "impact": "Pre-compromise recovery points may have aged out on some copies.",
                             "attackPath": entry["attackPath"]})
        commvault_resources.append(res)

    depends = [(e["from"], e["to"]) for e in edges if e["rel"] == "depends_on"]
    return {
        "status": "ASSESSED",
        "readOnly": True,
        "compromised": comp,
        "t0": iso(t0),
        "dwellTimeHours": dwell_hours,
        "cleanCutoff": iso(cutoff),
        "summary": (f"{len(comp)} compromised node(s) can reach {len(affected) - len(comp)} other node(s) within "
                    f"{max_depth} hops: {len(commvault_resources)} Commvault-protected resource(s) in recovery scope, "
                    f"{len(identity_objects)} identity/control object(s) needing credential action, {len(gaps)} gap(s)."),
        "affectedNodes": affected,
        "identityObjects": identity_objects,
        "recoveryScope": commvault_resources,
        "gaps": sorted(gaps, key=lambda g: {"critical": 0, "high": 1, "medium": 2}[g["severity"]]),
        "dependencyHints": [{"dependent": nodes[a]["name"], "dependsOn": nodes[b]["name"]} for a, b in depends],
        "warnings": warnings,
        "note": ("Blast radius is what the compromised identities COULD control (over-approximation), which is the "
                 "safe basis for recovery scoping. Accuracy depends on the completeness of the supplied graph."),
    }
