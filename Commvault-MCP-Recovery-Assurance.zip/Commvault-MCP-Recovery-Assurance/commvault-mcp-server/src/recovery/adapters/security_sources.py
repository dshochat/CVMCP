# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Deterministic adapters: security-tool exports -> the Recovery Assurance graph format.

  Cortex (XDR / XSIAM incident)          -> compromised identities + hosts, t0, suggested scenario
  Microsoft Defender XDR incident        -> same, from alerts' devices/entities (or Graph alerts_v2 evidence)
  Wiz (security graph result)            -> nodes + edges (what those identities can reach)
  Microsoft Security Exposure Management -> nodes + edges from ExposureGraphEdges (advanced hunting)

No AI interpretation: an LLM may pass these exports through, but conversion happens here, with
mapping tables in mappings.json. FIELD SHAPES ARE UNVALIDATED until checked against real exports;
every unmatched entity, relationship or category is reported rather than guessed.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

MAPPINGS = json.loads((Path(__file__).resolve().parent / "mappings.json").read_text(encoding="utf-8"))


def _norm(name: str) -> str:
    """Normalise identity/host names for matching: strip DOMAIN\\, @domain, FQDN suffix; lowercase."""
    n = str(name or "").strip()
    n = n.split("\\")[-1].split("@")[0]
    return n.lower()


def _iso_ms(v: Any) -> Optional[str]:
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        secs = v / 1000 if v > 10**11 else v
        return datetime.fromtimestamp(secs, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    return str(v)


# ------------------------------------------------------------------ Cortex
def from_cortex_incident(incident: Dict[str, Any]) -> Dict[str, Any]:
    """Accepts a Cortex XDR/XSIAM incident (get_incident_extra_data-style or flattened).
    Expected (UNVALIDATED) fields: incident_id, creation_time (ms), detection_time, description,
    alert_categories[], users[], hosts[], alerts[{detection_timestamp, category, host_name, user_name}]."""
    inc = incident.get("reply", incident)
    inc = inc.get("incident", inc)
    alerts = (incident.get("reply", {}).get("alerts", {}) or {}).get("data", []) or inc.get("alerts", []) or []
    users = list(inc.get("users") or []) + [a.get("user_name") for a in alerts if a.get("user_name")]
    hosts = list(inc.get("hosts") or []) + [a.get("host_name") for a in alerts if a.get("host_name")]
    hosts = [h.split(":")[0] for h in hosts]  # Cortex host entries may be "name:agent_id"
    times = [a.get("detection_timestamp") for a in alerts if a.get("detection_timestamp")]
    t0 = min(times) if times else (inc.get("detection_time") or inc.get("creation_time"))
    cats = [str(c) for c in (inc.get("alert_categories") or [])] + [str(a.get("category")) for a in alerts if a.get("category")]
    text = " ".join(cats + [str(inc.get("description", "")), str(inc.get("incident_name", ""))]).lower()
    matches = []
    for rule in MAPPINGS["cortex"]["categoryToScenario"]:
        hit = next((m for m in rule["match"] if m in text), None)
        if hit and rule["scenario"] not in [m[0] for m in matches]:
            matches.append((rule["scenario"], hit))
    scenario = matches[0][0] if matches else MAPPINGS["cortex"]["defaultScenario"]
    matched = ", ".join(f"'{h}' -> {sid}" for sid, h in matches) if matches else None
    return {
        "incidentId": inc.get("incident_id"),
        "t0": _iso_ms(t0),
        "compromisedUsers": sorted({_norm(u) for u in users if u}),
        "compromisedHosts": sorted({_norm(h) for h in hosts if h}),
        "suggestedScenario": scenario,
        "matchedScenarios": [m[0] for m in matches] or [scenario],
        "scenarioReason": f"incident categories/description matched {matched}" if matched else "no category matched; default playbook",
        "categories": sorted(set(cats)),
    }


# --------------------------------------------------------------------- Wiz
def _wiz_entity(e: Dict[str, Any]) -> Tuple[str, Dict[str, Any], Optional[str]]:
    wtype = str(e.get("type", "")).upper()
    t = MAPPINGS["wiz"]["entityTypes"].get(wtype)
    name = e.get("name") or (e.get("properties") or {}).get("name") or e.get("id")
    nid = f"wiz:{e.get('id') or name}"
    node = {"id": nid, "type": t or "unknown", "name": name, "wizType": wtype}
    if t in ("cloud_vm", "db_server", "workload", "database", "storage", "kubernetes_cluster"):
        node["commvaultClient"] = name  # resolved against Commvault by name/hostname later
    return nid, node, (None if t else wtype)


def from_wiz_graph(result: Dict[str, Any]) -> Dict[str, Any]:
    """Accepts either
       a) explicit graph: {"nodes":[{id,type,name}], "edges":[{source|from, target|to, type|rel}]}
       b) Wiz graphSearch-style rows: {"data":{"graphSearch":{"nodes":[{"entities":[e1,e2,...]}]}}} where each row is an
          ordered path; consecutive entities are linked with defaultPathRelationship (control).  (UNVALIDATED)"""
    nodes, edges, unknown_types, unknown_rels = {}, [], set(), set()
    if "nodes" in result and "edges" in result:
        for e in result["nodes"]:
            nid, node, unk = _wiz_entity(e)
            nodes[e.get("id")] = node
            unknown_types.update([unk] if unk else [])
        for r in result["edges"]:
            a, b = r.get("source", r.get("from")), r.get("target", r.get("to"))
            wrel = str(r.get("type", r.get("rel", ""))).upper()
            rel = MAPPINGS["wiz"]["relationships"].get(wrel)
            if not rel:
                unknown_rels.add(wrel)
                continue
            if a in nodes and b in nodes:
                edges.append({"from": nodes[a]["id"], "to": nodes[b]["id"], "rel": rel, "wizRel": wrel})
    else:
        rows = (((result.get("data") or {}).get("graphSearch") or {}).get("nodes")) or result.get("rows") or []
        default_rel = MAPPINGS["wiz"]["defaultPathRelationship"]
        for row in rows:
            chain = []
            for e in row.get("entities", []) or []:
                nid, node, unk = _wiz_entity(e)
                nodes.setdefault(e.get("id") or nid, node)
                unknown_types.update([unk] if unk else [])
                chain.append(node["id"])
            for a, b in zip(chain, chain[1:]):
                edges.append({"from": a, "to": b, "rel": default_rel, "wizRel": "PATH"})
    uniq = {(e["from"], e["to"], e["rel"]): e for e in edges}
    return {"nodes": list(nodes.values()), "edges": list(uniq.values()),
            "unmappedEntityTypes": sorted(unknown_types), "unmappedRelationships": sorted(unknown_rels)}


# ---------------------------------------------------------- Microsoft Defender XDR
def _words(s: Any) -> str:
    """'CredentialAccess' -> 'credential access credentialaccess' (match either spelling)."""
    s = str(s or "")
    return f"{re.sub(r'(?<=[a-z])(?=[A-Z])', ' ', s)} {s}".lower()


def _host(name: Any) -> str:
    """Short host name: 'dc1.cv.lab' -> 'dc1'. Leaves cloud resource ids / names without dots alone."""
    n = _norm(name)
    return n if "/" in n else n.split(".")[0]


def from_defender_incident(incident: Dict[str, Any]) -> Dict[str, Any]:
    """Accepts a Microsoft Defender XDR incident as returned by
       a) the Defender XDR API  GET /api/incidents  (incidentId, incidentName, alerts[].devices[], alerts[].entities[]), or
       b) Microsoft Graph       GET /security/incidents/{id}?$expand=alerts  (id, displayName, alerts[].evidence[]),
       or a {"value":[...]} list (first incident). Field shapes from Microsoft's docs; UNVALIDATED on a live tenant."""
    inc = incident
    if isinstance(inc.get("value"), list) and inc["value"]:
        inc = inc["value"][0]
    cfg = MAPPINGS["defender"]
    system = set(cfg["systemAccounts"])
    users, hosts, times, cats, techniques, roles = [], [], [], [], [], {}
    for a in inc.get("alerts", []) or []:
        times += [t for t in (a.get("firstActivity"), a.get("firstActivityDateTime")) if t]
        cats += [a.get("category")] if a.get("category") else []
        techniques += [str(t) for t in a.get("mitreTechniques") or []]
        for d in a.get("devices", []) or []:                                   # Defender XDR API
            if d.get("deviceDnsName"):
                hosts.append(_host(d["deviceDnsName"]))
        for e in a.get("entities", []) or []:
            if str(e.get("entityType", "")).lower() == "user":
                u = e.get("userPrincipalName") or e.get("accountName")
                if u and _norm(u) not in system and str(e.get("domainName", "")).lower() != "nt authority":
                    users.append(_norm(u))
        for ev in a.get("evidence", []) or []:                                 # Graph alerts_v2 evidence
            t = str(ev.get("@odata.type", "")).rsplit(".", 1)[-1]
            r = [str(x) for x in ev.get("roles") or []]
            if t == "deviceEvidence":
                h = ev.get("hostName") or ev.get("deviceDnsName")
                if h:
                    hosts.append(_host(h)); roles.setdefault(_host(h), set()).update(r)
            elif t == "userEvidence":
                ua = ev.get("userAccount") or {}
                u = ua.get("userPrincipalName") or ua.get("accountName")
                if u and _norm(u) not in system and str(ua.get("domainName", "")).lower() != "nt authority":
                    users.append(_norm(u)); roles.setdefault(_norm(u), set()).update(r)
    t0 = min(times) if times else (inc.get("createdTime") or inc.get("createdDateTime"))
    name = inc.get("incidentName") or inc.get("displayName") or ""
    text = " ".join([_words(c) for c in cats] + [t.lower() for t in techniques]
                    + [str(name).lower()] + [str(a.get("title", "")).lower() for a in inc.get("alerts", []) or []])
    matches = []
    for rule in cfg["categoryToScenario"]:
        hit = next((m for m in rule["match"] if m in text), None)
        if hit and rule["scenario"] not in [m[0] for m in matches]:
            matches.append((rule["scenario"], hit))
    scenario = matches[0][0] if matches else cfg["defaultScenario"]
    matched = ", ".join(f"'{h}' -> {sid}" for sid, h in matches) if matches else None
    return {
        "source": "Microsoft Defender XDR",
        "incidentId": inc.get("incidentId") or inc.get("id"),
        "incidentName": name,
        "t0": _iso_ms(t0),
        "compromisedUsers": sorted(set(users)),
        "compromisedHosts": sorted(set(hosts)),
        "evidenceRoles": {k: sorted(v) for k, v in roles.items() if v},
        "suggestedScenario": scenario,
        "matchedScenarios": [m[0] for m in matches] or [scenario],
        "scenarioReason": f"Defender categories/MITRE techniques/titles matched {matched}" if matched
                          else "no category or technique matched; default playbook",
        "categories": sorted({str(c) for c in cats}),
        "mitreTechniques": sorted(set(techniques)),
    }


# --------------------------------------------- Microsoft Security Exposure Management
def _rows(result: Any) -> List[Dict[str, Any]]:
    if isinstance(result, list):
        return result
    for k in ("Results", "results", "rows", "value"):
        if isinstance(result.get(k), list):
            return result[k]
    return []


def _label(s: Any) -> str:
    s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", str(s or ""))
    return re.sub(r"\s+", " ", s).strip().lower()


def _cats(v: Any) -> List[str]:
    if isinstance(v, str):
        try:
            v = json.loads(v)
        except ValueError:
            v = [v]
    return [str(x).lower() for x in (v or [])]


def from_exposure_graph(result: Any) -> Dict[str, Any]:
    """Accepts ExposureGraphEdges rows from Defender advanced hunting (portal export, the Defender
    /api/advancedhunting/run 'Results', or Graph security/runHuntingQuery 'results'):
      EdgeLabel, SourceNodeId, SourceNodeName, SourceNodeLabel, SourceNodeCategories,
      TargetNodeId, TargetNodeName, TargetNodeLabel, TargetNodeCategories
    lab/defender/blast_radius.kql produces exactly these rows for the incident's compromised entities. UNVALIDATED."""
    cfg = MAPPINGS["exposureGraph"]
    nodes, edges, unknown_types, unknown_rels = {}, [], set(), set()

    def node(nid, name, label, cats):
        if nid in nodes:
            return nodes[nid]["id"]
        lab = str(label or "").lower()
        t = cfg["nodeLabels"].get(lab) or next((cfg["categories"][c] for c in _cats(cats) if c in cfg["categories"]), None)
        if not t:
            unknown_types.add(lab or "?")
        n = {"id": f"msem:{nid}", "type": t or "unknown", "name": name or nid, "msemLabel": lab}
        if t in ("server", "cloud_vm", "db_server", "database", "workload", "storage"):
            n["commvaultClient"] = _host(name or nid)
        nodes[nid] = n
        return n["id"]

    for r in _rows(result):
        a = node(r.get("SourceNodeId"), r.get("SourceNodeName"), r.get("SourceNodeLabel"), r.get("SourceNodeCategories"))
        b = node(r.get("TargetNodeId"), r.get("TargetNodeName"), r.get("TargetNodeLabel"), r.get("TargetNodeCategories"))
        lab = _label(r.get("EdgeLabel"))
        rel = cfg["edgeLabels"].get(lab)
        if not rel:
            if lab not in cfg["ignoredEdgeLabels"]:
                unknown_rels.add(lab)
            continue
        edges.append({"from": a, "to": b, "rel": rel, "msemRel": lab})
    uniq = {(e["from"], e["to"], e["rel"]): e for e in edges}
    return {"nodes": list(nodes.values()), "edges": list(uniq.values()),
            "unmappedEntityTypes": sorted(unknown_types), "unmappedRelationships": sorted(unknown_rels)}


# ------------------------------------------------------------------- merge
def build_graph(cortex_incident: Optional[Dict[str, Any]] = None, wiz_graph: Optional[Dict[str, Any]] = None,
                dwell_time_hours: Optional[float] = None, defender_incident: Optional[Dict[str, Any]] = None,
                exposure_graph: Any = None) -> Dict[str, Any]:
    """Incident source (who/when/what): Cortex or Defender XDR. Reachability source (blast radius): Wiz and/or
    Microsoft Security Exposure Management. Any combination; graphs from several sources are merged."""
    incs = [x for x in ((from_defender_incident(defender_incident), "Defender") if defender_incident else None,
                        (from_cortex_incident(cortex_incident), "Cortex") if cortex_incident else None) if x]
    graphs = [(from_wiz_graph(wiz_graph), "Wiz")] if wiz_graph else []
    if exposure_graph:
        graphs.append((from_exposure_graph(exposure_graph), "Exposure Management"))
    nodes, edges, unk_t, unk_r = {}, [], {}, {}
    for g, src in graphs:
        nodes.update({n["id"]: n for n in g["nodes"]})
        edges += g["edges"]
        if g["unmappedEntityTypes"]:
            unk_t[src] = g["unmappedEntityTypes"]
        if g["unmappedRelationships"]:
            unk_r[src] = g["unmappedRelationships"]
    by_name = {}
    for n in nodes.values():
        for key in {_norm(n["name"]), _host(n["name"])}:
            by_name.setdefault(key, []).append(n["id"])
    compromised, unmatched = [], []
    graph_src = " / ".join(s for _, s in graphs) or "any reachability graph"
    for cx, isrc in incs:
        for kind, names in (("user", cx.get("compromisedUsers", [])), ("server", cx.get("compromisedHosts", []))):
            for nm in names:
                ids = by_name.get(nm) or by_name.get(nm.split(".")[0]) or by_name.get(nm.split("@")[0])
                if ids:
                    compromised += ids
                else:  # not in the reachability graph: add as a standalone compromised node so it is still scoped
                    nid = f"{isrc.lower()}:{kind}:{nm}"
                    nodes[nid] = {"id": nid, "type": kind, "name": nm, **({"commvaultClient": nm} if kind == "server" else {})}
                    compromised.append(nid)
                    unmatched.append(f"{kind} '{nm}' from {isrc} not found in {graph_src} (scoped on its own)")
    primary = incs[0][0] if incs else {}
    times = [c.get("t0") for c, _ in incs if c.get("t0")]
    scen = []
    for c, _ in incs:
        scen += [s for s in c.get("matchedScenarios") or [] if s not in scen]
    graph = {
        "compromised": sorted(set(compromised)),
        "t0": min(times) if times else None,
        "nodes": list(nodes.values()),
        "edges": list({(e["from"], e["to"], e["rel"]): e for e in edges}.values()),
    }
    if dwell_time_hours is not None:
        graph["dwellTimeHours"] = dwell_time_hours
    return {
        "status": "IMPORTED" if graph["compromised"] else "NO_COMPROMISED_ENTITIES",
        "graph": graph,
        "suggestedScenario": primary.get("suggestedScenario"),
        "matchedScenarios": scen,
        "scenarioReason": "; ".join(f"{s}: {c.get('scenarioReason')}" for c, s in incs) or None,
        "incidentId": primary.get("incidentId"),
        "incidentSource": " + ".join(s for _, s in incs) or None,
        "report": {
            "nodes": len(graph["nodes"]), "edges": len(graph["edges"]),
            "reachabilitySources": [s for _, s in graphs],
            "unmappedEntityTypes": unk_t, "unmappedRelationships": unk_r,
            "unmatchedIncidentEntities": unmatched,
            "mitreTechniques": sorted({t for c, _ in incs for t in c.get("mitreTechniques", [])}),
            "note": "Adapter field shapes follow vendor docs and are unvalidated until checked against real exports.",
        },
    }
