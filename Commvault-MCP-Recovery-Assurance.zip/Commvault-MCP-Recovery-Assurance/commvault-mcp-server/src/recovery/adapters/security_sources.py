# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Deterministic adapters: security-tool exports -> the Recovery Assurance graph format.

  Cortex (XDR / XSIAM incident)  -> compromised identities + hosts, t0, suggested scenario
  Wiz (security graph result)    -> nodes + edges (what those identities can reach)

No AI interpretation: an LLM may pass these exports through, but conversion happens here, with
mapping tables in mappings.json. FIELD SHAPES ARE UNVALIDATED until checked against real exports;
every unmatched entity, relationship or category is reported rather than guessed.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

MAPPINGS = json.loads((Path(__file__).resolve().parent / "mappings.json").read_text(encoding="utf-8"))


def _norm(name: str) -> str:
    """Normalise identity/host names for matching: strip DOMAIN\\, @domain, FQDN suffix; lowercase."""
    n = str(name or "").strip()
    n = n.split("\\")[-1].split("@")[0]
    return n.lower()


def _iso_ms(v: Any) -> Optional[str]:
    if v in (None, ""):
        return None
    if isinstance(v, (int, float)):
        secs = v / 1000 if v > 10**11 else v
        return datetime.fromtimestamp(secs, tz=timezone.utc).isoformat().replace("+00:00", "Z")
    return str(v)


# ------------------------------------------------------------------ Cortex
def from_cortex_incident(incident: Dict[str, Any]) -> Dict[str, Any]:
    """Accepts a Cortex XDR/XSIAM incident (get_incident_extra_data-style or flattened).
    Expected (UNVALIDATED) fields: incident_id, creation_time (ms), detection_time, description,
    alert_categories[], users[], hosts[], alerts[{detection_timestamp, category, host_name, user_name}]."""
    inc = incident.get("reply", incident)
    inc = inc.get("incident", inc)
    alerts = (incident.get("reply", {}).get("alerts", {}) or {}).get("data", []) or inc.get("alerts", []) or []
    users = list(inc.get("users") or []) + [a.get("user_name") for a in alerts if a.get("user_name")]
    hosts = list(inc.get("hosts") or []) + [a.get("host_name") for a in alerts if a.get("host_name")]
    hosts = [h.split(":")[0] for h in hosts]  # Cortex host entries may be "name:agent_id"
    times = [a.get("detection_timestamp") for a in alerts if a.get("detection_timestamp")]
    t0 = min(times) if times else (inc.get("detection_time") or inc.get("creation_time"))
    cats = [str(c) for c in (inc.get("alert_categories") or [])] + [str(a.get("category")) for a in alerts if a.get("category")]
    text = " ".join(cats + [str(inc.get("description", "")), str(inc.get("incident_name", ""))]).lower()
    matches = []
    for rule in MAPPINGS["cortex"]["categoryToScenario"]:
        hit = next((m for m in rule["match"] if m in text), None)
        if hit and rule["scenario"] not in [m[0] for m in matches]:
            matches.append((rule["scenario"], hit))
    scenario = matches[0][0] if matches else MAPPINGS["cortex"]["defaultScenario"]
    matched = ", ".join(f"'{h}' -> {sid}" for sid, h in matches) if matches else None
    return {
        "incidentId": inc.get("incident_id"),
        "t0": _iso_ms(t0),
        "compromisedUsers": sorted({_norm(u) for u in users if u}),
        "compromisedHosts": sorted({_norm(h) for h in hosts if h}),
        "suggestedScenario": scenario,
        "matchedScenarios": [m[0] for m in matches] or [scenario],
        "scenarioReason": f"incident categories/description matched {matched}" if matched else "no category matched; default playbook",
        "categories": sorted(set(cats)),
    }


# --------------------------------------------------------------------- Wiz
def _wiz_entity(e: Dict[str, Any]) -> Tuple[str, Dict[str, Any], Optional[str]]:
    wtype = str(e.get("type", "")).upper()
    t = MAPPINGS["wiz"]["entityTypes"].get(wtype)
    name = e.get("name") or (e.get("properties") or {}).get("name") or e.get("id")
    nid = f"wiz:{e.get('id') or name}"
    node = {"id": nid, "type": t or "unknown", "name": name, "wizType": wtype}
    if t in ("cloud_vm", "db_server", "workload", "database", "storage", "kubernetes_cluster"):
        node["commvaultClient"] = name  # resolved against Commvault by name/hostname later
    return nid, node, (None if t else wtype)


def from_wiz_graph(result: Dict[str, Any]) -> Dict[str, Any]:
    """Accepts either
       a) explicit graph: {"nodes":[{id,type,name}], "edges":[{source|from, target|to, type|rel}]}
       b) Wiz graphSearch-style rows: {"data":{"graphSearch":{"nodes":[{"entities":[e1,e2,...]}]}}} where each row is an
          ordered path; consecutive entities are linked with defaultPathRelationship (control).  (UNVALIDATED)"""
    nodes, edges, unknown_types, unknown_rels = {}, [], set(), set()
    if "nodes" in result and "edges" in result:
        for e in result["nodes"]:
            nid, node, unk = _wiz_entity(e)
            nodes[e.get("id")] = node
            unknown_types.update([unk] if unk else [])
        for r in result["edges"]:
            a, b = r.get("source", r.get("from")), r.get("target", r.get("to"))
            wrel = str(r.get("type", r.get("rel", ""))).upper()
            rel = MAPPINGS["wiz"]["relationships"].get(wrel)
            if not rel:
                unknown_rels.add(wrel)
                continue
            if a in nodes and b in nodes:
                edges.append({"from": nodes[a]["id"], "to": nodes[b]["id"], "rel": rel, "wizRel": wrel})
    else:
        rows = (((result.get("data") or {}).get("graphSearch") or {}).get("nodes")) or result.get("rows") or []
        default_rel = MAPPINGS["wiz"]["defaultPathRelationship"]
        for row in rows:
            chain = []
            for e in row.get("entities", []) or []:
                nid, node, unk = _wiz_entity(e)
                nodes.setdefault(e.get("id") or nid, node)
                unknown_types.update([unk] if unk else [])
                chain.append(node["id"])
            for a, b in zip(chain, chain[1:]):
                edges.append({"from": a, "to": b, "rel": default_rel, "wizRel": "PATH"})
    uniq = {(e["from"], e["to"], e["rel"]): e for e in edges}
    return {"nodes": list(nodes.values()), "edges": list(uniq.values()),
            "unmappedEntityTypes": sorted(unknown_types), "unmappedRelationships": sorted(unknown_rels)}


# ------------------------------------------------------------------- merge
def build_graph(cortex_incident: Optional[Dict[str, Any]] = None, wiz_graph: Optional[Dict[str, Any]] = None,
                dwell_time_hours: Optional[float] = None) -> Dict[str, Any]:
    cx = from_cortex_incident(cortex_incident) if cortex_incident else None
    wz = from_wiz_graph(wiz_graph) if wiz_graph else {"nodes": [], "edges": [], "unmappedEntityTypes": [],
                                                        "unmappedRelationships": []}
    nodes = {n["id"]: n for n in wz["nodes"]}
    by_name = {}
    for n in nodes.values():
        by_name.setdefault(_norm(n["name"]), []).append(n["id"])
    compromised, unmatched = [], []
    for kind, names in (("user", (cx or {}).get("compromisedUsers", [])), ("server", (cx or {}).get("compromisedHosts", []))):
        for nm in names:
            ids = by_name.get(nm) or by_name.get(nm.split(".")[0])
            if ids:
                compromised += ids
            else:  # not in the Wiz graph: add as a standalone compromised node so it is still scoped
                nid = f"cortex:{kind}:{nm}"
                nodes[nid] = {"id": nid, "type": kind, "name": nm, **({"commvaultClient": nm} if kind == "server" else {})}
                compromised.append(nid)
                unmatched.append(f"{kind} '{nm}' from Cortex not found in the Wiz graph (scoped on its own)")
    graph = {
        "compromised": sorted(set(compromised)),
        "t0": (cx or {}).get("t0"),
        "nodes": list(nodes.values()),
        "edges": wz["edges"],
    }
    if dwell_time_hours is not None:
        graph["dwellTimeHours"] = dwell_time_hours
    return {
        "status": "IMPORTED" if graph["compromised"] else "NO_COMPROMISED_ENTITIES",
        "graph": graph,
        "suggestedScenario": (cx or {}).get("suggestedScenario"),
        "matchedScenarios": (cx or {}).get("matchedScenarios") or [],
        "scenarioReason": (cx or {}).get("scenarioReason"),
        "incidentId": (cx or {}).get("incidentId"),
        "report": {
            "nodes": len(graph["nodes"]), "edges": len(graph["edges"]),
            "unmappedWizEntityTypes": wz["unmappedEntityTypes"],
            "unmappedWizRelationships": wz["unmappedRelationships"],
            "unmatchedCortexEntities": unmatched,
            "note": "Adapter field shapes are unvalidated until checked against real Wiz/Cortex exports.",
        },
    }
