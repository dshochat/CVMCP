# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Approved recovery definitions (baselines) and recovery-drift detection.

A baseline is the owner-approved answer to "what IS this application, for recovery
purposes", plus a protection snapshot. It is stored as local JSON next to the MCP
server (RECOVERY_BASELINE_DIR). Nothing is written to the CommCell.
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.recovery.discovery import RecoveryDiscovery
from src.recovery.sequencing import audit_existing_order, build_sequence, render_plan


def baseline_dir() -> Path:
    d = Path(os.environ.get("RECOVERY_BASELINE_DIR", "recovery_baselines")).resolve()
    d.mkdir(parents=True, exist_ok=True)
    return d


def _slug(app: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", app.strip().lower()).strip("-")
    if not s:
        raise ValueError("application_name must contain letters or digits")
    return s[:80]


def _path(app: str) -> Path:
    return baseline_dir() / f"{_slug(app)}.json"


def _snapshot(resource: Dict[str, Any]) -> Dict[str, Any]:
    p = resource["protection"]
    copies = [c for pl in p["plans"] for c in pl.get("copies", []) if not c.get("isSnapshot")]
    return {
        "id": resource["id"],
        "type": resource["type"],
        "applications": sorted(p["applications"]),
        "subclients": sorted(sc["name"] for sc in p["subclients"]),
        "plans": sorted(pl.get("name") or pl.get("id") for pl in p["plans"]),
        "copyCount": len(copies),
        "regions": sorted({c["region"] for c in copies if c.get("region")}),
        "hasImmutableCopy": any(c.get("immutable") for c in copies),
        "hasAirGappedCopy": any(c.get("airGapped") for c in copies),
        "databases": sorted({d for sc in p["subclients"] for d in (sc.get("databases") or [])}),
    }


def load_baseline(app: str) -> Optional[Dict[str, Any]]:
    path = _path(app)
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def _decide(result: Dict[str, Any], include: List[str], exclude: List[str], require_all: bool):
    inc = {n.lower() for n in include}
    exc = {n.lower() for n in exclude}
    candidates = {r["name"].lower(): r for r in result["resources"] if r["role"] == "candidate"}
    unknown = sorted((inc | exc) - set(candidates))
    if unknown:
        return None, {"status": "REJECTED", "reason": f"Not among discovered candidates: {', '.join(unknown)}. "
                      "Run discover_recovery_application again and use names exactly as returned."}
    undecided = sorted(r["name"] for k, r in candidates.items() if k not in inc and k not in exc)
    if undecided and require_all:
        return None, {"status": "NEEDS_DECISION",
                      "reason": "Every candidate must be explicitly included or excluded by the owner.",
                      "undecidedCandidates": undecided}
    members = [r for r in result["resources"] if r["role"] != "candidate" or r["name"].lower() in inc]
    excluded = sorted(r["name"] for k, r in candidates.items() if k in exc)
    return {"members": members, "excluded": excluded, "undecided": undecided}, None


def propose_sequence(discovery: RecoveryDiscovery, application_name: str, seed_resource: str,
                     include: List[str], exclude: List[str], tier_overrides: Optional[Dict[str, str]] = None,
                     ordering_exceptions: Optional[List[str]] = None) -> Dict[str, Any]:
    result = discovery.discover(seed_resource, application_name)
    if result.get("status") != "DISCOVERED":
        return result
    decided, err = _decide(result, include, exclude, require_all=False)
    if err:
        return err
    plan = build_sequence(application_name, decided["members"], tier_overrides, ordering_exceptions)
    out = {"status": "PROPOSED", "readOnly": True, **plan,
           "members": sorted(r["name"] for r in decided["members"]), "excluded": decided["excluded"]}
    if decided["undecided"]:
        out["undecidedCandidates"] = decided["undecided"]
        out["nextStep"] = ("Owner must include or exclude: " + ", ".join(decided["undecided"]) +
                           ". Then regenerate the sequence.")
    else:
        out["nextStep"] = ("Show this plan to the user. If they agree, call approve_recovery_map with the same "
                           "inputs and plan_hash=" + plan["planHash"] + ". The server will ask the user to confirm directly.")
    return out


def prepare_approval(discovery: RecoveryDiscovery, application_name: str, seed_resource: str,
                     include: List[str], exclude: List[str], plan_hash_in: str,
                     tier_overrides: Optional[Dict[str, str]] = None,
                     ordering_exceptions: Optional[List[str]] = None):
    """Re-run discovery + sequencing server-side and bind to the fingerprint the user was shown.
    Returns (pending, None) or (None, error_result)."""
    result = discovery.discover(seed_resource, application_name)
    if result.get("status") != "DISCOVERED":
        return None, result
    decided, err = _decide(result, include, exclude, require_all=True)
    if err:
        return None, err
    plan = build_sequence(application_name, decided["members"], tier_overrides, ordering_exceptions)
    if plan["planHash"] != (plan_hash_in or "").strip():
        return None, {"status": "PLAN_CHANGED",
                      "reason": "The recovery plan no longer matches the fingerprint the user reviewed "
                                "(production changed, or different inputs were passed). Nothing was approved.",
                      "expectedPlanHash": plan_hash_in, "currentPlanHash": plan["planHash"],
                      "nextStep": "Call generate_recovery_sequence again and show the user the new plan."}
    pending = {
        "application": application_name, "seed": seed_resource, "rpoHours": discovery.rpo_hours,
        "members": {r["name"]: {**_snapshot(r), "role": r["role"] if r["role"] != "candidate" else "owner_confirmed",
                                "evidence": r["evidence"]} for r in decided["members"]},
        "excluded": decided["excluded"], "openGapsAtApproval": result["gaps"],
        "sequence": plan, "tierOverrides": tier_overrides or {}, "orderingExceptions": ordering_exceptions or [],
    }
    text = render_plan(plan, list(pending["members"]), decided["excluded"])
    return {"baseline": pending, "confirmationText": text}, None


def commit_approval(pending: Dict[str, Any], approved_by: str, approval_method: str) -> Dict[str, Any]:
    baseline = {**pending["baseline"], "approvedBy": approved_by, "approvalMethod": approval_method,
                "approvedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                "ownerConfirmedOutsideCommvault": []}
    path = _path(baseline["application"])
    path.write_text(json.dumps(baseline, indent=2), encoding="utf-8")
    seq = baseline["sequence"]
    return {"status": "APPROVED", "application": baseline["application"], "approvedBy": approved_by,
            "approvalMethod": approval_method, "baselineFile": str(path), "planHash": seq["planHash"],
            "members": sorted(baseline["members"]), "excluded": baseline["excluded"],
            "recoveryOrder": [f"P{p['priority']}: " + ", ".join(r["name"] for r in p["resources"])
                              for p in seq["priorities"]],
            "openGaps": len(baseline["openGapsAtApproval"])}


def audit_recovery_group(discovery: RecoveryDiscovery, recovery_group_name: str,
                         application_name: Optional[str] = None) -> Dict[str, Any]:
    """Zero-input audit: classify every entity in an existing Cleanroom recovery group by technology
    and check its priorities against the recommended order. With an approved baseline, also checks membership."""
    group = discovery.r.get_recovery_group(recovery_group_name)
    if not group:
        return {"status": "GROUP_NOT_FOUND", "recoveryGroup": recovery_group_name}
    base = load_baseline(application_name) if application_name else None
    if base:
        plan = base["sequence"]
        basis = f"approved recovery definition for {application_name} ({base['approvedAt']})"
    else:
        resources, unresolved = [], []
        for e in group["entities"]:
            c = discovery.r.resolve_client(e["name"])
            if not c:
                unresolved.append(e["name"])
                continue
            resources.append(discovery._resource(c, "member", "confirmed", [], discovery.profile(c)))
        if not resources:
            return {"status": "UNRESOLVED", "recoveryGroup": recovery_group_name,
                    "reason": "None of the group's entities could be matched to Commvault clients.",
                    "unresolved": unresolved}
        plan = build_sequence(recovery_group_name, resources)
        basis = "technology classification of the group's own members (no approved definition)"
    out = audit_existing_order(plan, group)
    out["basis"] = basis
    out["recoveryGroupDetails"] = {k: group.get(k) for k in ("id", "assemblyId", "runbook", "target", "vendor")}
    if not group.get("prioritiesAvailable", True):
        out["status"] = "PRIORITIES_UNAVAILABLE" if not any(f["type"] == "missing_from_group" for f in out["findings"]) else out["status"]
        out["prioritiesNote"] = ("Group members were read, but per-entity priorities were not returned by the API, "
                                 "so ordering could not be checked. Recommended order is shown for comparison.")
    if not base:
        out["findings"] = [f for f in out["findings"] if f["type"] != "missing_from_group"]
        out["status"] = "ORDER_VIOLATIONS" if out["findings"] else (
            "COMPLIANT" if group.get("prioritiesAvailable", True) else "PRIORITIES_UNAVAILABLE")
        out["summary"] = (f"Recovery group '{group['name']}' has {len(out['findings'])} ordering issue(s)."
                          if out["findings"] else (f"Recovery group '{group['name']}' follows the recommended order."
                          if group.get("prioritiesAvailable", True) else
                          f"Recovery group '{group['name']}': members read, priorities not available from the API."))
        out["classificationsNeedingConfirmation"] = plan["classificationsNeedingConfirmation"]
    out["note"] = "Read-only audit. No change was made to the recovery group."
    return out


def detect_drift(discovery: RecoveryDiscovery, application_name: str) -> Dict[str, Any]:
    base = load_baseline(application_name)
    if not base:
        return {"status": "NO_BASELINE", "application": application_name,
                "nextStep": "Run discover_recovery_application, have the owner review it, then approve_recovery_map."}
    discovery.rpo_hours = base.get("rpoHours", discovery.rpo_hours)
    current = discovery.discover(base["seed"], application_name)
    findings: List[Dict[str, Any]] = []

    def add(sev, kind, res, finding, impact, action):
        findings.append({"severity": sev, "type": kind, "resource": res, "finding": finding,
                         "impact": impact, "recommendedAction": action})

    if current.get("status") != "DISCOVERED":
        add("critical", "seed_missing", base["seed"], "The approved seed resource no longer resolves in Commvault.",
            "The application's anchor resource is gone or renamed; the recovery definition cannot be evaluated.",
            "Confirm with the owner whether the application was migrated or decommissioned.")
        return _drift_result(application_name, base, findings, current)

    by_name = {r["name"]: r for r in current["resources"]}
    known = set(base["members"]) | set(base["excluded"])

    # 1. New resources that now look like part of the application but were never reviewed.
    for r in current["resources"]:
        if r["name"] in known:
            continue
        prot = r["protection"]["protected"]
        add("critical" if not prot else "high", "new_unreviewed_resource", r["name"],
            f"New resource appears to belong to {application_name} ({r['confidence']} confidence: "
            f"{'; '.join(r['evidence'])}) and is {'NOT protected' if not prot else 'protected'} "
            f"but is not part of the approved recovery definition.",
            f"A {application_name} recovery would restore an incomplete application"
            + ("; this resource has no backups at all." if not prot else "."),
            "Owner to review; if it belongs to the application, re-approve the recovery map including it.")

    # 2. Approved members that disappeared or whose protection degraded.
    rediscover = RecoveryDiscovery(discovery.r, rpo_hours=discovery.rpo_hours)
    current_members: List[Dict[str, Any]] = []
    for name, snap in base["members"].items():
        r = by_name.get(name)
        if r is None:
            client = discovery.r.resolve_client(name)
            if not client:
                add("high", "member_missing", name, "Approved member no longer exists in Commvault.",
                    "Either it was decommissioned or it is no longer protected under any client.",
                    "Confirm with the owner; update the recovery definition.")
                continue
            prof = rediscover.profile(client)
            r = rediscover._resource(client, "member", "confirmed", [], prof)
            add("medium", "membership_signal_lost", name,
                "Approved member is no longer linked to the application by Commvault signals (e.g. removed from client group).",
                "Future discovery may silently miss it.", "Restore the grouping or confirm the change with the owner.")
        current_members.append(r)
        now = _snapshot(r)
        p = r["protection"]
        if p.get("protectionUnknown"):
            add("medium", "protection_unknown", name, "Protection could not be determined from the API.",
                "Recoverability of this member is unverified.", "Verify in Command Center.")
            continue
        if not p["protected"]:
            add("critical", "protection_removed", name, "Approved member is no longer protected.",
                "This component cannot be recovered.", "Re-associate a plan immediately.")
            continue
        for sc in sorted(set(snap["subclients"]) - set(now["subclients"])):
            add("high", "subclient_removed", name, f"Subclient '{sc}' no longer exists.",
                "Data previously protected by it may now be unprotected.", "Verify content is covered elsewhere.")
        for app in sorted(set(snap["applications"]) - set(now["applications"])):
            add("medium", "application_removed", name, f"Application '{app}' is no longer discovered on the client.",
                "Application-consistent recovery for it may no longer be possible.", "Confirm with the owner.")
        for db in sorted(set(snap["databases"]) - set(now["databases"])):
            add("high", "database_removed", name, f"Database '{db}' is no longer in protected content.",
                "That database would be missing after recovery.", "Add it back to subclient content.")
        for db in sorted(set(now["databases"]) - set(snap["databases"])):
            add("low", "database_added", name, f"New protected database '{db}'.",
                "Recovery definition is out of date (informational).", "Re-approve the recovery map.")
        if snap["plans"] != now["plans"]:
            add("medium", "plan_changed", name, f"Plan changed from {snap['plans']} to {now['plans']}.",
                "Retention, copies and RPO may differ from what was approved.", "Validate the new plan meets the application tier.")
        if now["copyCount"] < snap["copyCount"]:
            add("high", "copy_removed", name, f"Copies dropped from {snap['copyCount']} to {now['copyCount']}.",
                "Fewer independent recovery sources.", "Restore the secondary copy.")
        if snap["hasImmutableCopy"] and not now["hasImmutableCopy"]:
            add("critical", "immutability_lost", name, "Immutable copy is no longer present.",
                "Recovery points can now be altered or deleted by an attacker.", "Restore immutable storage for this plan.")
        if snap["hasAirGappedCopy"] and not now["hasAirGappedCopy"]:
            add("critical", "air_gap_lost", name, "Air-gapped copy is no longer present.",
                "Ransomware on the production network may reach every recovery point.", "Restore the air-gapped copy.")
        if len(snap["regions"]) > 1 and len(now["regions"]) <= 1:
            add("high", "region_diversity_lost", name, "Copies are no longer spread across regions.",
                "A regional outage would affect every recovery point.", "Restore a copy in a second region.")
        h = p["hoursSinceLastGoodBackup"]
        if h is None or h > discovery.rpo_hours:
            add("high", "rpo_breach", name,
                "No successful backup in the lookback window." if h is None else
                f"Last successful backup {h}h ago exceeds the {discovery.rpo_hours}h RPO.",
                "Recovery would lose more data than approved.", "Investigate failing or missing backup jobs.")

    # 3. Recovery-order drift.
    approved_seq = base.get("sequence")
    if approved_seq and current_members:
        _order_drift(application_name, base, approved_seq, current_members,
                     [r for r in current["resources"] if r["name"] not in known and r["confidence"] in ("high", "confirmed")],
                     add)

    return _drift_result(application_name, base, findings, current)


def _priority_map(plan):
    return {r["name"]: (p["priority"], r["tier"]) for p in plan["priorities"] for r in p["resources"]}


def _order_drift(app, base, approved_seq, members, new_resources, add):
    overrides, exceptions = base.get("tierOverrides") or {}, base.get("orderingExceptions") or []
    approved = _priority_map(approved_seq)
    try:
        now_seq = build_sequence(app, members, overrides, exceptions)
    except ValueError:
        return
    now = _priority_map(now_seq)
    for name, (prio, tier) in now.items():
        if name in approved and approved[name][1] != tier:
            add("high", "technology_changed", name,
                f"Classified as {tier} tier now (was {approved[name][1]}): "
                + now_seq_evidence(now_seq, name),
                "The approved recovery order is based on the old role of this server.",
                "Re-approve the recovery map so the order reflects the new technology.")
    if not new_resources:
        return
    try:
        projected = build_sequence(app, members + new_resources, overrides, exceptions)
    except ValueError:
        return
    proj = _priority_map(projected)
    new_names = {r["name"] for r in new_resources}
    waits = {r["name"]: r["waitsFor"] for p in projected["priorities"] for r in p["resources"]}
    for n in sorted(new_names):
        prio, tier = proj[n]
        dependents = sorted(m for m, w in waits.items() if n in w and m not in new_names)
        add("high", "recovery_order_drift", n,
            f"New {tier}-tier resource would recover at priority {prio}"
            + (f"; {', '.join(dependents)} must now wait for it." if dependents else "."),
            "The approved recovery order does not include it"
            + (f", so {', '.join(dependents)} could start before {n} is available." if dependents else "."),
            "Proposed order: " + " -> ".join(
                "[" + ", ".join(r["name"] for r in p["resources"]) + "]" for p in projected["priorities"]))


def now_seq_evidence(plan, name):
    for p in plan["priorities"]:
        for r in p["resources"]:
            if r["name"] == name:
                return "; ".join(r["evidence"])
    return ""


def _drift_result(app, base, findings, current):
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings.sort(key=lambda f: order[f["severity"]])
    worst = findings[0]["severity"] if findings else None
    if not findings:
        headline = f"{app}: recovery definition is IN SYNC with production as seen by Commvault."
    else:
        headline = (f"{app}: RECOVERY DRIFT DETECTED - {len(findings)} finding(s), worst severity {worst}. "
                    f"Top: {findings[0]['finding']}")
    return {
        "application": app,
        "status": "DRIFT_DETECTED" if findings else "IN_SYNC",
        "summary": headline,
        "baselineApprovedAt": base["approvedAt"],
        "baselineApprovedBy": base["approvedBy"],
        "findings": findings,
        "checkedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "readOnly": True,
        "note": "No changes were made to Commvault. Every recommended action requires a human decision.",
    }
