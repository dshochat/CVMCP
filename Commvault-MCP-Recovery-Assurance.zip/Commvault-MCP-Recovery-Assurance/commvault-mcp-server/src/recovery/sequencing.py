# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Technology-aware recovery sequencing.

Philosophy: zero-input ordering for normal architectures, human input only for exceptions.

  1. Classify every resource into a recovery tier, with evidence:
       - Commvault agent discovered on the client  -> strong ("confirmed")
       - naming convention                          -> "medium", needs confirmation
       - nothing recognisable                       -> "low", defaults to application tier, needs confirmation
  2. Build a recovery DAG: every resource waits for the nearest lower tier that is present,
     plus any explicit owner exceptions ("A before B").
  3. Layer the DAG (longest path) -> Commvault Cleanroom recovery-group priorities (1 = first).
  4. Attach per-technology readiness gates (what "healthy" means before the next priority is released).
     Gates are recommendations in this version; they are not executed.

Shared foundation services (AD, DNS, identity) are treated as cleanroom prerequisites shared by
all applications, not as members of a single application's recovery group, unless discovered
inside the application itself.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Iterable, List, Optional, Tuple

from src.recovery.cv_reader import name_tokens

TIERS: Dict[str, Dict[str, Any]] = {
    "foundation":   {"rank": 1, "label": "Foundation (identity, DNS, core services)"},
    "data":         {"rank": 2, "label": "Data (databases)"},
    "middleware":   {"rank": 3, "label": "Messaging / cache / shared middleware"},
    "application":  {"rank": 4, "label": "Application backend"},
    "presentation": {"rank": 5, "label": "Presentation (web / frontend)"},
}

# Commvault agent (iDA) names -> tier. Strong evidence: Commvault itself discovered the technology.
AGENT_TIERS = {
    "active directory": "foundation",
    "sql server": "data", "oracle": "data", "oracle rac": "data", "db2": "data", "postgresql": "data",
    "mysql": "data", "sap hana": "data", "sybase": "data", "informix": "data", "mongodb": "data",
    "cassandra": "data", "cosmos db": "data", "dynamodb": "data", "exchange database": "data",
    "sap for oracle": "data", "sap for hana": "data",
}

# Hostname tokens -> tier. Medium evidence: convention only.
NAME_TIERS = [
    ("foundation", {"dc", "ad", "adds", "dns", "ldap", "idp", "pdc"}),
    ("data", {"sql", "db", "dbs", "ora", "oracle", "pg", "pgsql", "postgres", "mysql", "mongo", "hana", "db2"}),
    ("middleware", {"kafka", "mq", "rabbit", "rabbitmq", "redis", "cache", "queue", "esb", "broker", "zk", "zookeeper"}),
    ("presentation", {"web", "www", "iis", "nginx", "frontend", "fe", "portal", "ui", "proxy", "lb"}),
    ("application", {"app", "api", "svc", "service", "backend", "be", "mid", "batch", "worker", "jboss", "tomcat"}),
]

READINESS = {
    "foundation":   ["Domain controller services running", "DNS resolves internal zone", "LDAP bind succeeds"],
    "data":         ["Database service running", "Every protected database ONLINE/OPEN", "Test query (SELECT 1) succeeds"],
    "middleware":   ["Broker/cache service listening", "Topic/queue or keyspace reachable"],
    "application":  ["Application service running", "Health endpoint (e.g. GET /health) returns 200"],
    "presentation": ["Web service running", "Front-end URL returns 200 through the cleanroom network"],
}

OVERRIDABLE = set(TIERS)


def classify(resource: Dict[str, Any], tier_overrides: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    name = resource["name"]
    overrides = {k.lower(): v.lower() for k, v in (tier_overrides or {}).items()}
    if name.lower() in overrides:
        t = overrides[name.lower()]
        if t not in OVERRIDABLE:
            raise ValueError(f"Unknown tier '{t}' for {name}. Valid tiers: {', '.join(TIERS)}")
        return {"tier": t, "confidence": "confirmed", "evidence": ["Set by application owner (exception)"],
                "needsConfirmation": False}

    apps = [a.lower() for a in resource.get("protection", {}).get("applications", [])]
    agent_hits = sorted({AGENT_TIERS[a] for a in apps if a in AGENT_TIERS}, key=lambda t: TIERS[t]["rank"])
    if agent_hits:
        tier = agent_hits[0]  # a client hosting a DB is recovered with the data tier
        agents = [a for a in resource["protection"]["applications"] if AGENT_TIERS.get(a.lower()) == tier]
        return {"tier": tier, "confidence": "confirmed",
                "evidence": [f"Commvault discovered {', '.join(agents)} on this client"],
                "needsConfirmation": False}

    tokens = set(name_tokens(name))
    for tier, words in NAME_TIERS:
        hit = tokens & words
        if hit:
            return {"tier": tier, "confidence": "medium",
                    "evidence": [f"Hostname contains '{sorted(hit)[0]}' (naming convention, no technology evidence)"],
                    "needsConfirmation": True}

    return {"tier": "application", "confidence": "low",
            "evidence": ["No technology evidence; defaulted to application tier"], "needsConfirmation": True}


def _parse_exceptions(exceptions: Iterable[str], names: List[str]) -> List[Tuple[str, str]]:
    lookup = {n.lower(): n for n in names}
    pairs = []
    for e in exceptions or []:
        sep = " before " if " before " in e.lower() else (">" if ">" in e else None)
        if not sep:
            raise ValueError(f"Ordering exception '{e}' must look like 'A before B' or 'A>B'")
        idx = e.lower().index(sep)
        a, b = e[:idx].strip(), e[idx + len(sep):].strip()
        if a.lower() not in lookup or b.lower() not in lookup:
            raise ValueError(f"Ordering exception '{e}' refers to a resource not in the plan")
        pairs.append((lookup[a.lower()], lookup[b.lower()]))
    return pairs


def build_sequence(application: str, resources: List[Dict[str, Any]],
                   tier_overrides: Optional[Dict[str, str]] = None,
                   ordering_exceptions: Optional[List[str]] = None) -> Dict[str, Any]:
    """resources: discovery resource dicts that are (proposed) members of the application."""
    names = [r["name"] for r in resources]
    cls = {r["name"]: classify(r, tier_overrides) for r in resources}
    rank = {n: TIERS[cls[n]["tier"]]["rank"] for n in names}

    # Edges: n depends on every resource in the nearest lower tier that is present.
    deps: Dict[str, set] = {n: set() for n in names}
    present = sorted(set(rank.values()))
    for n in names:
        lower = [r for r in present if r < rank[n]]
        if lower:
            deps[n] |= {m for m in names if rank[m] == lower[-1]}
    edges_from_exceptions = _parse_exceptions(ordering_exceptions or [], names)
    for a, b in edges_from_exceptions:
        deps[b].add(a)
        deps[a].discard(b)  # owner exception overrides the tier rule in the opposite direction

    # Longest-path layering with cycle detection (Kahn).
    level: Dict[str, int] = {}
    remaining = {n: set(d) for n, d in deps.items()}
    current = 1
    while remaining:
        ready = sorted([n for n, d in remaining.items() if not d], key=lambda x: (rank[x], x))
        if not ready:
            raise ValueError("Ordering exceptions create a cycle between: " + ", ".join(sorted(remaining)))
        for n in ready:
            level[n] = current
            del remaining[n]
        for d in remaining.values():
            d.difference_update(ready)
        current += 1

    priorities = []
    for p in sorted(set(level.values())):
        members = sorted([n for n in names if level[n] == p], key=lambda x: (rank[x], x))
        tiers = sorted({cls[n]["tier"] for n in members}, key=lambda t: TIERS[t]["rank"])
        priorities.append({
            "priority": p,
            "tiers": [TIERS[t]["label"] for t in tiers],
            "resources": [{"name": n, "tier": cls[n]["tier"], "confidence": cls[n]["confidence"],
                           "evidence": cls[n]["evidence"], "waitsFor": sorted(deps[n])} for n in members],
            "releaseNextPriorityWhen": sorted({g for t in tiers for g in READINESS[t]}),
        })

    has_foundation = any(c["tier"] == "foundation" for c in cls.values())
    needs = [{"resource": n, "proposedTier": cls[n]["tier"], "why": cls[n]["evidence"][0]}
             for n in names if cls[n]["needsConfirmation"]]
    plan = {
        "application": application,
        "priorities": priorities,
        "prerequisites": [] if has_foundation else [
            "Shared foundation services (Active Directory, DNS) must be recovered and healthy in the cleanroom "
            "before Priority 1. They are shared across applications and are not part of this recovery group."],
        "ownerExceptionsApplied": [f"{a} before {b}" for a, b in edges_from_exceptions],
        "classificationsNeedingConfirmation": needs,
        "commvaultMapping": [{"entity": r["name"], "executionOrder": {"priority": p["priority"]}}
                             for p in priorities for r in p["resources"]],
        "readinessGatesNote": "Readiness gates are recommended checks; this version does not execute them.",
    }
    plan["planHash"] = plan_hash(plan)
    return plan


def plan_hash(plan: Dict[str, Any]) -> str:
    """Hash of exactly what the user approves: members, tiers, priorities, prerequisites, exceptions."""
    core = {
        "application": plan["application"],
        "order": [(p["priority"], r["name"], r["tier"]) for p in plan["priorities"] for r in p["resources"]],
        "prerequisites": plan["prerequisites"],
        "exceptions": plan["ownerExceptionsApplied"],
    }
    return hashlib.sha256(json.dumps(core, sort_keys=True).encode()).hexdigest()[:16]


def render_plan(plan: Dict[str, Any], members: List[str], excluded: List[str]) -> str:
    """Human-readable plan text shown verbatim in the confirmation dialog."""
    lines = [f"Approve the recovery definition for {plan['application']}?", "",
             f"Members ({len(members)}): {', '.join(sorted(members))}"]
    if excluded:
        lines.append(f"Excluded: {', '.join(sorted(excluded))}")
    lines += ["", "Recovery order:"]
    for pre in plan["prerequisites"]:
        lines.append(f"  Before P1: {pre.split('.')[0]}")
    for p in plan["priorities"]:
        lines.append(f"  P{p['priority']}: " + ", ".join(
            f"{r['name']} [{r['tier']}{'' if r['confidence'] == 'confirmed' else ', inferred'}]" for r in p["resources"]))
    if plan["classificationsNeedingConfirmation"]:
        lines += ["", "Inferred from naming only - check these:"]
        lines += [f"  {c['resource']} -> {c['proposedTier']}" for c in plan["classificationsNeedingConfirmation"]]
    lines += ["", f"Plan fingerprint: {plan['planHash']}",
              "Approving writes a local baseline only; nothing in Commvault changes."]
    return "\n".join(lines)


def audit_existing_order(plan: Dict[str, Any], group: Dict[str, Any]) -> Dict[str, Any]:
    """Compare an existing Commvault recovery group's priorities against the recommended sequence."""
    rec = {r["name"].lower(): (p["priority"], r["tier"]) for p in plan["priorities"] for r in p["resources"]}
    actual = {e["name"].lower(): (e["name"], e.get("priority")) for e in group["entities"]}
    findings = []
    names = sorted(set(rec) & set(actual))
    for a in names:
        for b in names:
            ra, rb = rec[a][0], rec[b][0]
            pa, pb = actual[a][1], actual[b][1]
            if ra < rb and pa is not None and pb is not None and pa > pb:
                findings.append({
                    "severity": "high",
                    "type": "order_violation",
                    "finding": f"{actual[b][0]} ({rec[b][1]}) recovers at priority {pb}, BEFORE "
                               f"{actual[a][0]} ({rec[a][1]}) at priority {pa}.",
                    "impact": f"{actual[b][0]} will start before the {rec[a][1]} tier it depends on is available.",
                    "recommendation": f"Recover {actual[a][0]} before {actual[b][0]}.",
                })
            elif ra < rb and pa is not None and pa == pb:
                findings.append({
                    "severity": "medium", "type": "same_priority",
                    "finding": f"{actual[a][0]} ({rec[a][1]}) and {actual[b][0]} ({rec[b][1]}) share priority {pa}.",
                    "impact": "They start in parallel; the dependent tier may start before its dependency is ready.",
                    "recommendation": f"Put {actual[a][0]} in an earlier priority than {actual[b][0]}.",
                })
    original = {r["name"].lower(): r["name"] for p in plan["priorities"] for r in p["resources"]}
    for n in sorted(set(rec) - set(actual)):
        findings.append({"severity": "high", "type": "missing_from_group",
                         "finding": f"Approved member {original[n]} is not in the recovery group.",
                         "impact": "Cleanroom recovery would bring back an incomplete application.",
                         "recommendation": "Add it to the recovery group at the recommended priority."})
    order = {"high": 0, "medium": 1}
    findings.sort(key=lambda f: order[f["severity"]])
    return {
        "recoveryGroup": group["name"],
        "status": "ORDER_VIOLATIONS" if findings else "COMPLIANT",
        "summary": (f"Recovery group '{group['name']}' has {len(findings)} ordering issue(s)."
                    if findings else f"Recovery group '{group['name']}' follows the recommended order."),
        "currentOrder": sorted(({"entity": v[0], "priority": v[1]} for v in actual.values()),
                               key=lambda x: (x["priority"] is None, x["priority"])),
        "recommendedOrder": plan["commvaultMapping"],
        "findings": findings,
        "readOnly": True,
    }
