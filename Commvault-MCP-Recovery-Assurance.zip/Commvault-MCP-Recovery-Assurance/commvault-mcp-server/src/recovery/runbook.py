# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Scenario-driven recovery runbooks.

  security scenario (catalog)  +  blast radius (graph)  +  technology recovery order (sequencing)
                                         |
                                         v
     phased runbook: contain -> trusted plane -> clean points -> recover (by priority) -> validate -> rotate -> reconnect

Scenarios are data: src/recovery/scenarios/*.json. Each defines its recovery-point policy, isolation,
per-tier action (restore pre-cutoff, clean latest, rebuild from image, data only, no restore) and the
non-Commvault steps. Every step is labelled with an actor and whether Commvault can automate it.
Read-only: nothing is executed.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.recovery.blast_radius import assess
from src.recovery.discovery import RecoveryDiscovery
from src.recovery.sequencing import audit_existing_order, build_sequence

CATALOG_DIR = Path(__file__).resolve().parent / "scenarios"
REQUIRED = {"id", "name", "description", "defaultDwellHours", "recoveryPointPolicy", "tierActions", "phases"}
RECOVER = "__RECOVERY_SEQUENCE__"

ACTION_TEXT = {
    "restore_pre_cutoff": "Restore from the pre-cutoff recovery point",
    "restore_clean_latest": "Restore from the newest recovery point confirmed clean by Threat Scan",
    "restore_data_pre_cutoff": "Restore DATA ONLY from the pre-cutoff point (no OS/binaries)",
    "restore_data_pre_cutoff_out_of_place": "Restore DATA ONLY from the pre-cutoff point, OUT OF PLACE, for reconciliation",
    "rebuild_from_image": "Rebuild from a known-good image; do NOT restore OS/binaries from backups taken after the cutoff",
    "no_restore": "No restore needed for this scenario; verify integrity only",
    "not_protected": "NOT PROTECTED by Commvault: rebuild or recover by other means",
    "verify_protection": "Protection could not be confirmed via API: verify in Command Center, then restore from the pre-cutoff point",
}


def load_catalog() -> Dict[str, Dict[str, Any]]:
    catalog = {}
    for f in sorted(CATALOG_DIR.glob("*.json")):
        sc = json.loads(f.read_text(encoding="utf-8"))
        missing = REQUIRED - set(sc)
        if missing:
            raise ValueError(f"Scenario {f.name} is missing: {', '.join(sorted(missing))}")
        catalog[sc["id"]] = sc
    return catalog


def list_scenarios() -> List[Dict[str, Any]]:
    return [{"id": s["id"], "name": s["name"], "description": s["description"],
             "defaultDwellHours": s["defaultDwellHours"], "recoveryPointPolicy": s["recoveryPointPolicy"],
             "isolation": s.get("isolation")} for s in load_catalog().values()]


PRECEDENCE = ["identity_compromise", "cloud_iam_compromise", "malicious_update", "ransomware", "data_tampering"]


def merge_scenarios(catalog: Dict[str, Dict[str, Any]], ids: List[str]) -> Dict[str, Any]:
    """Combine playbooks for chained attacks (e.g. identity compromise -> ransomware).
    Primary = highest precedence. Strictest recovery-point rule wins (before_cutoff over clean_latest);
    longest default dwell; secondary playbooks contribute steps the primary does not already have."""
    ids = sorted(dict.fromkeys(ids), key=lambda i: PRECEDENCE.index(i) if i in PRECEDENCE else 99)
    primary = json.loads(json.dumps(catalog[ids[0]]))
    if len(ids) == 1:
        return primary
    order = [ph["phase"] for ph in primary["phases"]]
    for sid in ids[1:]:
        sec = catalog[sid]
        for ph in sec["phases"]:
            if ph["steps"] == RECOVER:
                continue
            if ph["phase"] in order:
                target = primary["phases"][order.index(ph["phase"])]
                if target["steps"] == RECOVER:
                    continue
                have = {st["title"] for st in target["steps"]}
                target["steps"] += [dict(st, detail=f"{st['detail']} (from {sec['name']} playbook)")
                                    for st in ph["steps"] if st["title"] not in have]
            else:
                pos = order.index("recover") if ph["phase"] in ("contain", "trusted_plane", "recovery_points", "foundation") and "recover" in order else len(order)
                primary["phases"].insert(pos, json.loads(json.dumps(ph)))
                order.insert(pos, ph["phase"])
    policies = {catalog[i]["recoveryPointPolicy"] for i in ids}
    primary["recoveryPointPolicy"] = "before_cutoff" if "before_cutoff" in policies else primary["recoveryPointPolicy"]
    if primary["recoveryPointPolicy"] == "before_cutoff":
        primary["tierActions"] = {t: ("restore_pre_cutoff" if a == "restore_clean_latest" else a)
                                  for t, a in primary["tierActions"].items()}
    primary["defaultDwellHours"] = max(catalog[i]["defaultDwellHours"] for i in ids)
    primary["name"] = " + ".join(catalog[i]["name"].split(" (")[0] for i in ids)
    primary["id"] = "+".join(ids)
    return primary


def _recovery_point_text(action: str, res: Dict[str, Any], policy: str) -> Dict[str, Any]:
    cp = res.get("recoveryPoint") or {}
    cand = cp.get("cleanCandidate")
    pre = (f"{cand['completed']} (job {cand['jobId']})" if cand else "NONE before cutoff - see gaps")
    if action == "rebuild_from_image":
        return {"text": "Known-good image from before the cutoff", "commvault": None}
    if action in ("no_restore", "not_protected"):
        return {"text": "n/a (no Commvault recovery point)" if action == "not_protected" else "n/a", "commvault": None}
    if action == "restore_clean_latest":
        return {"text": f"Newest Threat-Scan-clean point; fallback {pre}",
                "commvault": {"recoveryPointCategory": "LATEST_CLEAN (requires Threat Scan)", "fallback": cand}}
    return {"text": pre, "commvault": {"recoveryPointCategory": "SPECIFIC_POINT", "point": cand}}


def build_runbook(discovery: RecoveryDiscovery, scenario_id: Any, graph: Dict[str, Any],
                  dwell_hours: Optional[float] = None, recovery_group_name: str = "",
                  application_members: Optional[List[str]] = None,
                  scenario_selection: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    catalog = load_catalog()
    ids = [i.strip() for i in (scenario_id.split(",") if isinstance(scenario_id, str) else scenario_id or []) if i.strip()]
    unknown = [i for i in ids if i not in catalog]
    if not ids or unknown:
        return {"status": "UNKNOWN_SCENARIO", "unknown": unknown, "available": sorted(catalog)}
    sc = merge_scenarios(catalog, ids)
    if dwell_hours is None:
        dwell_hours = float(graph.get("dwellTimeHours")) if graph.get("dwellTimeHours") is not None else float(sc["defaultDwellHours"])
    br = assess(discovery, graph, dwell_hours)
    scope = list(br["recoveryScope"])
    notes: List[str] = list(br["warnings"])

    # Optional: bring along the rest of an approved application so it is recovered consistently.
    in_scope = {r["name"].lower() for r in scope}
    for name in application_members or []:
        if name.lower() in in_scope:
            continue
        client = discovery.r.resolve_client(name)
        if client:
            res = discovery._resource(client, "application_member", "confirmed",
                                      ["Not in the blast radius; part of the approved application definition"],
                                      discovery.profile(client))
            res["recoveryPoint"] = None
            scope.append(res)
            notes.append(f"{client['name']} added from the application definition (outside the blast radius).")

    # depends_on edges -> ordering exceptions between in-scope resources.
    node_to_client = {r.get("graphNode"): r["name"] for r in scope if r.get("graphNode")}
    exceptions = []
    for e in graph.get("edges") or []:
        if str(e.get("rel", "")).lower() == "depends_on":
            a, b = node_to_client.get(str(e["from"])), node_to_client.get(str(e["to"]))
            if a and b and a != b:
                exceptions.append(f"{b} before {a}")
    try:
        seq = build_sequence(f"{sc['name']} recovery", scope, None, exceptions) if scope else None
    except ValueError as err:
        notes.append(f"Dependency hints ignored ({err}); technology order used.")
        seq = build_sequence(f"{sc['name']} recovery", scope) if scope else None

    by_name = {r["name"]: r for r in scope}
    recovery_steps: List[Dict[str, Any]] = []
    if seq:
        for p in seq["priorities"]:
            for item in p["resources"]:
                res = by_name[item["name"]]
                action = sc["tierActions"].get(item["tier"], "restore_pre_cutoff")
                if res["protection"].get("protectionUnknown") and action not in ("no_restore", "rebuild_from_image"):
                    action = "verify_protection"
                elif not res["protection"]["protected"] and action not in ("no_restore", "rebuild_from_image"):
                    action = "not_protected"   # keeps its place in the order, but nothing to restore
                rp = _recovery_point_text(action, res, sc["recoveryPointPolicy"])
                recovery_steps.append({
                    "title": f"P{p['priority']} - {item['name']} [{item['tier']}]: {ACTION_TEXT[action]}",
                    "actor": "app_owner" if action in ("rebuild_from_image", "not_protected", "verify_protection") else "commvault",
                    "automatable": action not in ("rebuild_from_image", "no_restore", "not_protected", "verify_protection"),
                    "detail": f"Recovery point: {rp['text']}. Waits for: {', '.join(item['waitsFor']) or 'nothing'}. "
                              f"Why in scope: {'; '.join(res['evidence'])}",
                    "commvault": {"cleanroomPriority": p["priority"], "isolation": sc.get("isolation"), **(rp["commvault"] or {})}
                                 if rp["commvault"] else None,
                })
            recovery_steps.append({
                "title": f"Gate: release priority {p['priority'] + 1} only when P{p['priority']} is healthy",
                "actor": "app_owner", "automatable": False,
                "detail": "; ".join(p["releaseNextPriorityWhen"]),
                "commvault": None,
            })
        if recovery_steps and recovery_steps[-1]["title"].startswith("Gate"):
            recovery_steps.pop()
    else:
        recovery_steps.append({"title": "No Commvault-protected resources in the blast radius", "actor": "security_team",
                               "automatable": False, "detail": "Review gaps: affected resources may be unprotected or "
                               "missing from the graph.", "commvault": None})

    phases, n = [], 0
    for ph in sc["phases"]:
        steps = recovery_steps if ph["steps"] == RECOVER else list(ph["steps"])
        if ph["phase"] == "contain" and br["identityObjects"]:
            id_list = ", ".join(o["name"] for o in br["identityObjects"][:25])
            steps = [{"title": f"Disable or reset the {len(br['identityObjects'])} identity/control object(s) in the blast radius",
                      "actor": "identity_team", "automatable": False,
                      "detail": id_list + (" ..." if len(br["identityObjects"]) > 25 else ""), "commvault": None}] + steps
        numbered = []
        for s in steps:
            n += 1
            numbered.append({"step": n, **s})
        phases.append({"phase": ph["phase"], "title": ph["title"], "steps": numbered})

    # Existing Cleanroom recovery group vs this scenario.
    rg_findings = []
    if recovery_group_name:
        g = discovery.r.get_recovery_group(recovery_group_name)
        if not g:
            rg_findings.append({"severity": "medium", "finding": f"Recovery group '{recovery_group_name}' not found."})
        else:
            cat = str(g.get("recoveryPointCategory") or "").upper()
            if sc["recoveryPointPolicy"] == "before_cutoff" and cat == "LATEST":
                rg_findings.append({"severity": "critical", "finding":
                    f"Recovery group '{g['name']}' is set to recover the LATEST recovery point. For {sc['name']} the "
                    f"latest points may contain attacker changes; use points from before {br['cleanCutoff']}."})
            if cat == "":
                rg_findings.append({"severity": "medium", "finding":
                    f"The recovery-point setting of '{g['name']}' could not be read from the API; confirm it is not LATEST."})
            if g.get("entities") and not g.get("prioritiesAvailable", True):
                rg_findings.append({"severity": "medium", "finding":
                    f"Per-machine priorities of '{g['name']}' were not returned by the API, so its order could not be checked."})
            if seq and g.get("entities"):
                audit = audit_existing_order(seq, g)
                for f in audit["findings"]:
                    if f["type"] == "missing_from_group":
                        continue  # reported below with scenario wording
                    rg_findings.append({"severity": f["severity"], "finding": f["finding"]})
            for e in g.get("entities", []):
                if e.get("ready") is False:
                    rg_findings.append({"severity": "high", "finding":
                        f"Commvault reports '{e['name']}' in '{g['name']}' is NOT ready for recovery: {str(e.get('notReadyReason'))[:200]}"})
            members = {e["name"].lower() for e in g.get("entities", [])}
            for r in scope:
                if members and r["name"].lower() not in members:
                    rg_findings.append({"severity": "high", "finding":
                        f"{r['name']} is in the recovery scope but not in recovery group '{g['name']}'."})

    manual = sum(1 for ph in phases for s in ph["steps"] if not s["automatable"])
    auto = sum(1 for ph in phases for s in ph["steps"] if s["automatable"])
    runbook = {
        "status": "RUNBOOK_READY" if scope else "NO_RECOVERY_SCOPE",
        "readOnly": True,
        "scenario": {"id": sc["id"], "name": sc["name"], "recoveryPointPolicy": sc["recoveryPointPolicy"],
                     "isolation": sc.get("isolation"), "playbooks": ids},
        "scenarioSelection": scenario_selection or {"source": "specified by caller", "playbooks": ids},
        "t0": br["t0"], "dwellTimeHours": dwell_hours, "cleanCutoff": br["cleanCutoff"],
        "summary": (f"{sc['name']}: {sum(1 for r in scope if r['protection']['protected'])} resource(s) to recover from Commvault"
                    + (f" + {sum(1 for r in scope if not r['protection']['protected'] and not r['protection'].get('protectionUnknown'))} unprotected to rebuild"
                       if any(not r['protection']['protected'] and not r['protection'].get('protectionUnknown') for r in scope) else "")
                    + (f" + {sum(1 for r in scope if r['protection'].get('protectionUnknown'))} to verify"
                       if any(r['protection'].get('protectionUnknown') for r in scope) else "")
                    + f" in {len(seq['priorities']) if seq else 0} "
                    f"priority group(s); {auto} Commvault-automatable step(s), {manual} manual step(s); "
                    f"{len(br['gaps'])} gap(s)" + (f"; {len(rg_findings)} recovery-group finding(s)" if rg_findings else "") + "."),
        "phases": phases,
        "recoveryOrder": [f"P{p['priority']}: " + ", ".join(r["name"] for r in p["resources"]) for p in seq["priorities"]] if seq else [],
        "recoveryPlan": [
            {"name": r["name"], "clientId": by_name[r["name"]].get("id"), "tier": r["tier"], "priority": p["priority"],
             "action": sc["tierActions"].get(r["tier"], "restore_pre_cutoff"),
             "protected": by_name[r["name"]]["protection"]["protected"],
             "protectionUnknown": by_name[r["name"]]["protection"].get("protectionUnknown", False),
             "applications": by_name[r["name"]]["protection"]["applications"],
             "subclients": by_name[r["name"]]["protection"]["subclients"],
             "cleanPoint": ((by_name[r["name"]].get("recoveryPoint") or {}).get("cleanCandidate"))}
            for p in (seq["priorities"] if seq else []) for r in p["resources"]],
        "blastRadius": {k: br[k] for k in ("summary", "compromised", "affectedNodes", "identityObjects", "gaps", "note")},
        "recoveryGroupFindings": rg_findings,
        "notes": notes,
        "generatedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    }
    runbook["runbookHash"] = hashlib.sha256(json.dumps(
        {"s": sc["id"], "c": br["cleanCutoff"], "o": runbook["recoveryOrder"],
         "p": [[x["title"] for x in ph["steps"]] for ph in phases]}, sort_keys=True).encode()).hexdigest()[:16]
    runbook["markdown"] = render_markdown(runbook)
    return runbook


def render_markdown(rb: Dict[str, Any]) -> str:
    L = [f"# Recovery runbook - {rb['scenario']['name']}", "",
         f"- Compromise time (t0): **{rb['t0'] or 'unknown'}** - dwell time {rb['dwellTimeHours']} h - "
         f"clean cutoff: **{rb['cleanCutoff'] or 'n/a'}**",
         f"- Playbook(s): {', '.join(rb['scenario']['playbooks'])} - selected: {rb['scenarioSelection'].get('source')}"
         + (f" ({rb['scenarioSelection']['reason']})" if rb['scenarioSelection'].get('reason') else ""),
         f"- Recovery-point policy: `{rb['scenario']['recoveryPointPolicy']}` - isolation: `{rb['scenario']['isolation']}`",
         f"- Recovery order: {' -> '.join(rb['recoveryOrder']) or 'n/a'}",
         f"- Fingerprint: `{rb['runbookHash']}` - generated {rb['generatedAt']} (read-only plan; nothing executed)", ""]
    if rb["recoveryGroupFindings"]:
        L += ["## Existing recovery group findings", ""] + [f"- **{f['severity'].upper()}** {f['finding']}" for f in rb["recoveryGroupFindings"]] + [""]
    if rb["blastRadius"]["gaps"]:
        L += ["## Gaps", ""] + [f"- **{g['severity'].upper()}** {g['resource']}: {g['finding']}" for g in rb["blastRadius"]["gaps"]] + [""]
    for ph in rb["phases"]:
        L += [f"## {ph['title']}", ""]
        for s in ph["steps"]:
            tag = "AUTO (Commvault)" if s["automatable"] else f"MANUAL ({s['actor']})"
            L.append(f"{s['step']}. **{s['title']}** - _{tag}_  ")
            L.append(f"   {s['detail']}")
        L.append("")
    L += ["## Blast radius", "", rb["blastRadius"]["summary"], ""]
    L += [f"- `{a['id']}` ({a['type']}): {a['attackPath']}" for a in rb["blastRadius"]["affectedNodes"][:50]]
    L += ["", f"_{rb['blastRadius']['note']}_"]
    return "\n".join(L)
