# --------------------------------------------------------------------------
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# See http://www.apache.org/licenses/LICENSE-2.0
# --------------------------------------------------------------------------
"""
Phase 2: turn a scenario runbook into a Commvault Cleanroom recovery group.

  runbook (read-only plan)  ->  desired recovery group  ->  preview + diff vs an existing group  ->  [approval]  ->  create

Rules:
  * CREATE a NEW group (e.g. IR-identity-compromise-2026-10-20). Existing groups are never modified.
  * Only machines Cleanroom can recover go in: protected, with a VM-level (Virtual Server) backup, and an action of
    "restore". Everything else stays a step in the runbook, with the reason.
  * Every member gets a SPECIFIC pre-cutoff recovery point (never LATEST) when the playbook requires it.
  * Create only. Launching a Cleanroom recovery stays a human action in Command Center.
  * The request payload is built in ONE function (build_create_payload) so the shape captured from Command Center
    11.46 can replace the documented shape without touching anything else.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

RESTORE_ACTIONS = {"restore_pre_cutoff", "restore_clean_latest"}
FILES_WORKLOAD = 9      # RecoveryGroup entity "workload": 8 = virtual machine, 9 = file system (11.46 lab)
VM_AGENT = "virtual server"


def _epoch(iso_s: Optional[str]) -> Optional[int]:
    if not iso_s:
        return None
    return int(datetime.fromisoformat(iso_s.replace("Z", "+00:00")).timestamp())


def eligibility(member: Dict[str, Any], cleanroom_supported: Optional[Dict[str, str]] = None) -> Tuple[bool, str]:
    if member["action"] not in RESTORE_ACTIONS:
        return False, f"runbook action is '{member['action']}', not a restore"
    if member.get("protectionUnknown"):
        return False, "protection could not be confirmed from the API"
    if not member.get("protected"):
        return False, "not protected by Commvault"
    if cleanroom_supported is not None:   # authoritative: the list Command Center's wizard offers
        if str(member.get("clientId")) in cleanroom_supported:
            return True, "offered for Cleanroom by Command Center"
        return False, "Command Center does not offer this server for Cleanroom recovery; keep it as a runbook restore step"
    has_vm_backup = any(str(sc.get("appName") or "").lower() == VM_AGENT for sc in member.get("subclients", []))
    if not has_vm_backup:
        apps = ", ".join(a for a in member.get("applications", []) if a.lower() != VM_AGENT) or "application"
        return False, f"no VM-level backup (protected at {apps} level); restore it with an application restore step"
    return True, "VM-level backup available"


def default_group_name(scenario_id: str, when: Optional[datetime] = None) -> str:
    when = when or datetime.now(timezone.utc)
    return f"IR-{scenario_id.replace('+', '-').replace('_', '-')}-{when:%Y%m%d-%H%M}"


def desired_group(runbook: Dict[str, Any], base_group: Optional[Dict[str, Any]], name: str = "",
                  cleanroom_supported: Optional[Dict[str, str]] = None) -> Dict[str, Any]:
    policy = runbook["scenario"]["recoveryPointPolicy"]
    members, excluded = [], []
    for m in runbook.get("recoveryPlan", []):
        ok, why = eligibility(m, cleanroom_supported)
        if not ok:
            excluded.append({"name": m["name"], "reason": why, "runbookPriority": m["priority"]})
            continue
        cp = m.get("cleanPoint")
        point = ({"category": "POINT_IN_TIME", "jobId": cp["jobId"], "time": _epoch(cp["completed"]), "iso": cp["completed"]}
                 if cp and policy == "before_cutoff" else
                 {"category": "LATEST_CLEAN_REQUIRES_THREAT_SCAN" if policy == "clean_latest" else "MISSING"})
        if policy == "before_cutoff" and not cp:
            excluded.append({"name": m["name"], "reason": "no clean recovery point before the cutoff",
                             "runbookPriority": m["priority"]})
            continue
        vm_groups = [sc.get("name") for sc in m.get("subclients", []) if str(sc.get("appName") or "").lower() == VM_AGENT]
        members.append({"name": m["name"], "clientId": m.get("clientId"), "tier": m["tier"],
                        "runbookPriority": m["priority"], "recoveryPoint": point, "vmGroups": vm_groups,
                        "vmLevel": bool(vm_groups), "applications": list(m.get("applications") or [])})
    # Re-number priorities densely over the eligible members, keeping the runbook order.
    rank = {p: i + 1 for i, p in enumerate(sorted({m["runbookPriority"] for m in members}))}
    for m in members:
        m["priority"] = rank[m["runbookPriority"]]
    target = ({"id": base_group.get("targetId"), "name": base_group.get("target")} if base_group else None)
    group = {
        "name": name or default_group_name(runbook["scenario"]["id"]),
        "basedOn": base_group.get("name") if base_group else None,
        "target": target,
        "delayBetweenPriorityMachinesMinutes": (base_group or {}).get("delayBetweenPrioritiesMinutes") or 10,
        "recoveryPoint": ({"category": "POINT_IN_TIME", "cutoff": runbook.get("cleanCutoff")}
                          if policy == "before_cutoff" else {"category": "LATEST", "note": "Threat Scan must confirm clean"}),
        # Threat Scan needs auto-scaled (create-new) cleanroom infrastructure, which conflicts with VMs restored into
        # existing (custom) infrastructure (11.46 lab, 2026-10-21). Only the clean_latest policy depends on it; with
        # pre-cutoff points it is off here and stays a manual validation step in the runbook.
        "enableThreatScan": policy == "clean_latest",
        "members": sorted(members, key=lambda m: (m["priority"], m["name"])),
        "excluded": excluded,
        "scenario": runbook["scenario"]["id"],
        "runbookHash": runbook.get("runbookHash"),
        "warnings": [files_only_warning(m["name"], m.get("applications")) for m in members
                     if m["tier"] == "foundation" and not m["vmLevel"]]
                    + ([THREAT_SCAN_NEEDS_AUTOSCALE] if policy == "clean_latest" else []),
        "eligibilitySource": ("Command Center Cleanroom-supported server list" if cleanroom_supported is not None
                              else "fallback rule: VM-level backup (Cleanroom list unavailable)"),
    }
    group["planHash"] = plan_hash(group)
    return group


THREAT_SCAN_NEEDS_AUTOSCALE = (
    "Threat Scan is required by this playbook (latest point, scan must confirm clean). Commvault runs it only with "
    "auto-scaled cleanroom infrastructure, which needs every entity on create-new recovery options: set that in "
    "the group's Configuration tab, or the members will report not ready.")


def files_only_warning(name: str, applications: Optional[List[str]] = None) -> str:
    apps = [a for a in (applications or []) if a and a.lower() != VM_AGENT]   # VM agent: Cleanroom still offered no VM entity
    has = (f"has {', '.join(apps)} backups but no VM-level backup" if apps else "has no VM-level backup")
    ad = any("active directory" in a.lower() for a in apps)
    return (f"CRITICAL: {name} is the identity foundation and {has}. Cleanroom will restore its files, not a running "
            f"domain controller"
            + (", and an Active Directory backup restores objects into a domain controller that is already running"
               if ad else "")
            + f". Until a DC is up, priorities 2+ may have nothing to authenticate against. Protect {name} at VM level, "
            f"or plan the AD forest recovery (bare-metal or system-state restore of a DC) before priority 2.")


def plan_hash(group: Dict[str, Any]) -> str:
    core = {"name": group["name"], "target": group["target"], "rp": group["recoveryPoint"],
            "members": [(m["name"], m["priority"], m["recoveryPoint"].get("jobId")) for m in group["members"]]}
    return hashlib.sha256(json.dumps(core, sort_keys=True, default=str).encode()).hexdigest()[:16]


def diff_against(group: Dict[str, Any], base: Optional[Dict[str, Any]]) -> List[str]:
    if not base:
        return ["No existing group to compare with."]
    out = []
    base_members = {e["name"].lower(): e for e in base.get("entities", [])}
    new_members = {m["name"].lower(): m for m in group["members"]}
    for k, m in new_members.items():
        if k not in base_members:
            out.append(f"+ {m['name']} added at priority {m['priority']} (not in '{base['name']}')")
        elif base_members[k].get("priority") != m["priority"]:
            out.append(f"~ {m['name']}: priority {base_members[k].get('priority')} in '{base['name']}' -> {m['priority']}")
    for k, e in base_members.items():
        if k not in new_members:
            out.append(f"- {e['name']} is in '{base['name']}' but outside this incident's scope (not included)")
    cat = str(base.get("recoveryPointCategory") or "")
    if cat and cat != group["recoveryPoint"]["category"]:
        out.append(f"~ recovery point: {cat} in '{base['name']}' -> {group['recoveryPoint']['category']}")
    return out


def render_preview(group: Dict[str, Any], diff: List[str]) -> str:
    L = [f"Create Cleanroom recovery group '{group['name']}'?", "",
         f"Target: {(group['target'] or {}).get('name') or 'NOT SET'}"
         + (f"  (copied from '{group['basedOn']}')" if group.get("basedOn") else ""),
         f"Recovery point: {group['recoveryPoint']['category']}"
         + (f" (before {group['recoveryPoint'].get('cutoff')})" if group['recoveryPoint'].get('cutoff') else ""),
         f"Delay between priorities: {group['delayBetweenPriorityMachinesMinutes']} min; Threat Scan: "
         + ("on" if group["enableThreatScan"] else "off (pre-cutoff points; scan stays a manual validation step)"),
         "", "Members:"]
    for m in group["members"]:
        rp = m["recoveryPoint"]
        L.append(f"  P{m['priority']}: {m['name']} [{m['tier']}] - "
                 + (f"point {rp['iso']} (job {rp['jobId']})" if rp.get("jobId") else rp["category"]))
    if group["excluded"]:
        L += ["", "Not included (stay as runbook steps):"] + [f"  {x['name']}: {x['reason']}" for x in group["excluded"]]
    if diff:
        L += ["", "Compared with the existing group:"] + [f"  {d}" for d in diff]
    if group.get("warnings"):
        L += [""] + group["warnings"]
    L += ["", f"Plan fingerprint: {group['planHash']}",
          "Creates a NEW group only. Existing groups are not changed. Nothing is recovered or launched."]
    return "\n".join(L)


def build_create_steps(group: Dict[str, Any]) -> List[Dict[str, Any]]:
    """The write calls, in order, as Command Center 11.46 sends them (captured 2026-10-20):
      1. POST V4/ServerGroup          create a manual server group with the members          -> assemblyId
      2. POST ClientGroup/{assemblyId} mark it as a Cleanroom application (configurationGroupType 2)
      3. POST Cleanroom/Runbook       create the recovery group in the application (target; entities are
                                      filled in by Commvault from the application's members)  -> recoveryGroupId
      4. PUT  RecoveryGroup           read-modify-write the group: POINT_IN_TIME recovery point, Threat Scan,
                                      useAutoScale=false (Commvault turns it on when it adds file-system entities;
                                      mixed with the VMs' existing infrastructure that makes every entity "not ready":
                                      "Recovery and Infrastructure options must be either all create-new or all custom")
      5. PUT  RecoveryGroup/{rg}/Entity/{id}  per entity: its record (minus subEntities) with executionOrder.priority
                                      set (Commvault creates every entity at priority 1)
      6. PUT  RecoveryGroup/{rg}/Entity/{id}/SkipRecovery/Enable  (no body) skip a member's file-system entity when
                                      the same member is recovered as a VM (captured 2026-10-21)"""
    ids = [{"id": int(m["clientId"])} for m in group["members"] if str(m.get("clientId") or "").isdigit()]
    rp = group["recoveryPoint"]
    return [
        {"step": 1, "validated": True, "method": "POST", "endpoint": "V4/ServerGroup",
         "body": {"name": group["name"], "serverGroupType": "MANUAL", "manualAssociation": {"associatedservers": ids}}},
        {"step": 2, "validated": True, "method": "POST", "endpoint": "ClientGroup/{assemblyId}",
         "body": {"clientGroupOperationType": "Update", "clientGroupDetail": {"configurationGroupType": 2, "tiPlan": {}}}},
        {"step": 3, "validated": True, "method": "POST", "endpoint": "Cleanroom/Runbook",
         "body": {"name": group["name"], "target": {"entity": {"id": (group["target"] or {}).get("id")}}, "entities": [],
                  "assembly": {"id": "{assemblyId}"},
                  "advancedOptions": {"enableThreatScan": group["enableThreatScan"], "powerOffVMPostValidation": False,
                                      "delayBetweenPriorityMachines": group["delayBetweenPriorityMachinesMinutes"],
                                      "continueOnFailure": False, "postRecoveryActions": [],
                                      "enableWindowsDefenderScan": False,
                                      "recoveryExpirationOptions": {"enableExpirationOption": False, "daysToExpire": 7}}}},
        {"step": 4, "validated": True, "method": "PUT", "endpoint": "RecoveryGroup",
         "body": "read-modify-write of GET RecoveryGroup/{recoveryGroupId}: set recoveryPointDetails "
                 + (f"{{recoveryPoint: {_epoch(rp.get('cutoff'))}, recoveryPointCategory: 'POINT_IN_TIME'}}"
                    if rp["category"] == "POINT_IN_TIME" else "unchanged (LATEST; Threat Scan must confirm clean)")
                 + f", threatScan.enableThreatScan = {group['enableThreatScan']}"
                 + (", useAutoScale = false" if not group["enableThreatScan"] else "")},
        {"step": 5, "validated": True, "method": "PUT", "endpoint": "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}",
         "body": "for each entity Commvault created: its record from GET RecoveryGroup/{recoveryGroupId} without "
                 "subEntities, with executionOrder = {priority: <member priority>}",
         "priorities": {m["name"]: m["priority"] for m in group["members"]}},
        {"step": 6, "validated": True, "method": "PUT",
         "endpoint": "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}/SkipRecovery/Enable",
         "body": None, "when": "a member's file-system entity, if that member also has a VM entity (redundant)"},
    ]


def build_create_payload(group: Dict[str, Any]) -> Dict[str, Any]:
    """Stage 2 body (recovery group in the assembly). UNVALIDATED: documented POST Cleanroom/Runbook shape."""
    return {
        "name": group["name"],
        "target": {"entity": {"id": (group["target"] or {}).get("id"), "name": (group["target"] or {}).get("name")}},
        "entities": [{
            "name": m["name"],
            "entity": {"id": int(m["clientId"]) if str(m.get("clientId") or "").isdigit() else m.get("clientId")},
            "recoveryConfiguration": {
                "executionOrder": {"priority": m["priority"], "order": 0},
                "recoveryPointDetails": (
                    {"entityRecoveryPointCategory": "POINT_IN_TIME", "entityRecoveryPoint": m["recoveryPoint"]["time"]}
                    if m["recoveryPoint"].get("time") else {"entityRecoveryPointCategory": "LATEST"}),
            },
        } for m in group["members"]],
        "advancedOptions": {
            "delayBetweenPriorityMachines": group["delayBetweenPriorityMachinesMinutes"],
            "enableThreatScan": group["enableThreatScan"],
            "continueOnFailure": False,
        },
    }


CREATE_ENDPOINT = ("POST", "Cleanroom/Runbook")
PAYLOAD_VALIDATED = True    # every step in build_create_steps is taken from Command Center 11.46 captures (2026-10-20)


class WriteDisabled(Exception):
    pass


class GuardedWriter:
    """The only component that can write to the CommCell.
    - off unless RECOVERY_WRITE_ENABLED=true
    - its own credential (keyring entry '<service>:write'), never the read-only discovery credential
    - endpoint allowlist: the captured create calls only (no delete, no launch), and only against the ids this
      writer itself created"""

    def __init__(self, base_url: str, token: str, verify: bool = True,
                 allow=(CREATE_ENDPOINT, ("POST", "V4/ServerGroup"), ("POST", "ClientGroup/{assemblyId}"),
                        ("PUT", "RecoveryGroup"), ("GET", "RecoveryGroup/{recoveryGroupId}"),
                        ("PUT", "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}"),
                        ("PUT", "RecoveryGroup/{recoveryGroupId}/Entity/{entityId}/SkipRecovery/Enable"))):
        self.base_url, self.token, self.verify, self.allow = base_url.rstrip("/") + "/", token, verify, set(allow)
        self.calls: List[str] = []

    @classmethod
    def from_environment(cls) -> "GuardedWriter":
        if os.environ.get("RECOVERY_WRITE_ENABLED", "false").strip().lower() != "true":
            raise WriteDisabled("Writes are disabled. An administrator must set RECOVERY_WRITE_ENABLED=true.")
        if not PAYLOAD_VALIDATED and os.environ.get("RECOVERY_ALLOW_UNVALIDATED_PAYLOAD", "false").lower() != "true":
            raise WriteDisabled("The create request has not been validated against this Commvault version yet "
                                "(capture pending). Refusing to write.")
        import keyring
        from src.utils import get_env_var, get_keyring_service_name
        token = keyring.get_password(get_keyring_service_name() + ":write", "access_token")
        if not token:
            raise WriteDisabled("No write credential stored. Run: uv run lab\\setup_write_token.py")
        server = get_env_var("CC_SERVER_URL")
        base = server.rstrip("/") + "/commandcenter/api/"
        return cls(base, token, get_env_var("SSL_VERIFY", default="true").lower() == "true")

    def send(self, method: str, endpoint: str, body: Dict[str, Any], template: Optional[str] = None) -> Dict[str, Any]:
        """template = the allowlisted endpoint pattern (e.g. 'ClientGroup/{assemblyId}') the concrete endpoint came from;
        only an id the writer itself just created may be filled into it."""
        key = (method.upper(), template or endpoint)
        if key not in self.allow:
            raise WriteDisabled(f"{method} {endpoint} is not on the write allowlist.")
        if template:
            filled = (template.replace("{assemblyId}", str(getattr(self, "_created_assembly", "?")))
                              .replace("{recoveryGroupId}", str(getattr(self, "_created_rg", "?"))))
            if "{entityId}" in filled:
                mm = re.search(r"/Entity/(\d+)", endpoint)
                eid = mm.group(1) if mm else "?"
                if eid not in {str(x) for x in getattr(self, "_known_entities", set())}:
                    raise WriteDisabled(f"Entity {eid} is not an entity of the recovery group this writer just created.")
                filled = filled.replace("{entityId}", eid)
            if filled != endpoint:
                raise WriteDisabled(f"{endpoint} does not target the group this writer just created.")
        if (method.upper(), endpoint) == ("PUT", "RecoveryGroup") and str((body or {}).get("id")) != str(getattr(self, "_created_rg", "?")):
            raise WriteDisabled("PUT RecoveryGroup may only update the recovery group this writer just created.")
        import requests
        self.calls.append(f"{method} {endpoint}")
        def call(auth_header):
            return requests.request(method.upper(), self.base_url + endpoint, json=body if method.upper() != "GET" else None,
                                    params={"getEntityDetails": "true", "getGroupDetails": "true"} if method.upper() == "GET" else None,
                                    verify=self.verify, timeout=120,
                                    headers={"Accept": "application/json", "Content-Type": "application/json", **auth_header})
        r = call({"Authorization": self.token if self.token.startswith("Bearer ") else f"Bearer {self.token}"})
        if r.status_code == 401:                          # same fallback as the stock cv_api_client
            r = call({"Authtoken": self.token})
        r.raise_for_status()
        data = r.json()
        if endpoint == "V4/ServerGroup":
            self._created_assembly = (data.get("serverGroupInfo") or {}).get("id")
        if endpoint == "Cleanroom/Runbook":
            self._created_rg = (data.get("recoveryGroup") or {}).get("id")
        return data


def entity_label(e: Dict[str, Any], all_entities: List[Dict[str, Any]]) -> str:
    """Entity names are not unique: Commvault names every file-system entity 'default'. Qualify with the server."""
    name = e.get("name") or str(e.get("id"))
    if sum(1 for x in all_entities if x.get("name") == name) > 1:
        return f"{name} ({(e.get('client') or {}).get('name') or e.get('id')})"
    return name


def run_create(writer: "GuardedWriter", group: Dict[str, Any]) -> Dict[str, Any]:
    """Execute the validated steps in order. Stops at the first failure and reports exactly what exists."""
    done, assembly_id, rg_id = [], None, None
    steps = {s["step"]: s for s in build_create_steps(group)}
    # 1. server group
    resp = writer.send("POST", "V4/ServerGroup", steps[1]["body"])
    assembly_id = (resp.get("serverGroupInfo") or {}).get("id")
    if not assembly_id:
        return {"status": "FAILED", "step": 1, "response": resp, "created": done}
    writer._created_assembly = assembly_id
    done.append(f"application (server group) '{group['name']}' id {assembly_id}")
    # 2. mark as Cleanroom application
    resp = writer.send("POST", f"ClientGroup/{assembly_id}", steps[2]["body"], template="ClientGroup/{assemblyId}")
    if (resp.get("errorCode") or 0) != 0:
        return {"status": "PARTIAL", "step": 2, "response": resp, "created": done}
    done.append("marked as Cleanroom application (configurationGroupType 2)")
    # 3. recovery group inside the application
    body3 = json.loads(json.dumps(steps[3]["body"]))
    body3["assembly"]["id"] = assembly_id
    parsed = parse_create_response(writer.send("POST", "Cleanroom/Runbook", body3))
    if parsed["status"] != "CREATED":
        return {"status": "PARTIAL", "step": 3, "response": parsed, "created": done}
    rg_id = parsed["recoveryGroupId"]
    writer._created_rg = rg_id
    done.append(f"recovery group '{group['name']}' id {rg_id} (entities filled in by Commvault)")
    # 4. recovery point + Threat Scan (read-modify-write of the group just created)
    current = writer.send("GET", f"RecoveryGroup/{rg_id}", None, template="RecoveryGroup/{recoveryGroupId}")
    rgobj = dict(current.get("recoveryGroup") or {})
    rp = group["recoveryPoint"]
    if rp["category"] == "POINT_IN_TIME" and rp.get("cutoff"):
        rgobj["recoveryPointDetails"] = {"recoveryPoint": _epoch(rp["cutoff"]), "recoveryPointCategory": "POINT_IN_TIME"}
    rgobj["threatScan"] = {**(rgobj.get("threatScan") or {}), "enableThreatScan": bool(group["enableThreatScan"])}
    if not group["enableThreatScan"]:
        rgobj["useAutoScale"] = False  # keep infrastructure "custom" like the VMs (see build_create_steps step 4)
    rgobj["id"] = rg_id
    resp = writer.send("PUT", "RecoveryGroup", rgobj)
    if (resp.get("error") or {}).get("errorCode"):
        return {"status": "PARTIAL", "step": 4, "response": resp, "created": done}
    done.append(("recovery point set to POINT_IN_TIME before the cutoff" if rp["category"] == "POINT_IN_TIME"
                  else "recovery point LATEST")
                 + ("; Threat Scan on (auto-scale left as Commvault set it)" if group["enableThreatScan"]
                    else "; Threat Scan off; auto-scale off"))
    # 5. priorities per entity (Commvault created them all at priority 1)
    def member_for(e):
        eid, cname, ename = str((e.get("entity") or {}).get("id")), (e.get("client") or {}).get("name"), e.get("name")
        for m in group["members"]:
            if eid == str(m.get("clientId")) or ename == m["name"] or cname == m["name"]:
                return m
        return None
    entities = current.get("entities", []) or []
    writer._known_entities = {e.get("id") for e in entities if e.get("id") is not None}
    set_prio, unmatched = [], []
    for e in entities:
        m = member_for(e)
        if not m:
            unmatched.append(e.get("name"))
            continue
        if (e.get("executionOrder") or {}).get("priority") == m["priority"]:
            set_prio.append(f"{entity_label(e, entities)}=P{m['priority']} (already)")
            continue
        body = {k: v for k, v in e.items() if k != "subEntities"}
        body["executionOrder"] = {"priority": m["priority"]}
        resp = writer.send("PUT", f"RecoveryGroup/{rg_id}/Entity/{e['id']}", body,
                           template="RecoveryGroup/{recoveryGroupId}/Entity/{entityId}")
        if (resp.get("errorCode") or 0) != 0:
            return {"status": "PARTIAL", "step": 5, "entity": e.get("name"), "response": resp, "created": done + set_prio}
        set_prio.append(f"{entity_label(e, entities)}=P{m['priority']}")
    done.append("priorities: " + ", ".join(set_prio))
    # 6. skip redundant file-system entities (member also recovered as a VM). After step 5: a priority PUT carries
    #    skipRecovery from the earlier read and would undo a skip.
    def is_files(e):
        return e.get("workload") == FILES_WORKLOAD or ("virtualMachine" not in e and e.get("name") == "default")
    vm_members = {member_for(e)["name"] for e in entities if not is_files(e) and member_for(e)}
    skipped, files_only = [], []
    for e in entities:
        m = member_for(e)
        if not m or not is_files(e) or e.get("skipRecovery"):
            continue
        if m["name"] in vm_members:
            resp = writer.send("PUT", f"RecoveryGroup/{rg_id}/Entity/{e['id']}/SkipRecovery/Enable", None,
                               template="RecoveryGroup/{recoveryGroupId}/Entity/{entityId}/SkipRecovery/Enable")
            if (resp.get("errorCode") or 0) != 0:
                return {"status": "PARTIAL", "step": 6, "entity": entity_label(e, entities), "response": resp,
                        "created": done}
            skipped.append(entity_label(e, entities))
        elif m["name"] not in files_only:
            files_only.append(m["name"])
    if skipped:
        done.append("skipped file-system steps already covered by the VM restore: " + ", ".join(skipped))
    # verify by reading the group back
    final = writer.send("GET", f"RecoveryGroup/{rg_id}", None, template="RecoveryGroup/{recoveryGroupId}")
    fents = final.get("entities", []) or []
    got, readiness, mismatches = {}, {}, []
    for e in fents:
        label = entity_label(e, fents)
        got[label] = (e.get("executionOrder") or {}).get("priority")
        if (e.get("restoreEligibility") or {}).get("isEligible") is False:
            readiness[label] = (e.get("restoreEligibility") or {}).get("ineligibleReason")
        m = member_for(e)
        if m and got[label] != m["priority"]:
            mismatches.append(label)
    return {"status": "CREATED" if not mismatches else "CREATED_WITH_MISMATCHES",
            "assemblyId": assembly_id, "recoveryGroupId": rg_id, "created": done,
            "verifiedPriorities": got, "priorityMismatches": mismatches, "unmatchedEntities": unmatched,
            "commvaultReadiness": readiness or "all entities report ready",
            "skippedEntities": skipped, "recoveredAsFilesOnly": files_only,
            "autoScale": (final.get("recoveryGroup") or {}).get("useAutoScale"),
            "warnings": [files_only_warning(m["name"], m.get("applications")) for m in group["members"]
                         if m["name"] in files_only and m["tier"] == "foundation"]
                        + ([THREAT_SCAN_NEEDS_AUTOSCALE] if group["enableThreatScan"] else [])}


def parse_create_response(resp: Dict[str, Any]) -> Dict[str, Any]:
    err = resp.get("error") or {}
    if err.get("errorCode"):
        return {"status": "FAILED", "errorCode": err.get("errorCode"), "errorMessage": err.get("errorMessage")}
    rg = resp.get("recoveryGroup") or {}
    return {"status": "CREATED", "recoveryGroupId": rg.get("id"), "name": rg.get("name")}
