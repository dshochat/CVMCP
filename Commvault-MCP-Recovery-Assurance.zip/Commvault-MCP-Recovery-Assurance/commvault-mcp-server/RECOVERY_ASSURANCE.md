# Recovery Assurance tools for Commvault MCP

> "Your backup succeeded" is not the question. **Does your recovery plan still represent your production application — and will it come back in the right order?**

Five MCP tools added to the Commvault MCP Server. All are **read-only against the CommCell**.

| Tool | What it does | Writes |
|---|---|---|
| `discover_recovery_application` | From **one owner-supplied seed** (e.g. `TRADING-WEB-01`), builds an evidence-based recovery map: apps/instances/databases, plans, copies, latest recovery points, *candidate* sibling resources, recoverability gaps, and what Commvault **cannot** see. | nothing |
| `generate_recovery_sequence` | **Zero-input recovery order** from technology: foundation → data → middleware → application → presentation. Maps to Cleanroom priorities (1 = first), what each resource waits for, readiness gates, and a `planHash` fingerprint. | nothing |
| `approve_recovery_map` | Re-runs discovery + sequencing on the server, refuses if the plan no longer matches `planHash`, then **asks the human directly** (MCP elicitation). The AI cannot approve. | local JSON baseline only |
| `detect_recovery_drift` | Compares production now with the approved definition: new unreviewed resources **and where they'd fall in the recovery order**, members lost/unprotected, technology changes, dropped databases, plan changes, lost secondary/immutable/air-gapped copies, RPO breaches. | nothing |
| `audit_recovery_order` | **Zero-input audit of an existing Cleanroom recovery group**: classifies each member and flags e.g. web/app servers recovering before their database. Useful on day one. | nothing |

## Design rules

- **No AI guessing.** Every relationship and classification carries `evidence` + `confidence` (`confirmed` / `high` / `medium` / `low`). No made-up percentages.
- **Technology from Commvault, not from names, where possible.** A discovered SQL/Oracle/DB2/PostgreSQL/… agent = data tier, `confirmed`. Hostname conventions (`web`, `api`, `kafka`) = `medium`, flagged for confirmation. Nothing recognisable = application tier, `low`. A database agent beats a misleading hostname.
- **Human input only for exceptions:** `tier_overrides` (`{"LIC-01": "foundation"}`) and `ordering_exceptions` (`"LIC-01 before ORA-01"`). Cycles are rejected.
- **AD/DNS are shared cleanroom prerequisites**, not members of every app's group (unless discovered inside the app).
- **Readiness gates** (DB ONLINE + `SELECT 1`, `/health` = 200, …) are generated as recommendations; executing them belongs to `prove_recoverability`.
- **Blind spots are reported**, not hidden.

## How approval is enforced

A parameter like `approved=true` is not a guardrail — the AI fills every parameter. Instead:

1. **Plan fingerprint.** `approve_recovery_map` must receive the `planHash` the user saw; the server recomputes it from live data and refuses (`PLAN_CHANGED`) if anything differs.
2. **Server-initiated confirmation (MCP elicitation).** The server sends the full plan text to the MCP client, which shows it to the human; the human types their name and accepts. The AI never sees or answers this dialog. Supports both protocol styles:
   - MCP ≤ 2025-11-25 (FastMCP 3.x, the version locked in `uv.lock`): `ctx.elicit()`.
   - MCP 2026-07-28 (FastMCP 4.x): guard pattern — `InputRequiredResult`, with the plan fingerprint carried in framework-sealed `request_state`.
3. **Fail closed.** If the client can't show the dialog, nothing is saved. An administrator can set `RECOVERY_APPROVAL_MODE=host` to rely on the host's per-tool "always ask" setting instead (weaker; documented as such).
4. **Recommended for production:** discovery runs on a read-only Commvault service account; any future write tool (creating a recovery group) uses a separate credential.

## Layout

```
src/recovery/cv_reader.py     # ONLY place that parses Commvault responses (LAB-VALIDATE markers)
src/recovery/discovery.py     # seed -> evidence graph -> gaps
src/recovery/sequencing.py    # technology classification, recovery DAG, priorities, audit
src/recovery/baseline.py      # propose / approve / drift / audit orchestration
src/recovery/simulator.py     # simulated CommCell ("TradingDemo") for tests and demo
src/tools/recovery_tools.py   # the 5 MCP tools, registered in src/tools/__init__.py
tests_recovery/               # 40 offline tests (pass on FastMCP 3.2.4 and 4.1.1)
demo/run_demo.py              # terminal walkthrough
demo/sim_server.py            # MCP server on the simulator (Claude Desktop demo)
```

## Run it today (no lab needed)

```powershell
cd "C:\WEB\CV MCP"
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -e .            # or: uv sync
pytest tests_recovery
python demo\run_demo.py
```

### Claude Desktop demo
Add to `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "commvault-recovery-sim": {
      "command": "C:\\WEB\\CV MCP\\.venv\\Scripts\\python.exe",
      "args": ["C:\\WEB\\CV MCP\\demo\\sim_server.py"]
    }
  }
}
```

Restart Claude Desktop, then try:
1. *"Our application TradingDemo runs on TRADING-WEB-01. Build its recovery map."*
2. *"SQL-01 and API-01 are ours, reporting-01 isn't. What's the recovery order?"*
3. *"Looks right, approve it."* → a confirmation dialog appears for **you**.
4. *"Audit the TradingDemo-Cleanroom recovery group."*
5. *"Simulate six months of production change."* → *"Is the TradingDemo recovery plan still accurate?"*
6. `reset_simulation` to run it again.

If your client doesn't support confirmation dialogs, step 3 is refused by design. For a demo you can set `"env": {"RECOVERY_APPROVAL_MODE": "host"}` in the config above.

## Against a real CommCell (Checkpoint B)

The tools are registered in the main server, so the normal setup applies (`CC_SERVER_URL`, tokens in keyring, `python -m src.server`). Optional env: `RECOVERY_BASELINE_DIR` (default `./recovery_baselines`), `RECOVERY_APPROVAL_MODE`.

Endpoints used (all GET) — each needs confirmation on 11.46:

| Purpose | Endpoint | Field paths to validate |
|---|---|---|
| Resolve seed | `getid?clientname=`, fallback `Client` | `clientId`; `clientProperties[].client.clientEntity` |
| Client + groups | `Client/{id}` | `clientGroups[]`, `clientProps.IsVirtualClient` |
| Applications (tier evidence) | `Agent?clientId=` | `agentProperties[].idaEntity.appName` — exact agent names drive classification |
| Subclients | `subclient?clientId=` | `subClientProperties[].subClientEntity` |
| Plan + databases | `subclient/{id}` | `planEntity`, `content[].mssqlDbContent.databaseName` |
| Copies | `v4/serverplan/{id}` | `backupDestinations[]`: region, storagePool, immutability flag, Air Gap Protect type |
| Recovery points | `Job?clientId=&jobFilter=Backup` | `jobSummary.status/jobEndTime/subclient` |
| Group members | `ClientGroup/{id}` | `clientGroupDetail.associatedClients[]` |
| Recovery groups | `V4/RecoveryGroups`, `V4/RecoveryGroups/{id}?getEntityDetails=true` | **path to confirm**; fields per API docs: `recoveryGroups[]`, `entities[].recoveryConfiguration.executionOrder.priority` |

Any mismatch is a one-file fix in `cv_reader.py`.

## Roadmap
1. ✅ Discovery + approval + drift (Commvault-only evidence)
2. ✅ Technology-aware recovery sequencing, enforced approval, order drift, recovery-group audit
3. Validate on 11.46 lab; add VM provider tags as an evidence signal (improves app-vs-web classification)
4. One external evidence source (ServiceNow CMDB *or* cloud tags)
5. `apply_recovery_plan`: create/update the Cleanroom recovery group with these priorities (first write action; elicitation + separate credential)
6. `find_clean_recovery_point` (Threat Scan) → `prove_recoverability` (Cleanroom + executed readiness gates)
