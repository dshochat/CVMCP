# Recovery Assurance tools for Commvault MCP

> "Your backup succeeded" is not the question. **Does your recovery plan still represent your production application — and will it come back in the right order?**

Nine MCP tools added to the Commvault MCP Server (five for application recovery assurance, four for security-scenario runbooks). All are **read-only against the CommCell**.

| Tool | What it does | Writes |
|---|---|---|
| `discover_recovery_application` | From **one owner-supplied seed** (e.g. `TRADING-WEB-01`), builds an evidence-based recovery map: apps/instances/databases, plans, copies, latest recovery points, *candidate* sibling resources, recoverability gaps, and what Commvault **cannot** see. | nothing |
| `generate_recovery_sequence` | **Zero-input recovery order** from technology: foundation → data → middleware → application → presentation. Maps to Cleanroom priorities (1 = first), what each resource waits for, readiness gates, and a `planHash` fingerprint. | nothing |
| `approve_recovery_map` | Re-runs discovery + sequencing on the server, refuses if the plan no longer matches `planHash`, then **asks the human directly** (MCP elicitation). The AI cannot approve. | local JSON baseline only |
| `detect_recovery_drift` | Compares production now with the approved definition: new unreviewed resources **and where they'd fall in the recovery order**, members lost/unprotected, technology changes, dropped databases, plan changes, lost secondary/immutable/air-gapped copies, RPO breaches. | nothing |
| `audit_recovery_order` | **Zero-input audit of an existing Cleanroom recovery group**: classifies each member and flags e.g. web/app servers recovering before their database. Useful on day one. | nothing |

## Security-scenario runbooks

Four more read-only tools turn a security incident into a recovery runbook.

| Tool | What it does |
|---|---|
| `list_recovery_scenarios` | The scenario catalog: `identity_compromise`, `cloud_iam_compromise`, `ransomware`, `data_tampering`, `malicious_update` |
| `import_security_context` | Deterministic adapters: raw **Cortex** incident (compromised users/hosts, t0, category → scenario) + raw **Wiz** graph (what they can reach) → recovery graph. Reports anything unmapped |
| `assess_blast_radius` | Walks *control* relations from the compromised nodes; returns affected nodes with the attack path as evidence, the Commvault recovery scope with the last clean point before **t0 − dwell time**, identity objects needing credential action, and gaps |
| `build_scenario_runbook` | Accepts raw Cortex/Wiz exports (or a graph). **The recovery playbook is derived from the incident** (e.g. Cortex "Credential Access" → identity playbook); `scenario` is only an override. Chained attacks (e.g. identity → ransomware) merge playbooks: strictest recovery-point rule wins, extra steps added. Phased runbook: contain → trusted recovery plane → clean recovery points → (identity first) → recover by priority with per-resource points and readiness gates → validate → rotate credentials → reconnect. Each step marked **AUTO (Commvault)** or **MANUAL (team)**. Checks an existing recovery group (e.g. flags `LATEST` after an identity compromise). Includes markdown |

### Why the tool owns the playbook

Wiz and Cortex describe the **attack** (who is compromised, since when, what they can reach). They do not describe the **recovery**: which recovery point is safe, restore vs rebuild, identity first, data out of place, what Commvault can automate. That is the playbook layer — selected automatically from the incident, overridable by the analyst.

### How a scenario changes recovery

| Scenario | Recovery point | Per-tier action |
|---|---|---|
| Identity compromise | Before t0 − dwell (never `LATEST`) | Identity first (forest recovery, KRBTGT ×2), then everything pre-cutoff |
| Cloud IAM compromise | Before t0 − dwell | Revoke/hunt persistence first; restore changed resources pre-cutoff; prefer AGP |
| Ransomware | Newest point Threat Scan confirms clean (fallback: pre-cutoff) | Restore all tiers into cleanroom |
| Data tampering | Last point before t0 | Data tier only, **out of place**, then reconcile; nothing else restored |
| Malicious update | Before t0 | **Rebuild** middleware/app/web from known-good images; restore **data only** |

Scenarios are data in `src/recovery/scenarios/*.json` — add or tune them without code changes.

### Graph format (tool-neutral)

```json
{ "compromised": ["user:svc-sql"], "t0": "2026-10-19T02:00:00Z", "dwellTimeHours": 24,
  "nodes": [{"id": "vm:vmwsql1", "type": "server", "commvaultClient": "vmwsql1"}],
  "edges": [{"from": "user:svc-sql", "to": "vm:vmwsql1", "rel": "admin_of"},
            {"from": "vm:vmwlnx1", "to": "vm:vmwsql1", "rel": "depends_on"}] }
```
Control relations (attack paths): `admin_of, member_of, can_assume, authenticates, can_write, can_reset_password, has_credentials_for, generic_all, runs_as, …`. `depends_on` is not an attack path; it becomes a recovery-ordering hint. Blast radius is what the compromised identities *could* control — an intentional over-approximation for recovery scoping.

### Feeding it from Wiz and Palo Alto Cortex

1. **Conversational** — the customer's AI client connects the Wiz MCP, Cortex MCP and Commvault MCP servers; the analyst asks for a runbook for an incident; raw exports are passed to `import_security_context` (no AI translation), then `build_scenario_runbook`.
2. **Adapters** — `src/recovery/adapters/security_sources.py` + editable `mappings.json` (Wiz entity/relationship types, Cortex category → scenario).
3. **Event-driven** — a Cortex XSOAR playbook calls the MCP server (HTTP transport) on qualifying incidents and attaches the runbook to the incident/ticket.

**Adapter field shapes are unvalidated** until checked against real Wiz and Cortex exports (samples in `demo/graphs/`).

Lab: `uv run lab\run_scenario.py --scenario identity_compromise --graph lab\graphs\lab_identity_dc1.json --group "Sample Application 1"`

## Phase 2 — create the recovery group in Commvault

| Tool | What it does | Writes |
|---|---|---|
| `preview_recovery_group` | From the incident runbook: the NEW Cleanroom recovery group it would create — target (copied from an existing group), eligible members with priorities and a **specific pre-cutoff recovery point** each, members left out with the reason, the diff vs the existing group, the exact request body, a `planHash` | nothing |
| `create_recovery_group` | Creates that group | one create call |

Guardrails on `create_recovery_group`:
- **Off by default** — `RECOVERY_WRITE_ENABLED=true` must be set by an administrator.
- **Every write call is taken verbatim from Command Center 11.46 captures** (`PAYLOAD_VALIDATED = True`). On another version, re-capture before enabling writes.
- **Separate write credential** in its own keyring entry (`uv run lab\setup_write_token.py`); discovery keeps the read-only one.
- **Allowlist:** only the create endpoint; update, delete and launch are refused in code.
- **Plan fingerprint + human approval** (same dialog the AI cannot answer), re-computed on the server.
- **Creates a NEW group** (`IR-<playbook>-<date>`); existing groups are never modified. **Nothing is recovered or launched.**
- **Eligibility:** the servers Command Center itself offers for Cleanroom (`v4/Servers?fq=clientProperties.clientProps.isCleanroomSupported:eq:true`, the wizard's own query — on the lab this includes `dc1` with the AD agent and SQL clients, not only VMs), with a "restore" action. Others stay as runbook steps with the reason.
- **How 11.46 creates it (captured from Command Center, 2026-10-20):** stage 1 = `POST V4/ServerGroup` `{name, serverGroupType: MANUAL, manualAssociation.associatedservers:[{id}]}` → assembly id, then `POST ClientGroup/<id>` `{clientGroupOperationType: Update, clientGroupDetail: {configurationGroupType: 2}}` (= Cleanroom application). Then `POST Cleanroom/Runbook` `{name, target:{entity:{id}}, entities:[], assembly:{id}, advancedOptions}` → recovery group id (Commvault fills in one entity per workload of the members, all at priority 1), then `PUT RecoveryGroup` (read-modify-write of the group) with `recoveryPointDetails: {recoveryPoint: <epoch>, recoveryPointCategory: "POINT_IN_TIME"}` (write uses the word; read returns 1). then `PUT RecoveryGroup/<rg>/Entity/<entityId>` per entity (the entity record as read, without `subEntities`, with `executionOrder.priority` set) → `{errorCode: 0}`, then a read-back of the group to verify every priority. Commvault's own readiness per entity (`restoreEligibility`, e.g. "last full backup copy more than 45 days old") is reported, not overridden. The writer may only touch the server group, recovery group and entity ids it just created (allowlist + id binding).

Lab: `uv run lab\preview_group.py --scenario identity_compromise --graph lab\graphs\lab_identity_dc1.json --base "Sample Application 1"`

## Design rules

- **No AI guessing.** Every relationship and classification carries `evidence` + `confidence` (`confirmed` / `high` / `medium` / `low`). No made-up percentages.
- **Technology from Commvault, not from names, where possible.** A discovered SQL/Oracle/DB2/PostgreSQL/… agent = data tier, `confirmed`. Hostname conventions (`web`, `api`, `kafka`) = `medium`, flagged for confirmation. Nothing recognisable = application tier, `low`. A database agent beats a misleading hostname.
- **Human input only for exceptions:** `tier_overrides` (`{"LIC-01": "foundation"}`) and `ordering_exceptions` (`"LIC-01 before ORA-01"`). Cycles are rejected.
- **AD/DNS are shared cleanroom prerequisites**, not members of every app's group (unless discovered inside the app).
- **Readiness gates** (DB ONLINE + `SELECT 1`, `/health` = 200, …) are generated as recommendations; executing them belongs to `prove_recoverability`.
- **Blind spots are reported**, not hidden.

## How approval is enforced

A parameter like `approved=true` is not a guardrail — the AI fills every parameter. Instead:

1. **Plan fingerprint.** `approve_recovery_map` must receive the `planHash` the user saw; the server recomputes it from live data and refuses (`PLAN_CHANGED`) if anything differs.
2. **Server-initiated confirmation (MCP elicitation).** The server sends the full plan text to the MCP client, which shows it to the human; the human types their name and accepts. The AI never sees or answers this dialog. Supports both protocol styles:
   - MCP ≤ 2025-11-25 (FastMCP 3.x, the version locked in `uv.lock`): `ctx.elicit()`.
   - MCP 2026-07-28 (FastMCP 4.x): guard pattern — `InputRequiredResult`, with the plan fingerprint carried in framework-sealed `request_state`.
3. **Fail closed.** If the client can't show the dialog, nothing is saved. An administrator can set `RECOVERY_APPROVAL_MODE=host` to rely on the host's per-tool "always ask" setting instead (weaker; documented as such).
4. **Recommended for production:** discovery runs on a read-only Commvault service account; any future write tool (creating a recovery group) uses a separate credential.

## Layout

```
src/recovery/cv_reader.py     # ONLY place that parses Commvault responses (LAB-VALIDATE markers)
src/recovery/discovery.py     # seed -> evidence graph -> gaps
src/recovery/sequencing.py    # technology classification, recovery DAG, priorities, audit
src/recovery/baseline.py      # propose / approve / drift / audit orchestration
src/recovery/simulator.py     # simulated CommCell ("TradingDemo") for tests and demo
src/recovery/blast_radius.py  # graph -> blast radius -> Commvault scope + clean points
src/recovery/runbook.py       # scenario catalog + runbook builder (+ markdown)
src/recovery/scenarios/       # scenario catalog (JSON, editable)
src/recovery/adapters/        # Wiz / Cortex adapters + mappings.json
src/recovery/apply.py         # Phase 2: desired group, eligibility, diff, guarded writer
src/tools/recovery_tools.py   # the 11 MCP tools, registered in src/tools/__init__.py
tests_recovery/               # 103 offline tests (pass on FastMCP 3.2.4 and 4.1.1)
demo/run_demo.py              # terminal walkthrough
demo/sim_server.py            # MCP server on the simulator (Claude Desktop demo)
```

## Run it today (no lab needed)

```powershell
cd "C:\WEB\CV MCP"
py -3.11 -m venv .venv
.venv\Scripts\activate
pip install -e .            # or: uv sync
pytest tests_recovery
python demo\run_demo.py
```

### Claude Desktop demo
Add to `%APPDATA%\Claude\claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "commvault-recovery-sim": {
      "command": "C:\\WEB\\CV MCP\\.venv\\Scripts\\python.exe",
      "args": ["C:\\WEB\\CV MCP\\demo\\sim_server.py"]
    }
  }
}
```

Restart Claude Desktop, then try:
1. *"Our application TradingDemo runs on TRADING-WEB-01. Build its recovery map."*
2. *"SQL-01 and API-01 are ours, reporting-01 isn't. What's the recovery order?"*
3. *"Looks right, approve it."* → a confirmation dialog appears for **you**.
4. *"Audit the TradingDemo-Cleanroom recovery group."*
5. *"Simulate six months of production change."* → *"Is the TradingDemo recovery plan still accurate?"*
6. `reset_simulation` to run it again.

If your client doesn't support confirmation dialogs, step 3 is refused by design. For a demo you can set `"env": {"RECOVERY_APPROVAL_MODE": "host"}` in the config above.

## Against a real CommCell (Checkpoint B)

The tools are registered in the main server, so the normal setup applies (`CC_SERVER_URL`, tokens in keyring, `python -m src.server`). Optional env: `RECOVERY_BASELINE_DIR` (default `./recovery_baselines`), `RECOVERY_APPROVAL_MODE`.

Endpoints used (all GET) — each needs confirmation on 11.46:

| Purpose | Endpoint | Field paths to validate |
|---|---|---|
| Resolve seed | `getid?clientname=`, fallback `Client` | `clientId`; `clientProperties[].client.clientEntity` |
| Client + groups | `Client/{id}` | `clientGroups[]`, `clientProps.IsVirtualClient` |
| Applications (tier evidence) | `Agent?clientId=` | `agentProperties[].idaEntity.appName` — exact agent names drive classification |
| Subclients | `subclient?clientId=` | `subClientProperties[].subClientEntity` |
| Plan + databases | `subclient/{id}` | `planEntity`, `content[].mssqlDbContent.databaseName` |
| Copies | `v4/serverplan/{id}` | `backupDestinations[]`: region, storagePool, immutability flag, Air Gap Protect type |
| Recovery points | `Job?clientId=&jobFilter=Backup` | `jobSummary.status/jobEndTime/subclient` |
| Group members | `ClientGroup/{id}` | `clientGroupDetail.associatedClients[]` |
| Recovery groups | `Security/Assembly` → `RecoveryGroups?assemblyId=` → `RecoveryGroup/{id}?getEntityDetails=true` | **Confirmed on 11.46.** Priority `entities[].executionOrder.priority`; `recoveryPointCategory` numeric (0 = LATEST); `RecoveryGroups/{id}` and `V4/…` return 403 |

Any mismatch is a one-file fix in `cv_reader.py`.

## Roadmap
1. ✅ Discovery + approval + drift (Commvault-only evidence)
2. ✅ Technology-aware recovery sequencing, enforced approval, order drift, recovery-group audit
3. Validate on 11.46 lab; add VM provider tags as an evidence signal (improves app-vs-web classification)
4. One external evidence source (ServiceNow CMDB *or* cloud tags)
5. ✅ Security-scenario runbooks: blast radius from a graph, 5 scenarios, Wiz/Cortex adapters (shapes to validate)
6. `apply_recovery_plan`: create/update the Cleanroom recovery group with these priorities (first write action; elicitation + separate credential)
7. `find_clean_recovery_point` (Threat Scan) → `prove_recoverability` (Cleanroom + executed readiness gates)

## Lab validation log

**2026-10-20 — Commvault 11.46 lab (`demolabcs1`), seed `vmwsql1` (VMware VM, SQL Server), 81 GET calls, all HTTP 200.**

Confirmed working as modeled: seed resolution (`getid`), VM detection (`vmStatusInfo`), agents (`idaEntity.appName`), subclients, `planEntity`, SQL database content (`mssqlDbContent.databaseName`), jobs (`jobSummary`), client-group members, `v4/serverplan` copies.

Found and fixed:
| Finding on real data | Fix |
|---|---|
| Hypervisor group `ESX1` (all VMs on one host) produced 3 false candidates | Infrastructure-named plain groups, configuration groups and smart groups are no longer application evidence (reported in `notes`) |
| `configurationGroupType: 2` + `isRGMigrated: true` marks an assembly created from a recovery group | Treated as strong application evidence → `high` on its own |
| Air Gap Protect copy missed (`deviceType: METALLIC_RECOVERY_RESERVE_AZURE_HOT`, `storageType: CLOUD`) | Air gap detected from device type / destination name |
| `wormStoragePoolFlag` is a bitmask (96 vs 225); any non-zero was read as immutable | Immutability from `complianceLock` → `dataRetentionLockDays` → WORM bit 0 (bit meaning still to confirm) |
| On-prem pools have an empty region → on-prem + Azure looked like "one region" | Empty region = `on-premises` |
| Snapshot copy counted as an independent copy | `isSnapCopy` / `SNAPSHOT_PRIMARY` excluded from copy counts |
| `master/model/msdb` listed as application databases | System databases hidden from summaries |
| `V4/RecoveryGroups` returns `200 {}`; Command Center actually uses `Security/Assembly` → `RecoveryGroups?assemblyId=<id>` (assembly id = client group id) | Recovery groups resolved through that chain; members fall back to the assembly's client group. **Entity-priority detail path still to confirm** (`RecoveryGroups/<id>?getEntityDetails=true` per API docs) |

**2026-10-20 (later) — rebuilt 11.46 lab, live run.** Discovery fixes confirmed live (only `vmwlnx1`; ESX1 ignored). Recovery-group detail: `RecoveryGroup/<id>?getEntityDetails=true` = 200; `RecoveryGroups/<id>` and `V4/RecoveryGroups/<id>` = 403. `subclient?clientId=` returns **404** for `exchange1`, which **is** protected by an Exchange agent subclient (Basic30Day). A 404 now means "subclient list unavailable", never "unprotected": protection is decided from backup job history (subclients reconstructed from jobs); with no jobs either, the resource is marked "protection unknown — verify" (medium), not "not protected". Any unreadable client becomes a gap instead of stopping the run. Audit no longer reports "compliant" when the API returns members without priorities.

**2026-10-20 (later) — probe of `exchange1` + `RecoveryGroup/3`, replayed through the fixed code:**
- `exchange1` (client 53) carries `clientProps.DAGpseudoClient` → `exchange1_1` (97), the Exchange DAG pseudo-client holding subclient 200 (Exchange Database, Basic30Day, `exchangeDBContent.databaseName`) and its jobs. Protection is now merged from linked clients: `exchange1` = protected, clean point job 18383.
- `RecoveryGroup/<id>`: priority is at `entities[].executionOrder.priority` (not under `recoveryConfiguration` as the API docs say); `recoveryPointCategory` is numeric — `0` = `LATEST` (Command Center's proxy shows the word).
- Real findings on the lab: "Sample Application 1" recovers `LATEST`; `vmwsql1` (database) and `vmwlnx1` (app) are both priority 1 (start in parallel) — the earlier "follows the recommended order" was a false result while priorities were unread.
- `GET Client` omits some VM clients (`vmwlnx1`) that `getid` / `Client/<id>` resolve — name-convention matching can miss VMs.

Result after fixes (replayed from captured responses with `lab/replay.py`): seed `vmwsql1` → one candidate, `vmwlnx1` (high, recovery-group assembly), ESX1 filtered, AGP copy recognised as air-gapped + immutable, real gap: `vmwlnx1` last good backup ~93 h ago.

**2026-10-20 (evening): first live Phase 2 create on 11.46.** `lab/create_group.py` created application `IR-dc1-test` (assembly 28) and recovery group 5 from the `identity_compromise` runbook in 10 allowlisted calls. Result: dc1 P1, vmwsql1 P2, vmwlnx1 + vmwwin1 P3, recovery point POINT_IN_TIME before the cutoff; exchange1 left out because Command Center doesn't offer it for Cleanroom; base group untouched. Fixed afterwards: entity names aren't unique (every file-system entity is called `default`), so the read-back now labels them `default (<server>)`. The earlier `CREATED_WITH_MISMATCHES` was a false alarm. **Open item:** on some entities Commvault reports "mismatch between the type of Recovery and Infrastructure options (all create-new or all custom)". We still need to compare it with a group created in Command Center to find out whether it's the default state of an API-created group or a field the create flow must set.

**2026-10-21: readiness item solved on a rebuilt lab.** The "Recovery and Infrastructure options mismatch" comes from Commvault itself: when it adds file-system entities (servers with a file-system agent) it turns on `useAutoScale` (create-new infrastructure), while the VM entities use existing (custom) infrastructure. Skipping the file entities alone did not clear it (captured); `useAutoScale: false` in the group update did (captured): only real backup-age reasons remained. The create flow now sets `useAutoScale: false` in step 4, and in step 6 skips a member's file-system entity when that member is also restored as a VM (`PUT RecoveryGroup/<rg>/Entity/<id>/SkipRecovery/Enable`, no body, captured). New finding: `dc1` is protected at file level only, so Cleanroom restores its files, not a working domain controller. The preview and the create result now raise a CRITICAL warning for identity/foundation servers that are recoverable as files only.

**2026-10-21: Microsoft ecosystem.** New adapters: `from_defender_incident` (Defender XDR API incident, or Graph `security/incidents?$expand=alerts` with alerts_v2 evidence) takes compromised users/devices, t0 (earliest alert activity) and the playbook (categories + MITRE techniques, e.g. T1003.006 DCSync → identity compromise, T1486 → ransomware). `from_exposure_graph` takes Microsoft Security Exposure Management `ExposureGraphEdges` rows from advanced hunting; logon, credential (`frequently logged in by`, `has credentials of`), role, permission and membership edges are control relationships, and vulnerability edges (`affecting`) are ignored. `lab/defender/blast_radius.kql` exports exactly the edges on paths from the incident's compromised entities. Any mix of Cortex/Defender and Wiz/Exposure Management can be combined. The MCP tools accept `defender_incident` and `exposure_graph`. The formats come from Microsoft's docs; the samples are synthetic until a real tenant export is used.

**2026-10-21 (Claude Code run on the lab):** With auto-scale off, Commvault reported a new readiness reason: "Threat Scan needs auto-scaling". Threat Scan needs create-new (auto-scaled) cleanroom infrastructure, which conflicts with VMs restored into existing infrastructure. Threat Scan is now turned on only for playbooks that depend on it (`clean_latest`, i.e. a latest point that a scan must confirm clean). Those keep Commvault's auto-scale and get a warning to set create-new recovery options; with pre-cutoff points it is off and stays a manual validation step. The dc1 warning now names the backups the server actually has (here Active Directory and File System): an AD agent backup restores objects into a running domain controller and does not rebuild one. Note: with a Defender incident and no dwell time given, the identity playbook's default dwell (168 h) applies, so the clean points are about a week before t0.
