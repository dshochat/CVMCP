COMMVAULT MCP - RECOVERY ASSURANCE EXTENSION (prototype for engineering review)
==============================================================================

What it is
  Five read-only MCP tools for the Commvault MCP Server that answer:
  "Does our recovery plan still represent the production application,
   and will it come back in the right order?"

    discover_recovery_application  - one seed resource -> evidence-based application map + gaps
    generate_recovery_sequence     - recovery order from technology (DB -> middleware -> app -> web), zero input
    approve_recovery_map           - human-confirmed (server-side dialog) recovery definition
    detect_recovery_drift          - what changed since approval, incl. recovery-order drift
    audit_recovery_order           - flags order violations in existing Cleanroom recovery groups

Contents
  commvault-mcp-server\      full repo (upstream 4d182bf) + extension, ready to run
  recovery-assurance.patch   the same changes as a git patch against 4d182bf
  ENGINEERING_GUIDE.md       how to run, tool reference, safety model, limitations, roadmap
  LAB_SETUP.md               step-by-step install + test against a real CommCell (also in commvault-mcp-server\lab)

Try it in 2 minutes (no CommCell needed)
  cd commvault-mcp-server
  py -3.11 -m venv .venv && .venv\Scripts\activate
  pip install -e .
  pytest tests_recovery          (40 passed)
  python demo\run_demo.py

Status
  Runs against a simulated CommCell only. Commvault API field paths still need
  validation on an 11.46 CommCell (see ENGINEERING_GUIDE.md, section 5).

Contact: David - Principal Solutions Engineer
