COMMVAULT MCP - RECOVERY ASSURANCE EXTENSION (prototype for engineering review)
==============================================================================

What it is
  Nine read-only MCP tools for the Commvault MCP Server that answer:
  "Does our recovery plan still represent the production application,
   and will it come back in the right order?"

    discover_recovery_application  - one seed resource -> evidence-based application map + gaps
    generate_recovery_sequence     - recovery order from technology (DB -> middleware -> app -> web), zero input
    approve_recovery_map           - human-confirmed (server-side dialog) recovery definition
    detect_recovery_drift          - what changed since approval, incl. recovery-order drift
    audit_recovery_order           - flags order violations in existing Cleanroom recovery groups
    import_security_context        - raw Cortex incident + Wiz graph -> recovery graph (deterministic)
    assess_blast_radius            - what the compromised identities can reach -> Commvault scope + clean points
    build_scenario_runbook         - incident -> phased recovery runbook (playbook derived from the incident)
    list_recovery_scenarios        - identity / cloud IAM / ransomware / data tampering / malicious update
    preview_recovery_group         - Phase 2: the NEW Cleanroom recovery group an incident implies (read-only)
    create_recovery_group          - Phase 2: create it (off by default; approval, separate credential, new groups only; sets priorities + clean points, verifies)

Contents
  commvault-mcp-server\      full repo (upstream 4d182bf) + extension, ready to run
  recovery-assurance.patch   the same changes as a git patch against 4d182bf
  ENGINEERING_GUIDE.md       how to run, tool reference, safety model, limitations, roadmap
  LAB_SETUP.md               step-by-step install + test against a real CommCell (also in commvault-mcp-server\lab)

Try it in 2 minutes (no CommCell needed)
  cd commvault-mcp-server
  py -3.11 -m venv .venv && .venv\Scripts\activate
  pip install -e .
  pytest tests_recovery          (71 passed)
  python demo\run_demo.py

Status
  First validation on a Commvault 11.46 lab completed; findings and fixes are in
  commvault-mcp-server\RECOVERY_ASSURANCE.md (Lab validation log).

Contact: David - Principal Solutions Engineer
