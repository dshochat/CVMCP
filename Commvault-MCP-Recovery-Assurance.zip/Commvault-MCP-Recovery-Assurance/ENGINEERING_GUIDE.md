# Recovery Assurance for Commvault MCP — Engineering Guide

**Status:** prototype for engineering review · first lab validation on 11.46 done (see `RECOVERY_ASSURANCE.md` → Lab validation log) · **Author:** David, Principal Solutions Engineer
**Base:** `Commvault/commvault-mcp-server` @ `4d182bf` (2026-06-19) · **Python** 3.11+ · **FastMCP** 3.2.4 (locked) and 4.1.1 tested

---

## 1. The idea in one paragraph

Customers can prove a backup succeeded. They usually can't prove their **recovery plan still matches their production application**, or that it will come back **in the right order**. This extension adds eleven MCP tools (nine read-only to the Commvault MCP Server (five for application recovery assurance, four that turn a security incident into a recovery runbook — section 6b; plus a guarded create for Phase 2 — section 6c):
1. Start from **one** resource the app owner names.
2. Build an evidence-based map of the application.
3. Work out the recovery order from the technology Commvault has already discovered (database → middleware → app → web), with no owner input.
4. Lock in an approved recovery definition. A human must confirm it in a dialog the AI cannot answer.
5. Detect **recovery drift** as production changes, and audit existing Cleanroom recovery groups for order violations.

## 2. What's in this package

```
commvault-mcp-server/          Full repo at 4d182bf + the extension (ready to run)
recovery-assurance.patch       Same changes as a git patch against 4d182bf (2,220 added lines, 1 modified file)
ENGINEERING_GUIDE.md           This document
README_FIRST.txt               One-page orientation
```

The only change to existing upstream code is **3 lines** in `src/tools/__init__.py` to register the new tool category. Everything else is new files:

| Path | Purpose |
|---|---|
| `src/tools/recovery_tools.py` | The 5 MCP tools (upstream conventions: plain functions, `Annotated` params, `ToolError`) |
| `src/recovery/cv_reader.py` | **Only** module that calls/parses the Commvault REST API. GET only. Field paths to verify are marked `LAB-VALIDATE` |
| `src/recovery/discovery.py` | Seed → evidence graph → recoverability gaps |
| `src/recovery/sequencing.py` | Technology classification, recovery DAG, priorities, readiness gates, recovery-group audit |
| `src/recovery/baseline.py` | Propose / approve / drift / audit orchestration; local JSON baselines |
| `src/recovery/simulator.py` | Simulated CommCell (“TradingDemo”) used by tests and the demo. Not used by the production code |
| `tests_recovery/` | 103 offline tests (incl. regressions from the 11.46 lab), no CommCell needed |
| `demo/run_demo.py`, `demo/sim_server.py` | Terminal walkthrough; MCP server on the simulator for Claude Desktop |
| `RECOVERY_ASSURANCE.md` | In-repo reference |

## 3. Quick start (10 minutes, no CommCell)

### Option A — use the included repo
```powershell
cd commvault-mcp-server
py -3.11 -m venv .venv
.venv\Scripts\activate          # Linux/macOS: source .venv/bin/activate
pip install -e .                 # or: uv sync
pytest tests_recovery            # expect: 103 passed
python demo\run_demo.py          # end-to-end story in the terminal
```

### Option B — apply the patch to your own checkout
```bash
git clone https://github.com/Commvault/commvault-mcp-server.git
cd commvault-mcp-server
git checkout 4d182bf
git apply /path/to/recovery-assurance.patch
uv sync && uv run pytest tests_recovery
```

### What the demo shows
1. Owner gives one seed (`TradingDemo` → `TRADING-WEB-01`). Discovery finds SQL-01 and API-01 with high confidence because they share a client group and naming. It finds reporting-01 with low confidence (naming only), and ignores a 40-member “All Production VMs” group as too broad.
2. Recovery order is generated automatically: `P1 SQL-01 (data, confirmed by SQL agent) → P2 API-01 → P3 WEB-01`. The last two are inferred from naming and flagged for confirmation. AD/DNS are listed as a shared cleanroom prerequisite.
3. Approval: the confirmation text the human sees, bound to a plan fingerprint.
4. Audit of the existing `TradingDemo-Cleanroom` group: WEB at priority 1 recovers before SQL and API → violations flagged.
5. Six months later: new API node and Kafka broker, a database dropped from subclient content, stale SQL backups. All are detected, including **“TRADING-API-01 must now wait for TRADING-KAFKA-01”** with a proposed new order.

## 4. Interactive demo in Claude Desktop (or any MCP client)

`%APPDATA%\Claude\claude_desktop_config.json`:
```json
{
  "mcpServers": {
    "commvault-recovery-sim": {
      "command": "C:\\path\\to\\commvault-mcp-server\\.venv\\Scripts\\python.exe",
      "args": ["C:\\path\\to\\commvault-mcp-server\\demo\\sim_server.py"]
    }
  }
}
```
Restart the client, then:
1. “Our application TradingDemo runs on TRADING-WEB-01. Build its recovery map.”
2. “SQL-01 and API-01 are ours, reporting-01 isn't. What's the recovery order?”
3. “Approve it.” → the **server** asks you to confirm in a dialog.
4. “Audit the TradingDemo-Cleanroom recovery group.”
5. “Simulate six months of production change.” → “Is the TradingDemo recovery plan still accurate?”
6. `reset_simulation` to start over.

If the client doesn't support MCP elicitation, approval is refused by design. For a demo only, add `"env": {"RECOVERY_APPROVAL_MODE": "host"}` and set the client to always ask before `approve_recovery_map`.

## 5. Running against a real CommCell

The tools are registered in the main server, so the standard upstream setup applies: run the setup script, put `CC_SERVER_URL` and tokens in the keyring, then `python -m src.server`. Use a **dedicated read-only service account**.

Optional environment variables:

| Variable | Default | Meaning |
|---|---|---|
| `RECOVERY_BASELINE_DIR` | `./recovery_baselines` | Where approved recovery definitions (JSON) are stored |
| `RECOVERY_APPROVAL_MODE` | `elicit` | `elicit` = server-initiated confirmation (fail closed). `host` = rely on the client's per-tool approval (weaker) |

### Endpoints used (all GET) — please validate on 11.46

| Purpose | Endpoint | Fields relied on |
|---|---|---|
| Resolve seed | `getid?clientname=`; fallback `Client` | `clientId`; `clientProperties[].client.clientEntity` |
| Client, groups, VM flag | `Client/{id}` | `clientGroups[]`, `clientProps.IsVirtualClient` |
| Installed applications (tier evidence) | `Agent?clientId=` | `agentProperties[].idaEntity.appName` |
| Subclients | `subclient?clientId=` | `subClientProperties[].subClientEntity` |
| Plan + protected databases | `subclient/{id}` | `planEntity`, `content[].mssqlDbContent.databaseName` (+ Oracle/other DB content keys) |
| Copies | `v4/serverplan/{id}` | `backupDestinations[]`: region, storagePool, immutability flag, storage type (Air Gap Protect) |
| Recovery points | `Job?clientId=&jobFilter=Backup&completedJobLookupTime=` | `jobSummary.status/jobEndTime/subclient` |
| Group membership | `ClientGroup/{id}` | `clientGroupDetail.associatedClients[]` |
| Recovery groups | `Security/Assembly` → `RecoveryGroups?assemblyId=` → `RecoveryGroup/{id}?getEntityDetails=true` | **Confirmed on 11.46** (from Command Center's own calls). Priority at `entities[].executionOrder.priority`; `recoveryPointCategory` numeric, 0 = LATEST. `V4/RecoveryGroups` returns `{}`; `RecoveryGroups/{id}` returns 403 |

All of these paths live in `cv_reader.py`, so any mismatch is a one-file fix. **The most valuable first lab test:** give the tool only `TradingDemo + TRADING-WEB-01` on a small 11.46 CommCell and see how much it discovers on its own.

## 6. Tool reference

### `discover_recovery_application(seed_resource, application_name="", rpo_hours=24)`
Resolves the seed by client name, display name, hostname, short hostname or id. It profiles the seed's agents, subclients, plans, copies and latest good backup. It finds **candidates** using deterministic signals only:
- Shared client group: groups with more than 25 members are ignored as too broad.
- Naming convention: labelled as a heuristic.

Two independent signals → `high`; group only → `medium`; naming only → `low`. Every candidate has `needsOwnerReview: true`.

Returns `resources`, `relationships` (each with `evidence`), `gaps` (no protection, app agent without app-level subclient, RPO breach, single copy, single region, no immutable copy, no air-gapped copy), `unknownOutsideCommvault`, `notes`, `counts`, `nextStep`.

### `generate_recovery_sequence(application_name, seed_resource, include_candidates=[], exclude_candidates=[], tier_overrides={}, ordering_exceptions=[])`
How it decides each tier:
- **Commvault-discovered agent:** `confirmed`. For example, SQL Server, Oracle, DB2, PostgreSQL, MySQL, SAP HANA or MongoDB → data tier; Active Directory → foundation.
- **Hostname convention:** `medium`, flagged for confirmation.
- **Nothing recognisable:** application tier, `low`, flagged.

A database agent beats a misleading hostname. Each resource waits for the nearest lower tier present. Owner exceptions (`"A before B"`) override the tier rule; cycles are rejected.

The DAG is layered into Cleanroom priorities (1 = first), with readiness gates per tier (recommendations only, not executed). Returns `priorities`, `prerequisites`, `classificationsNeedingConfirmation`, `commvaultMapping` (`executionOrder.priority` per entity), and `planHash`.

### `approve_recovery_map(application_name, seed_resource, plan_hash, include_candidates, exclude_candidates, tier_overrides, ordering_exceptions, rpo_hours)`
1. Re-runs discovery and sequencing on the server. The AI's copy of the plan is never trusted.
2. Requires every candidate to be explicitly included or excluded.
3. Refuses with `PLAN_CHANGED` if the result doesn't match `plan_hash`.
4. Asks the **human** to confirm via MCP elicitation. On MCP ≤2025-11-25 this uses `ctx.elicit`. On 2026-07-28 it uses the guard pattern (`InputRequiredResult`), with the fingerprint in framework-sealed `request_state`.
5. On accept, writes the baseline (members, protection snapshot, sequence, approver, method, timestamp).

There is deliberately **no `approved_by` / `approved=true` parameter**: the AI fills every parameter, so such a field proves nothing.

### `detect_recovery_drift(application_name)`
Findings, sorted by severity, each with `impact` and `recommendedAction`:
- `new_unreviewed_resource`: critical if unprotected
- `recovery_order_drift`: where a new resource falls in the order and who must now wait for it, with the proposed new order
- `technology_changed`
- `member_missing`, `membership_signal_lost`, `protection_removed`
- `subclient_removed`, `database_removed`, `database_added`
- `plan_changed`, `copy_removed`, `immutability_lost`, `air_gap_lost`, `region_diversity_lost`
- `rpo_breach`

### `audit_recovery_order(recovery_group_name, application_name="")`
Needs no input beyond the group name. Resolves each group entity to a client, classifies it, and compares the group's current priorities with the recommended order. Flags `order_violation` (dependent tier recovers earlier) and `same_priority` (dependent tier starts in parallel). With an approved definition it also flags `missing_from_group`.

## 6b. Security-scenario runbooks (4 more tools)

`list_recovery_scenarios`, `import_security_context`, `assess_blast_radius`, `build_scenario_runbook`.

- **Input:** raw Palo Alto **Cortex** incident + **Wiz** security-graph export (deterministic adapters, editable `src/recovery/adapters/mappings.json`), or a tool-neutral graph `{compromised, t0, dwellTimeHours, nodes, edges}`.
- **Blast radius:** BFS along control relations (`admin_of`, `member_of`, `can_assume`, `authenticates`, `generic_all`, …) from the compromised nodes; attack path kept as evidence; mapped to Commvault clients; last clean recovery point before **t0 − dwell**; gaps for unprotected/non-Commvault resources and missing clean points. `depends_on` edges become ordering hints.
- **Playbooks** (`src/recovery/scenarios/*.json`): identity compromise, cloud IAM compromise, ransomware, data tampering, malicious update. **Derived automatically from the incident**; `scenario` is only an override; chained attacks merge (strictest recovery-point rule wins).
- **Runbook:** contain → trusted recovery plane → clean points → identity first (where relevant) → recover by priority with per-resource points and readiness gates → validate → rotate credentials → reconnect; every step AUTO (Commvault) or MANUAL (team). Flags an existing recovery group set to `LATEST` after an identity compromise, wrong order, missing members. Markdown output for tickets.
- **Integration patterns:** conversational (Wiz MCP + Cortex MCP + Commvault MCP in one AI client), adapters, or event-driven via a Cortex XSOAR playbook calling the MCP server over HTTP.
- **Status:** engine tested (103 tests). Incident sources: Cortex or **Microsoft Defender XDR** (API incident or Graph alerts_v2 evidence). Reachability: Wiz or **Microsoft Security Exposure Management** (`ExposureGraphEdges` rows from advanced hunting; `lab/defender/blast_radius.kql` exports the paths from the compromised entities). Adapter field shapes follow vendor docs and are **unvalidated** until checked against real exports.

## 6c. Phase 2: creating the recovery group (2 more tools)

`preview_recovery_group` (read-only) shows the NEW Cleanroom recovery group an incident runbook implies: target copied from an existing group, eligible members (protected, VM-level backup, restore action) with priorities and a specific pre-cutoff recovery point each, excluded members with reasons, the diff vs the existing group, the request body and a `planHash`. `create_recovery_group` creates it — off by default (`RECOVERY_WRITE_ENABLED`), separate write credential, endpoint allowlist bound to the ids it just created (no change to existing groups, no delete, no launch), plan-hash binding and human approval. It never modifies existing groups and never launches a recovery. **Status:** eligibility uses Command Center's own Cleanroom-supported server query. Creation stage 1 (application/assembly: `POST V4/ServerGroup`, then `POST ClientGroup/<id>` with `configurationGroupType: 2`) is taken verbatim from a Command Center 11.46 capture; then `POST Cleanroom/Runbook` (recovery group in the application) and `PUT RecoveryGroup` (POINT_IN_TIME recovery point) are also taken from the capture. Per-member priorities are set with `PUT RecoveryGroup/<rg>/Entity/<entityId>` per entity (the entity record as read, without `subEntities`, with `executionOrder.priority` set) → `{errorCode: 0}`, then a read-back of the group to verify every priority. Commvault's own readiness per entity (`restoreEligibility`, e.g. "last full backup copy more than 45 days old") is reported, not overridden. Group update also sets `useAutoScale: false` (otherwise Commvault mixes create-new and custom infrastructure and marks every entity not ready); a member's redundant file-system entity is skipped (`PUT RecoveryGroup/<rg>/Entity/<id>/SkipRecovery/Enable`); identity servers recoverable as files only get a CRITICAL warning. All six write calls are captured from 11.46; re-capture on other versions. Lab script: `lab/create_group.py` (typed-name confirmation).

## 7. Safety model

- **Read-only against the CommCell.** Only `GET` requests, all in `cv_reader.py`. The only write anywhere is the local baseline JSON after human confirmation.
- **Evidence, not inference.** No LLM decides membership, tier or order. All decisions come from deterministic code. Uncertainty is shown, not hidden.
- **Human confirmation enforced by the server**, bound to a plan fingerprint, failing closed. Tests cover accept, decline, a client without dialog support, and an AI retrying without a human answer.
- **Path safety:** application names are slugged before becoming file names. Endpoint paths go through the upstream sanitizer.
- **Recommended:** keep any future write tool (creating/updating recovery groups) behind elicitation **and** a separate, write-capable credential.

## 8. Known limitations (honest list)

1. **One lab validation so far** (11.46, one seed). Core endpoints confirmed; the WORM bit meaning and the non-zero `recoveryPointCategory` values are still unconfirmed. Exchange servers are handled via their DAG pseudo-client; other pseudo-client types (e.g. SQL AG, Oracle RAC) may need the same treatment.
2. **Scale.**
   - The naming heuristic lists all clients and profiles every candidate (about 6 GETs each).
   - There's no paging or candidate cap yet.
   - It needs both before use on large CommCells.
3. **App tier vs. web tier is weak** with Commvault-only evidence: both usually look like File System + Virtual Server. VM provider tags or CMDB data would fix this.
4. **Baselines are local JSON.** Fine for one user, not for a shared multi-tenant deployment. They need proper storage and integrity protection.
5. **Least-privilege role not yet defined** for the read-only service account.
6. **Readiness gates are generated, not executed.**
7. **Commvault-only visibility.** AD, DNS, network, secrets and external services are reported as unknowns, not discovered.

## 9. Extending it

- **More technologies:** add Commvault agent names to `AGENT_TIERS`, and hostname tokens to `NAME_TIERS`, in `sequencing.py`. Exact `appName` strings from a real CommCell are the first thing to confirm.
- **New evidence sources** (VM tags, ServiceNow CMDB, cloud tags): add a signal in `RecoveryDiscovery.discover()` that adds `evidence` strings to candidates. The confidence grading and the rest of the pipeline stay the same.
- **Different Commvault response shapes:** change only `cv_reader.py`.

## 10. Proposed roadmap

1. ✅ Discovery, approval, drift
2. ✅ Technology-aware sequencing, enforced approval, order drift, recovery-group audit
3. Validate on an 11.46 lab; paging, candidate caps, least-privilege role
4. VM provider tags as evidence; one external source (ServiceNow CMDB or cloud tags)
5. `apply_recovery_plan`: create/update the Cleanroom recovery group with these priorities (first write action)
6. `find_clean_recovery_point` (Threat Scan) → `prove_recoverability` (Cleanroom recovery + executed readiness gates → recoverability evidence)

## 11. What I'm asking engineering for

1. Technical review of the approach and the MCP tool contracts.
2. Access to a small 11.46 lab CommCell plus a read-only service account, to validate the endpoints in §5.
3. Guidance on whether this belongs in `commvault-mcp-server` as an optional tool category (like the DocuSign/Salesforce integrations), and the contribution process.
