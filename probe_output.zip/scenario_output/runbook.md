# Recovery runbook - Identity compromise (Active Directory / Entra ID)

- Compromise time (t0): **2026-10-18T18:37:33Z** - dwell time 24.0 h - clean cutoff: **2026-10-17T18:37:33Z**
- Playbook(s): identity_compromise - selected: specified by caller
- Recovery-point policy: `before_cutoff` - isolation: `cleanroom`
- Recovery order: P1: dc1 -> P2: vmwsql1 -> P3: exchange1, vmwlnx1, vmwwin1
- Fingerprint: `16b77fa77dd2d19e` - generated 2026-10-20T18:37:55.489808Z (read-only plan; nothing executed)

## Existing recovery group findings

- **MEDIUM** The recovery-point setting of 'Sample Application 1' could not be read from the API; confirm it is not LATEST.
- **MEDIUM** Per-machine priorities of 'Sample Application 1' were not returned by the API, so its order could not be checked.
- **HIGH** dc1 is in the recovery scope but not in recovery group 'Sample Application 1'.
- **HIGH** exchange1 is in the recovery scope but not in recovery group 'Sample Application 1'.
- **HIGH** vmwwin1 is in the recovery scope but not in recovery group 'Sample Application 1'.

## Gaps

- **MEDIUM** exchange1: Protection could not be determined from the API

## Contain and preserve evidence

1. **Disable or reset the 3 identity/control object(s) in the blast radius** - _MANUAL (identity_team)_  
   svc-sql, Domain Admins, cv.lab
2. **Disable compromised accounts and revoke their sessions/tokens** - _MANUAL (identity_team)_  
   Includes service accounts and service principals in the blast radius.
3. **Isolate domain controllers / identity infrastructure from production networks** - _MANUAL (network_team)_  
   Prevent further replication of attacker changes.
4. **Preserve forensic evidence before any restore** - _MANUAL (security_team)_  
   Snapshot or image compromised DCs and logs; never restore over the only copy of evidence.

## Establish a trusted recovery plane

5. **Access Commvault with break-glass credentials and MFA** - _MANUAL (security_team)_  
   Treat Commvault admin and service accounts tied to the compromised directory as suspect.
6. **Review Commvault audit trail for unauthorized changes since the cutoff** - _MANUAL (security_team)_  
   Plan, retention, user and role changes; deletion requests.
7. **Confirm immutable / air-gapped copies are intact** - _AUTO (Commvault)_  
   Recovery points come from copies the attacker could not modify.

## Select clean recovery points

8. **Use recovery points from BEFORE the clean cutoff (t0 minus dwell time)** - _AUTO (Commvault)_  
   Never LATEST: the latest points may contain attacker persistence. Per-resource points are listed in the recovery sequence.
9. **Threat Scan the chosen recovery points** - _AUTO (Commvault)_  
   Confirm the selected points are clean before restoring.

## Recover identity first (in the cleanroom)

10. **Restore a domain controller from the pre-cutoff point into the cleanroom** - _AUTO (Commvault)_  
   If the DC is a Commvault client in scope it appears at the first priority of the recovery sequence.
11. **Perform AD forest recovery** - _MANUAL (identity_team)_  
   Seize FSMO roles, clean up metadata for unrecovered DCs, verify SYSVOL.
12. **Reset the KRBTGT account password twice** - _MANUAL (identity_team)_  
   Invalidates forged Kerberos tickets (golden tickets).
13. **Reset privileged and service account credentials; remove unknown privileged accounts, delegations and GPOs** - _MANUAL (identity_team)_  
   Compare against the pre-cutoff state.

## Recover affected workloads in dependency order

14. **P1 - dc1 [foundation]: Restore from the pre-cutoff recovery point** - _AUTO (Commvault)_  
   Recovery point: 2026-10-16T19:08:32Z (job 18354). Waits for: nothing. Why in scope: Attack path: user:svc-sql -> [member_of] group:Domain Admins -> [admin_of] vm:dc1
15. **Gate: release priority 2 only when P1 is healthy** - _MANUAL (app_owner)_  
   DNS resolves internal zone; Domain controller services running; LDAP bind succeeds
16. **P2 - vmwsql1 [data]: Restore from the pre-cutoff recovery point** - _AUTO (Commvault)_  
   Recovery point: 2026-10-17T01:30:30Z (job 18452). Waits for: dc1. Why in scope: Attack path: user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:vmwsql1
17. **Gate: release priority 3 only when P2 is healthy** - _MANUAL (app_owner)_  
   Database service running; Every protected database ONLINE/OPEN; Test query (SELECT 1) succeeds
18. **P3 - exchange1 [application]: Protection could not be confirmed via API: verify in Command Center, then restore from the pre-cutoff point** - _MANUAL (app_owner)_  
   Recovery point: NONE before cutoff - see gaps. Waits for: vmwsql1. Why in scope: Attack path: user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:exchange1
19. **P3 - vmwlnx1 [application]: Restore from the pre-cutoff recovery point** - _AUTO (Commvault)_  
   Recovery point: 2026-10-16T18:41:24Z (job 18340). Waits for: vmwsql1. Why in scope: Attack path: user:svc-sql -> [has_credentials_for] vm:vmwlnx1
20. **P3 - vmwwin1 [application]: Restore from the pre-cutoff recovery point** - _AUTO (Commvault)_  
   Recovery point: 2026-10-16T18:59:49Z (job 18341). Waits for: vmwsql1. Why in scope: Attack path: user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:vmwwin1

## Validate

21. **Threat Scan the recovered workloads** - _AUTO (Commvault)_  
   Run Commvault Threat Scan on recovered data in the cleanroom; any hit stops promotion.
22. **Run readiness gates per priority** - _MANUAL (app_owner)_  
   Release each priority only when its readiness gates pass (see recovery sequence).
23. **Verify AD replication and authentication health** - _MANUAL (identity_team)_  
   dcdiag / repadmin clean; test logons for application service accounts.

## Rotate credentials

24. **Rotate every credential used by recovered applications** - _MANUAL (app_owner)_  
   Service accounts, connection strings, API keys stored on recovered servers.
25. **Rotate the credentials Commvault uses (if in the blast radius)** - _MANUAL (security_team)_  
   Commvault service accounts, hypervisor and cloud credentials.

## Reconnect in stages

26. **Promote recovered identity, then applications, back to production networks in priority order** - _MANUAL (network_team)_  
   Monitor for re-compromise indicators at each stage.

## Blast radius

1 compromised node(s) can reach 7 other node(s) within 6 hops: 5 Commvault-protected resource(s) in recovery scope, 3 identity/control object(s) needing credential action, 1 gap(s).

- `user:svc-sql` (service_account): directly compromised
- `group:Domain Admins` (group): user:svc-sql -> [member_of] group:Domain Admins
- `vm:vmwlnx1` (server): user:svc-sql -> [has_credentials_for] vm:vmwlnx1
- `domain:cv.lab` (domain): user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab
- `vm:dc1` (domain_controller): user:svc-sql -> [member_of] group:Domain Admins -> [admin_of] vm:dc1
- `vm:exchange1` (server): user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:exchange1
- `vm:vmwsql1` (server): user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:vmwsql1
- `vm:vmwwin1` (server): user:svc-sql -> [member_of] group:Domain Admins -> [generic_all] domain:cv.lab -> [authenticates] vm:vmwwin1

_Blast radius is what the compromised identities COULD control (over-approximation), which is the safe basis for recovery scoping. Accuracy depends on the completeness of the supplied graph._